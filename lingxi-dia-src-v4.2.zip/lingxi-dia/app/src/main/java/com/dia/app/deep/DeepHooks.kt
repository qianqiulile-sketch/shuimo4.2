package com.dia.app.deep

import android.net.Uri
import android.util.Log
import com.dia.app.agent.ToolHost
import com.dia.app.agent.ToolOutcome
import com.dia.app.files.AiFolder
import com.dia.app.files.FileManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 长思里每次调用工具前后的「自动记账」，让 AI 不用自己记得去存、去找：
 *
 * 调用前：
 *  - 文件参数（file / files / path …）写的是名字或相对路径时，先在本长思目录里模糊查找，换成真实文件编号
 *  - 搜过的词 / 读过的网址直接返回存档（加 "fresh":true 可强制重新联网）
 *  - create_file 直接生成到本长思的「成果/」（同名覆盖前自动把旧版放进「备份/历史」）
 * 调用后：
 *  - 搜索结果、网页正文、分步研究结果自动存档到「资料/」并登记
 *  - ai_files 写入的文件、其它工具新生成的文件自动登记到目录索引
 *  - 「找不到文件」时把本目录的文件清单附在结果里，让 AI 下一次能写对
 */
object DeepHooks {

    private const val TAG = "DeepHooks"

    class Pre(
        val args: JSONObject,
        /** 不为 null 时直接作为结果返回，不再执行工具 */
        val shortcut: ToolOutcome? = null,
        /** 调用前已登记的文件编号（null = 不清楚，不做新文件检测） */
        val fileIdsBefore: Set<String>? = null,
        val cached: Boolean = false,
    )

    /** 哪些工具的哪些参数是「已有文件」。 */
    private val FILE_ARGS = mapOf(
        "read_file" to listOf("file", "id", "path", "name"),
        "doc_outline" to listOf("file", "id", "path"),
        "edit_file" to listOf("file", "id", "path"),
        "rewrite_file" to listOf("file", "id", "path"),
        "convert_file" to listOf("file", "id", "path"),
        "restore_file" to listOf("file", "id", "name"),
        "translate" to listOf("file"),
        "pdf_tool" to listOf("file", "id"),
        "transcribe_audio" to listOf("file", "id", "path", "name"),
        "listen_audio" to listOf("file", "id", "path", "name"),
        "set_background" to listOf("image"),
    )

    /** 这些工具另存出的新文件要复制进本长思的「成果/」。 */
    private val COPY_IN = setOf("rewrite_file", "convert_file", "translate", "pdf_tool")

    private val FILE_ID = Regex("^f\\d+$", RegexOption.IGNORE_CASE)

    /** 每个长思每一轮的搜索次数：[0] 命中存档（重复搜）的次数，[1] 总次数。用来打断「反复搜同一个词」的死循环。 */
    private val searchCounts = java.util.concurrent.ConcurrentHashMap<String, IntArray>()

    private fun counter(sid: String): IntArray {
        val cycle = DeepEngine.get(sid)?.cycles ?: 0
        val key = "$sid#$cycle"
        if (searchCounts.size > 200) searchCounts.keys.filter { !it.startsWith("$sid#") }.take(100).forEach { searchCounts.remove(it) }
        return searchCounts.getOrPut(key) { IntArray(2) }
    }
    private val timeFmt get() = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.CHINA)

    private fun str(a: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = a.opt(k)
            if (v != null && v != JSONObject.NULL && v.toString().isNotBlank()) return v.toString().trim()
        }
        return ""
    }

    /** 在本长思目录（及其登记的外部文件、整个 AI 文件夹）里找文件，返回登记后的编号。 */
    fun resolveFileId(folder: File, key: String): String? {
        val k = key.trim()
        if (k.isEmpty() || FILE_ID.matches(k)) return null
        // 名字和已附加的文件完全一致（例如用户在对话里发的文件）：不改写，交给原来的查找
        if (FileManager.files.value.any { it.name.equals(k, true) }) return null
        val f = DeepMemory.findFile(folder, k)
            ?: externalByName(folder, k)
            ?: try { AiFolder.resolve(k).takeIf { it.isFile } } catch (_: Exception) { null }
            ?: try { DeepMemory.findFile(AiFolder.dir("作品"), k) } catch (_: Exception) { null }
            ?: return null
        return try {
            val ref = FileManager.attachPath(f.absolutePath)
            if (f.absolutePath.startsWith(folder.absolutePath)) DeepMemory.registerFile(folder, f, "", fileId = ref.id)
            ref.id
        } catch (e: Exception) {
            null
        }
    }

    private fun externalByName(folder: File, key: String): File? {
        val n = DeepMemory.norm(key.substringAfterLast('/').substringBeforeLast('.'))
        if (n.isEmpty()) return null
        val m = DeepMemory.load(folder)
        val ext = synchronized(m) { m.files.filter { it.external } }
        return ext.map { File(it.path) }.firstOrNull { it.isFile && DeepMemory.norm(it.nameWithoutExtension) == n }
    }

    suspend fun before(name: String, args0: JSONObject, host: ToolHost, sid: String): Pre {
        val folder = DeepEngine.folderOf(sid) ?: return Pre(args0)
        return try {
            withContext(Dispatchers.IO) { beforeIo(name, args0, host, sid, folder) }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "before $name: ${e.message}")
            Pre(args0)
        }
    }

    private suspend fun beforeIo(name: String, args0: JSONObject, host: ToolHost, sid: String, folder: File): Pre {
        val args = JSONObject(args0.toString())

        // 1. 文件参数：名字 → 真实文件
        FILE_ARGS[name]?.let { keys ->
            for (k in keys) {
                val v = args.opt(k)?.takeIf { it is String }?.toString()?.trim().orEmpty()
                if (v.isEmpty() || FILE_ID.matches(v)) continue
                resolveFileId(folder, v)?.let { id -> args.put(k, id) }
                break
            }
            if (name == "pdf_tool") {
                args.optJSONArray("files")?.let { a ->
                    val out = JSONArray()
                    for (i in 0 until a.length()) {
                        val v = a.optString(i)
                        out.put(resolveFileId(folder, v) ?: v)
                    }
                    args.put("files", out)
                }
            }
        }

        when (name) {
            // 2. 搜索 / 网页缓存
            "web_search" -> {
                val c = counter(sid)
                val total = synchronized(c) { ++c[1] }
                if (!args.optBoolean("fresh", false)) {
                    val q = str(args, "query", "q", "keyword", "text")
                    DeepMemory.findSearch(folder, q)?.let { (e, text) ->
                        val hits = synchronized(c) { ++c[0] }
                        // 这一轮已经第 2 次搜重复的词：资料够了，别再搜，去写文件
                        val stop = if (hits >= 2) "【系统】这一步你已经 $hits 次搜索重复的词（共搜索 $total 次），资料已经够用。停止搜索！${DeepEngine.outputsHint(sid)}\n\n" else ""
                        return Pre(
                            args, cached = true,
                            shortcut = ToolOutcome(
                                stop + "（本长思第 ${e.cycle} 轮已搜过「${e.q}」，以下是存档「${e.file}」。不要重复搜同样的词：" +
                                    "需要更多信息就换角度 / 换关键词；确实要最新结果可加 \"fresh\":true）\n\n" + text.take(if (hits >= 2) 1500 else 7000),
                                display = "♻ 使用存档：${e.file}\n\n" + text.take(1500),
                            ),
                        )
                    }
                }
            }
            "read_webpage" -> if (!args.optBoolean("fresh", false)) {
                val url = str(args, "url", "link")
                DeepMemory.findPage(folder, url)?.let { (e, text) ->
                    return Pre(
                        args, cached = true,
                        shortcut = ToolOutcome(
                            "（这个网页第 ${e.cycle} 轮已读过，以下是存档「${e.file}」，不必重读）\n\n" + text.take(9000),
                            display = "♻ 使用存档：${e.file}\n\n" + text.take(1500),
                        ),
                    )
                }
            }
            // 3. 成果文件直接生成在本长思目录
            "create_file" -> return Pre(args, shortcut = createInSession(args, host, sid, folder))
            // 4. ai_files 读文件时名字写错一点也能找到
            "ai_files" -> {
                val path = str(args, "path", "file", "name", "dir")
                val content = args.optString("content", args.optString("text", ""))
                val action = str(args, "action", "op").lowercase().ifBlank { if (content.isNotEmpty()) "write" else if (path.isBlank()) "list" else "read" }
                if (path.isNotBlank() && action in setOf("read", "cat", "open", "view", "info", "stat", "attach", "register")) {
                    val exists = try { AiFolder.resolve(path, folder).exists() } catch (_: Exception) { false }
                    if (!exists) {
                        val hit = DeepMemory.findFile(folder, path) ?: externalByName(folder, path)
                        if (hit != null) {
                            args.put("path", hit.absolutePath)
                            args.remove("file"); args.remove("name")
                        }
                    }
                }
            }
        }
        // 在解析完文件参数之后再记下已有的文件，之后多出来的才是本工具新生成的
        return Pre(args, fileIdsBefore = FileManager.files.value.map { it.id }.toSet())
    }

    private suspend fun createInSession(args: JSONObject, host: ToolHost, sid: String, folder: File): ToolOutcome {
        val name = str(args, "name", "filename", "title").ifBlank { "成果" }
        val content = args.optString("content", args.optString("text", ""))
        if (content.isBlank()) return ToolOutcome("缺少文件内容 content", ok = false)
        val ext = FileManager.normalizeFormat(str(args, "format", "type", "ext"), name)
        val base = name.trim().let { n -> if (n.contains('.') && n.substringAfterLast('.').length in 1..5) n.substringBeforeLast('.') else n }
        val dir = File(folder, DeepMemory.DIR_OUT).apply { mkdirs() }
        val target = File(dir, DeepMemory.slug(base, 40) + "." + ext)
        val label = mapOf("docx" to "Word", "pptx" to "PPT", "xlsx" to "Excel", "pdf" to "PDF").getOrDefault(ext, ext)
        val ok = host.confirm("在长思「成果」里${if (target.exists()) "更新" else "新建"}「${target.name}」？", "格式：$label\n长度：${content.length} 字")
        if (!ok) return ToolOutcome("用户取消了新建文件。", ok = false)
        host.progress("正在生成 $label…")
        val data = FileManager.renderContent(content, ext, base)
        val existed = target.exists()
        if (existed) {
            // 覆盖前留一份旧版
            try {
                val hist = File(folder, DeepMemory.DIR_BACKUP + "/历史").apply { mkdirs() }
                target.copyTo(File(hist, target.nameWithoutExtension + "_" + timeFmt.format(Date()) + "." + ext), overwrite = true)
            } catch (_: Exception) { }
        }
        target.writeBytes(data)
        AiFolder.touch()
        val ref = FileManager.attachPath(target.absolutePath)
        val desc = str(args, "desc", "description", "note").ifBlank { "成果：$base（$label）" }
        DeepMemory.registerFile(folder, target, desc, DeepEngine.stepTag(sid), ref.id)
        val rel = DeepMemory.DIR_OUT + "/" + target.name
        return ToolOutcome(
            "已${if (existed) "更新（旧版在 备份/历史）" else "生成"} ${ref.id}《${target.name}》，路径「$rel」（${AiFolder.sizeLabel(target.length())}）。" +
                "之后用 ${ref.id} 或这个路径读取 / 精修（ai_files read、doc_outline、edit_file、rewrite_file）。",
        )
    }

    fun after(name: String, pre: Pre, host: ToolHost, sid: String, outcome: ToolOutcome): ToolOutcome {
        if (pre.shortcut != null || pre.cached) return outcome
        val folder = DeepEngine.folderOf(sid) ?: return outcome
        return try {
            afterIo(name, pre.args, sid, folder, pre.fileIdsBefore, outcome)
        } catch (e: Exception) {
            Log.w(TAG, "after $name: ${e.message}")
            outcome
        }
    }

    private fun afterIo(name: String, args: JSONObject, sid: String, folder: File, before: Set<String>?, outcome: ToolOutcome): ToolOutcome {
        val step = DeepEngine.stepTag(sid)
        val cycle = DeepEngine.get(sid)?.cycles ?: 0
        var out = outcome
        if (outcome.ok) {
            when (name) {
                "web_search" -> {
                    val q = str(args, "query", "q", "keyword", "text")
                    if (q.isNotBlank()) {
                        val rel = DeepMemory.archiveSearch(folder, q, outcome.forModel, cycle, step)
                        val total = counter(sid).let { c -> synchronized(c) { c[1] } }
                        val more = if (total >= 6) "\n【系统】这一步已经搜索 $total 次了，请尽快动手：${DeepEngine.outputsHint(sid)}" else ""
                        out = outcome.copy(forModel = outcome.forModel + "\n\n（完整结果已自动存档：$rel，之后要用直接 ai_files read，不必重搜）" + more)
                    }
                }
                "read_webpage" -> {
                    val url = str(args, "url", "link")
                    val title = Regex("标题：(.+)").find(outcome.forModel)?.groupValues?.get(1)?.trim().orEmpty()
                    if (url.isNotBlank()) {
                        val rel = DeepMemory.archivePage(folder, url, title, outcome.forModel, cycle, step)
                        out = outcome.copy(forModel = outcome.forModel + "\n\n（网页正文已自动存档：$rel）")
                    }
                }
                "step_think" -> {
                    val q = str(args, "question", "query", "task", "text")
                    val rel = "资料/研究/r_${timeFmt.format(Date())}_${DeepMemory.slug(q)}.md"
                    val f = File(folder, rel)
                    f.parentFile?.mkdirs()
                    f.writeText("# 分步研究：$q\n\n$step\n\n${outcome.forModel}\n")
                    DeepMemory.registerFile(folder, f, "分步研究「${q.take(30)}」", step)
                    out = outcome.copy(forModel = outcome.forModel + "\n\n（研究结果已存档：$rel）")
                }
                "ai_files" -> {
                    val action = str(args, "action", "op").lowercase()
                    val content = args.optString("content", args.optString("text", ""))
                    val eff = action.ifBlank { if (content.isNotEmpty()) "write" else "" }
                    val p = when (eff) {
                        "write", "save", "create", "overwrite", "append", "add" -> str(args, "path", "file", "name", "dir")
                        "move", "rename", "mv", "copy", "cp" -> str(args, "to", "dest", "target", "new_path")
                        else -> ""
                    }
                    if (p.isNotBlank()) {
                        val f = try { AiFolder.resolve(p, folder) } catch (_: Exception) { null }
                        if (f != null && f.isFile) {
                            DeepMemory.registerFile(folder, f, str(args, "desc", "description", "note"), step)
                        }
                    }
                }
            }
        }
        // 其它工具新生成的文件（另存、转换、合并、翻译…）：登记到索引
        if (before != null) {
            val fresh = FileManager.files.value.filter { it.id !in before }
            for (ref in fresh) {
                val u = Uri.parse(ref.uri)
                if (u.scheme != "file") continue
                val f = File(u.path ?: continue)
                if (!f.isFile) continue
                DeepMemory.registerFile(folder, f, "由「${name}」生成", step, ref.id)
                // 改写 / 转换 / 翻译另存到了长思目录外：复制一份进「成果/」，交付门和成果报告才找得到。
                // 如果本步要产出的文件还没有、且名字对得上（报告.docx ← 报告_改写.docx），直接放到那个位置
                if (name in COPY_IN && !f.absolutePath.startsWith(folder.absolutePath)) {
                    try {
                        val stem = DeepMemory.norm(f.nameWithoutExtension)
                        val expect = DeepEngine.currentOutputs(sid).firstOrNull { rel ->
                            val n = rel.substringAfterLast('/')
                            n.substringAfterLast('.').equals(f.extension, true) && !File(folder, rel).exists() &&
                                stem.startsWith(DeepMemory.norm(n.substringBeforeLast('.')))
                        }
                        val dst = if (expect != null) File(folder, expect) else AiFolder.unique(File(folder, DeepMemory.DIR_OUT).apply { mkdirs() }, f.name)
                        dst.parentFile?.mkdirs()
                        f.copyTo(dst, overwrite = true)
                        DeepMemory.registerFile(folder, dst, "由「${name}」生成（已复制进本长思）", step)
                        out = out.copy(forModel = out.forModel + "\n（已复制到本长思：${DeepMemory.relPath(folder, dst)}）")
                    } catch (e: Exception) {
                        Log.w(TAG, "copy in: ${e.message}")
                    }
                }
            }
        }
        // 找不到文件：附上清单，下一次就能写对
        if (!out.ok && (out.forModel.contains("找不到") || out.forModel.contains("不存在"))) {
            out = out.copy(forModel = out.forModel + "\n\n本长思目录里现有的文件（用这里的路径或 f 编号）：\n" + DeepMemory.indexForPrompt(folder, 1800))
        }
        return out
    }
}
