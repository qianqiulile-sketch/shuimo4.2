package com.dia.app.pilot.cloud

/**
 * Holds the [Backend] enum used by Pilot, Guide, and the classifier.
 *
 * The actual routing logic lives in [TaskClassifier]: a model-driven
 * decision that combines fast hard rules with a brief on-device Gemma
 * classification call for ambiguous prompts. We keep the enum here so
 * existing call-sites referencing `TaskRouter.Backend` keep working.
 */
object TaskRouter {
    enum class Backend { LOCAL, CLOUD }
}
