package com.dia.app.deep

/**
 * 自主长思的「计划树」（纯 Kotlin，不依赖 Android，可单元测试）。
 *
 * 每个步骤有稳定的 id（s1、s2…，用户和 AI 同时修改也不会错位），
 * 显示用的编号（1、1.2、1.2.3）按位置实时计算。
 */
data class DeepStep(
    val id: String,
    val title: String,
    val detail: String = "",
    /** todo 待办 / doing 进行中 / done 完成 / skip 跳过 / failed 失败 */
    val status: String = TODO,
    /** 这一步的结论（简短） */
    val result: String = "",
    /** 谁加的：ai / user */
    val by: String = "ai",
    val children: List<DeepStep> = emptyList(),
    /** 这一步必须产出的文件（相对路径）。为空时按标题 / 说明自动识别（[DeepGate.expectedOutputs]） */
    val outputs: List<String> = emptyList(),
    /** 改写类步骤：要改写的原文件（相对路径） */
    val source: String = "",
    /** 上一次没完成的原因（下一次重做时告诉 AI） */
    val lastIssue: String = "",
) {
    val isLeaf: Boolean get() = children.isEmpty()

    /** 这一步必须产出的文件：显式指定的优先，否则从标题 / 说明里识别。 */
    val expectedOutputs: List<String> get() = outputs.ifEmpty { DeepGate.expectedOutputs(title, detail) }

    companion object {
        const val TODO = "todo"
        const val DOING = "doing"
        const val DONE = "done"
        const val SKIP = "skip"
        const val FAILED = "failed"
        val ALL_STATUS = listOf(TODO, DOING, DONE, SKIP, FAILED)
    }
}

/** 摊平后的一行（界面列表 / 提示词用）。 */
data class FlatStep(val step: DeepStep, val label: String, val depth: Int, val parentId: String?)

object PlanOps {

    fun statusIcon(s: String): String = when (s) {
        DeepStep.DONE -> "✓"
        DeepStep.DOING -> "▶"
        DeepStep.SKIP -> "⊘"
        DeepStep.FAILED -> "✗"
        else -> "○"
    }

    fun statusLabel(s: String): String = when (s) {
        DeepStep.DONE -> "完成"
        DeepStep.DOING -> "进行中"
        DeepStep.SKIP -> "跳过"
        DeepStep.FAILED -> "失败"
        else -> "待办"
    }

    fun normalizeStatus(s: String): String = when (s.trim().lowercase()) {
        "done", "完成", "已完成", "ok", "finished", "✓" -> DeepStep.DONE
        "doing", "进行中", "running", "in_progress" -> DeepStep.DOING
        "skip", "跳过", "skipped", "cancel", "取消" -> DeepStep.SKIP
        "failed", "失败", "error", "fail" -> DeepStep.FAILED
        else -> DeepStep.TODO
    }

    // ───────── 遍历 ─────────

    fun flatten(plan: List<DeepStep>): List<FlatStep> {
        val out = ArrayList<FlatStep>()
        fun walk(list: List<DeepStep>, prefix: String, depth: Int, parent: String?) {
            for ((i, s) in list.withIndex()) {
                val label = if (prefix.isEmpty()) "${i + 1}" else "$prefix.${i + 1}"
                out.add(FlatStep(s, label, depth, parent))
                walk(s.children, label, depth + 1, s.id)
            }
        }
        walk(plan, "", 0, null)
        return out
    }

    fun find(plan: List<DeepStep>, id: String): DeepStep? {
        for (s in plan) {
            if (s.id == id) return s
            find(s.children, id)?.let { return it }
        }
        return null
    }

    fun labelOf(plan: List<DeepStep>, id: String): String? = flatten(plan).firstOrNull { it.step.id == id }?.label

    /** 按 id（s3）或显示编号（1.2）查找。 */
    fun resolveId(plan: List<DeepStep>, key: String): String? {
        val k = key.trim().removePrefix("[").removeSuffix("]")
        if (k.isEmpty()) return null
        val flat = flatten(plan)
        flat.firstOrNull { it.step.id.equals(k, true) }?.let { return it.step.id }
        flat.firstOrNull { it.label == k }?.let { return it.step.id }
        flat.firstOrNull { it.step.title == k }?.let { return it.step.id }
        return null
    }

    fun parentOf(plan: List<DeepStep>, id: String): String? = flatten(plan).firstOrNull { it.step.id == id }?.parentId

    /** 一个步骤（含子步骤）是否已经结束（完成 / 跳过）。 */
    fun isClosed(s: DeepStep): Boolean =
        if (s.isLeaf) s.status == DeepStep.DONE || s.status == DeepStep.SKIP
        else s.status == DeepStep.SKIP || s.children.all { isClosed(it) }

    /**
     * 下一个要执行的步骤：按顺序第一个「待办 / 进行中 / 失败未重试」的叶子；
     * 被跳过的分支整个跳过。失败的步骤不会自动重试（AI 或用户可以改回待办）。
     */
    fun nextTodo(plan: List<DeepStep>): DeepStep? {
        for (s in plan) {
            if (s.status == DeepStep.SKIP) continue
            if (s.isLeaf) {
                if (s.status == DeepStep.TODO || s.status == DeepStep.DOING) return s
            } else {
                nextTodo(s.children)?.let { return it }
            }
        }
        return null
    }

    fun counts(plan: List<DeepStep>): Pair<Int, Int> {
        val leaves = flatten(plan).filter { it.step.isLeaf }
        val done = leaves.count { it.step.status == DeepStep.DONE || it.step.status == DeepStep.SKIP }
        return done to leaves.size
    }

    fun maxIdNumber(plan: List<DeepStep>): Int =
        flatten(plan).mapNotNull { it.step.id.removePrefix("s").toIntOrNull() }.maxOrNull() ?: 0

    // ───────── 修改（都返回新的计划，原计划不变） ─────────

    fun update(plan: List<DeepStep>, id: String, f: (DeepStep) -> DeepStep): List<DeepStep> =
        plan.map { s ->
            when {
                s.id == id -> f(s)
                s.children.isNotEmpty() -> s.copy(children = update(s.children, id, f))
                else -> s
            }
        }

    fun remove(plan: List<DeepStep>, id: String): List<DeepStep> =
        plan.filter { it.id != id }.map { if (it.children.isEmpty()) it else it.copy(children = remove(it.children, id)) }

    /**
     * 插入新步骤。
     * @param parentId 作为谁的子步骤（null = 顶层）
     * @param afterId 插在谁后面（null = 末尾）
     */
    fun insert(plan: List<DeepStep>, step: DeepStep, parentId: String? = null, afterId: String? = null): List<DeepStep> {
        fun into(list: List<DeepStep>): List<DeepStep> {
            if (afterId != null) {
                val i = list.indexOfFirst { it.id == afterId }
                if (i >= 0) return list.subList(0, i + 1) + step + list.subList(i + 1, list.size)
            }
            return list + step
        }
        if (parentId == null) {
            if (afterId != null && plan.none { it.id == afterId }) {
                // afterId 在更深层：插到它的兄弟中
                val p = parentOf(plan, afterId)
                if (p != null) return insert(plan, step, p, afterId)
            }
            return into(plan)
        }
        return update(plan, parentId) { it.copy(children = into(it.children), status = if (it.status == DeepStep.DONE) DeepStep.TODO else it.status) }
    }

    /** 插到下一个待办步骤的前面（同级）；没有待办就放到最后。用户标记「优先改写」时用。 */
    fun insertBeforeNext(plan: List<DeepStep>, step: DeepStep): List<DeepStep> {
        val next = nextTodo(plan) ?: return plan + step
        fun into(list: List<DeepStep>): List<DeepStep>? {
            val i = list.indexOfFirst { it.id == next.id }
            if (i >= 0) return list.subList(0, i) + step + list.subList(i, list.size)
            for ((j, c) in list.withIndex()) {
                val kids = into(c.children) ?: continue
                return list.subList(0, j) + c.copy(children = kids) + list.subList(j + 1, list.size)
            }
            return null
        }
        return into(plan) ?: (plan + step)
    }

    /** 同级上移 / 下移。 */
    fun move(plan: List<DeepStep>, id: String, up: Boolean): List<DeepStep> {
        fun inList(list: List<DeepStep>): List<DeepStep>? {
            val i = list.indexOfFirst { it.id == id }
            if (i < 0) return null
            val j = if (up) i - 1 else i + 1
            if (j !in list.indices) return list
            val m = list.toMutableList()
            val t = m[i]; m[i] = m[j]; m[j] = t
            return m
        }
        inList(plan)?.let { return it }
        return plan.map { s -> if (s.children.isEmpty()) s else s.copy(children = inList(s.children) ?: move(s.children, id, up)) }
    }

    /** 把进行中的步骤改回待办（例如暂停 / 重启后）。 */
    fun resetDoing(plan: List<DeepStep>): List<DeepStep> =
        plan.map { s ->
            s.copy(
                status = if (s.status == DeepStep.DOING) DeepStep.TODO else s.status,
                children = resetDoing(s.children),
            )
        }

    /** 把失败的步骤改回待办（用户补充了资料 / 提示后重新尝试）。返回 (新计划, 被重置的 id)。 */
    fun resetFailed(plan: List<DeepStep>): Pair<List<DeepStep>, List<String>> {
        val ids = ArrayList<String>()
        fun walk(list: List<DeepStep>): List<DeepStep> = list.map { s ->
            if (s.status == DeepStep.FAILED) ids.add(s.id)
            s.copy(status = if (s.status == DeepStep.FAILED) DeepStep.TODO else s.status, children = walk(s.children))
        }
        return walk(plan) to ids
    }

    /** 失败的步骤（给复盘看）。 */
    fun failed(plan: List<DeepStep>): List<FlatStep> = flatten(plan).filter { it.step.status == DeepStep.FAILED }

    // ───────── 文本 ─────────

    /** 给模型看的计划（带 id、编号、状态、结论）。 */
    fun render(plan: List<DeepStep>, currentId: String? = null, resultChars: Int = 80): String {
        if (plan.isEmpty()) return "（还没有计划）"
        val sb = StringBuilder()
        for (f in flatten(plan)) {
            val s = f.step
            sb.append("  ".repeat(f.depth)).append(statusIcon(s.status)).append(" [").append(s.id).append("] ")
                .append(f.label).append(' ').append(s.title)
            if (s.by == "user") sb.append("（用户添加）")
            if (s.id == currentId) sb.append("  ← 当前")
            if (s.result.isNotBlank() && resultChars > 0) sb.append(" —— ").append(s.result.replace('\n', ' ').take(resultChars))
            sb.append('\n')
        }
        return sb.toString().trimEnd()
    }

    /** Markdown 版本（写进「计划.md」）。 */
    fun markdown(topic: String, plan: List<DeepStep>): String {
        val sb = StringBuilder("# 长思计划：").append(topic).append("\n\n")
        val (d, t) = counts(plan)
        sb.append("进度：").append(d).append('/').append(t).append("\n\n")
        for (f in flatten(plan)) {
            val s = f.step
            val box = when (s.status) { DeepStep.DONE -> "[x]"; DeepStep.SKIP -> "[-]"; DeepStep.FAILED -> "[!]"; DeepStep.DOING -> "[>]"; else -> "[ ]" }
            sb.append("  ".repeat(f.depth)).append("- ").append(box).append(' ').append(f.label).append(' ').append(s.title)
            if (s.by == "user") sb.append(" *(用户)*")
            sb.append('\n')
            if (s.detail.isNotBlank()) sb.append("  ".repeat(f.depth + 1)).append("> ").append(s.detail.replace('\n', ' ')).append('\n')
            if (s.result.isNotBlank()) sb.append("  ".repeat(f.depth + 1)).append("结论：").append(s.result.replace('\n', ' ')).append('\n')
        }
        return sb.toString()
    }

    /**
     * 解析模型给出的计划：
     *  - 缩进 / 编号列表：「1. xxx」「  1.1 yyy」「- zzz」
     * 返回 (深度, 标题, 说明) 列表，深度从 0 开始。
     */
    fun parseOutline(text: String): List<Triple<Int, String, String>> {
        val out = ArrayList<Triple<Int, String, String>>()
        val numRe = Regex("^(\\s*)(\\d+(?:\\.\\d+)*)[.、)）]?\\s+(.+)$")
        val bulRe = Regex("^(\\s*)[-*•·]\\s+(?:\\[[ xX]\\]\\s*)?(.+)$")
        for (raw in text.lines()) {
            val line = raw.replace("\t", "    ")
            if (line.isBlank()) continue
            val m = numRe.find(line)
            val (depth, body) = if (m != null) {
                val dots = m.groupValues[2].count { it == '.' }
                val indent = m.groupValues[1].length / 2
                maxOf(dots, indent) to m.groupValues[3]
            } else {
                val b = bulRe.find(line) ?: continue
                (b.groupValues[1].length / 2) to b.groupValues[2]
            }
            val clean = body.trim().trim('*').trim()
            if (clean.length < 2) continue
            val title = clean.substringBefore("：").substringBefore(": ").trim().ifBlank { clean }
            val detail = if (clean.length > title.length) clean.substring(title.length).trimStart('：', ':', ' ') else ""
            out.add(Triple(depth.coerceIn(0, 4), title.take(80), detail.take(300)))
        }
        return out
    }

    /** 由 (深度, 标题, 说明) 列表建计划树；idStart 是下一个可用的编号。 */
    fun build(items: List<Triple<Int, String, String>>, idStart: Int, by: String = "ai"): Pair<List<DeepStep>, Int> {
        var next = idStart
        // 用可变节点先搭树，再转成不可变
        class N(val step: DeepStep, val depth: Int) { val kids = ArrayList<N>() }
        val roots = ArrayList<N>()
        val stack = ArrayList<N>()
        for ((depth, title, detail) in items) {
            val n = N(DeepStep("s${next++}", title, detail, by = by), depth)
            while (stack.isNotEmpty() && stack.last().depth >= depth) stack.removeAt(stack.lastIndex)
            if (stack.isEmpty()) roots.add(n) else stack.last().kids.add(n)
            stack.add(n)
        }
        fun conv(n: N): DeepStep = n.step.copy(children = n.kids.map { conv(it) })
        return roots.map { conv(it) } to next
    }
}
