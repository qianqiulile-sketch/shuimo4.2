package com.dia.app.slate

import androidx.compose.ui.graphics.Color

/**
 * One sample point inside a stroke, stored in **page-space** (px relative
 * to top-left of the page). Pressure is normalised 0..1; on devices
 * without pressure we use the constant value the platform reports.
 */
data class InkPoint(
    val x: Float,
    val y: Float,
    val pressure: Float = 1f,
)

/** Origin of a stroke — distinguishes user ink from AI handwriting. */
enum class StrokeOrigin { USER, AI }

/** Pen mode the user is currently using. */
enum class PenMode { PEN, HIGHLIGHTER, ERASER }

/**
 * A single ink stroke. Points are in page-space, so when we pan/zoom
 * we don't have to re-walk the strokes — just transform the canvas.
 */
data class Stroke(
    val id: Long,
    val points: MutableList<InkPoint> = mutableListOf(),
    val color: Color,
    val width: Float,
    val origin: StrokeOrigin = StrokeOrigin.USER,
    val mode: PenMode = PenMode.PEN,
) {
    var minX: Float = Float.POSITIVE_INFINITY
        private set
    var minY: Float = Float.POSITIVE_INFINITY
        private set
    var maxX: Float = Float.NEGATIVE_INFINITY
        private set
    var maxY: Float = Float.NEGATIVE_INFINITY
        private set

    fun add(p: InkPoint) {
        points.add(p)
        if (p.x < minX) minX = p.x
        if (p.y < minY) minY = p.y
        if (p.x > maxX) maxX = p.x
        if (p.y > maxY) maxY = p.y
    }
}
