package com.dia.app.screen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.dia.app.DiaAccessibilityService
import com.dia.app.MainActivity
import com.dia.app.R
import com.dia.app.guide.GuideOverlayService
import com.dia.app.pilot.PilotAgent
import com.dia.app.prefs.DiaSettings
import com.dia.app.ui.chat.ChatController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * 悬浮气泡：浮在所有应用上方，单击展开菜单，拖动移动，双击隐藏。
 *
 * 菜单内容、名称、提示词、顺序、颜色大小都可以在
 * 「对话页 → 菜单 → 悬浮气泡设置」里编辑（见 [BubbleConfig]）。
 * 「问灵犀」会读取当前屏幕文字，连同问题一起发到灵犀对话里回答。
 */
class QuickActionService : Service() {

    companion object {
        private const val TAG = "QuickAction"
        private const val CHANNEL_ID = "dia_quick_action_channel"
        private const val NOTIFICATION_ID = 4714

        @Volatile
        private var running = false
        fun isRunning(): Boolean = running

        fun hasOverlayPermission(context: Context): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)

        fun start(context: Context) {
            if (!hasOverlayPermission(context)) return
            val intent = Intent(context, QuickActionService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
                else context.startService(intent)
            } catch (e: Exception) { Log.w(TAG, "start failed: ${e.message}") }
        }

        fun stop(context: Context) {
            try { context.stopService(Intent(context, QuickActionService::class.java)) } catch (_: Exception) {}
        }
    }

    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var menu: View? = null
    private var resultCard: View? = null
    private var askPanel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var observeJob: Job? = null
    private var styleJob: Job? = null
    private var menuJob: Job? = null
    private var cardJob: Job? = null
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        BubbleConfig.init(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        showBubble()
        observeResults()
        styleJob = scope.launch {
            var first = true
            BubbleConfig.style.collectLatest {
                if (first) { first = false; return@collectLatest }
                val oldX = bubbleParams?.x
                val oldY = bubbleParams?.y
                removeBubble()
                showBubble(oldX, oldY)
            }
        }
    }

    override fun onDestroy() {
        running = false
        observeJob?.cancel()
        styleJob?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
        removeBubble()
        removeMenu()
        removeResultCard()
        removeAskPanel()
        super.onDestroy()
    }

    // ───────── 气泡 ─────────

    private fun showBubble(posX: Int? = null, posY: Int? = null) {
        if (bubble != null) return
        val style = BubbleConfig.style.value
        val size = dp(style.sizeDp)
        val view = FrameLayout(this).apply {
            alpha = style.alpha
            val seal = TextView(this@QuickActionService).apply {
                text = "灵"
                gravity = Gravity.CENTER
                setTextColor(0xFFFFF6EA.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.42f)
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = size * 0.26f
                    setColor(style.colorInt())
                    setStroke(dp(2), 0xCCFFF1E2.toInt())
                }
            }
            addView(seal, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        }

        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val params = WindowManager.LayoutParams(
            size + dp(8), size + dp(8),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = posX ?: (screenW - size - dp(16))
            y = posY ?: (screenH / 2)
        }

        var isDragging = false
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var lastTapTime = 0L

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isDragging = false
                    initialX = params.x; initialY = params.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (dx * dx + dy * dy > 100) {
                        isDragging = true
                        params.x = (initialX + dx).toInt()
                        params.y = (initialY + dy).toInt()
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        val now = System.currentTimeMillis()
                        if (now - lastTapTime < 300) stopSelf() else {
                            lastTapTime = now
                            toggleMenu()
                        }
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(view, params)
            bubble = view
            bubbleParams = params
        } catch (e: Exception) { Log.w(TAG, "bubble add failed: ${e.message}") }
    }

    private fun removeBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    // ───────── 菜单（来自可编辑配置） ─────────

    private fun toggleMenu() {
        if (menu != null) { removeMenu(); return }
        showMenu()
    }

    private fun panelBackground(radius: Int = 18): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(0xF21F1A16.toInt(), 0xEE2B231C.toInt()),
    ).apply {
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), 0x66D4A85A)
    }

    private fun showMenu() {
        removeMenu()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = panelBackground()
            elevation = dp(10).toFloat()
        }
        val title = TextView(this).apply {
            text = "灵犀 · 随手问"
            setTextColor(0xFFD4A85A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            setPadding(dp(6), dp(2), dp(6), dp(6))
        }
        container.addView(title)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        val actions = BubbleConfig.actions.value.filter { it.enabled }
        for (a in actions) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(9), dp(12), dp(9))
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(0x14F0E8D8)
                }
            }
            row.addView(TextView(this).apply {
                text = a.label
                setTextColor(0xFFF0E8D8.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            })
            if (a.subtitle.isNotBlank()) {
                row.addView(TextView(this).apply {
                    text = a.subtitle
                    setTextColor(0x99F0E8D8.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                })
            }
            row.setOnClickListener { removeMenu(); runAction(a) }
            list.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply { bottomMargin = dp(5) })
        }
        if (actions.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "菜单是空的，请在灵犀里编辑气泡菜单"
                setTextColor(0x99F0E8D8.toInt())
                setOnClickListener { removeMenu(); ChatBridge.openChat(this@QuickActionService) }
            })
        }
        val maxH = (resources.displayMetrics.heightPixels * 0.55f).toInt()
        container.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        scroll.post {
            if (scroll.height > maxH) {
                scroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH)
            }
        }

        val bp = bubbleParams ?: return
        val params = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val screenW = resources.displayMetrics.widthPixels
            x = if (bp.x > screenW / 2) (bp.x - dp(232)).coerceAtLeast(dp(8)) else (bp.x + dp(64)).coerceAtMost(screenW - dp(248))
            y = (bp.y - dp(80)).coerceAtLeast(dp(24))
        }
        try { windowManager.addView(container, params); menu = container } catch (e: Exception) { Log.w(TAG, "menu add failed: ${e.message}") }

        menuJob?.cancel()
        menuJob = scope.launch {
            delay(BubbleConfig.style.value.menuSeconds * 1000L)
            removeMenu()
        }
    }

    private fun removeMenu() {
        menu?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        menu = null
    }

    private fun runAction(a: BubbleAction) {
        when (a.type) {
            BubbleAction.TYPE_TRANSLATE -> ScreenAssistant.translateScreen()
            BubbleAction.TYPE_SUMMARIZE -> ScreenAssistant.summarizeScreenImage()
            BubbleAction.TYPE_ANSWER -> ScreenAssistant.answerScreen()
            BubbleAction.TYPE_SOLVE -> ScreenAssistant.solveScreen()
            BubbleAction.TYPE_ASK_REGION -> startAskAboutScreen()
            BubbleAction.TYPE_QUICK_ASK -> showAskPanel(a.prompt)
            BubbleAction.TYPE_SCREEN_TO_CHAT -> {
                val text = DiaAccessibilityService.getInstance()?.getAllScreenText()
                if (text.isNullOrBlank()) {
                    Toast.makeText(this, "读不到屏幕文字（需要开启无障碍服务）", Toast.LENGTH_SHORT).show()
                } else {
                    ChatBridge.openChatWithDraft(this, "【屏幕内容】\n${text.take(3000)}\n\n")
                }
            }
            BubbleAction.TYPE_VOICE -> startVoiceCommand()
            BubbleAction.TYPE_OPEN_CHAT -> ChatBridge.openChat(this)
            BubbleAction.TYPE_CUSTOM -> {
                if (!DiaAccessibilityService.isRunning()) {
                    Toast.makeText(this, "需要先开启无障碍服务", Toast.LENGTH_SHORT).show()
                } else {
                    com.dia.app.translate.ScreenTranslateService.start(
                        this, com.dia.app.translate.ScreenTranslateService.Mode.ASK, a.prompt.ifBlank { a.label },
                    )
                }
            }
            BubbleAction.TYPE_HIDE -> stopSelf()
        }
    }

    // ───────── 问灵犀：输入问题 + 屏幕上下文 ─────────

    private fun showAskPanel(defaultQuestion: String) {
        removeAskPanel()
        // 先读取屏幕（面板弹出后活动窗口会变成面板本身）
        val screenText = DiaAccessibilityService.getInstance()?.getAllScreenText()?.take(2500)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            background = panelBackground(16)
            elevation = dp(12).toFloat()
        }
        panel.addView(TextView(this).apply {
            text = if (screenText.isNullOrBlank()) "问灵犀" else "问灵犀（已读取当前屏幕 ${screenText.length} 字）"
            setTextColor(0xFFD4A85A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        })
        val edit = EditText(this).apply {
            hint = "例如：这段话是什么意思？帮我回复一下"
            setText(defaultQuestion)
            setTextColor(0xFFF0E8D8.toInt())
            setHintTextColor(0x88F0E8D8.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            imeOptions = EditorInfo.IME_ACTION_SEND
            minLines = 2
            maxLines = 5
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(0x22F0E8D8)
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        panel.addView(edit, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(8), 0, 0)
        }
        fun submit() {
            val q = edit.text?.toString()?.trim().orEmpty()
            if (q.isEmpty()) return
            hideKeyboard(edit)
            removeAskPanel()
            showCard("灵犀思考中…", withActions = false)
            ChatController.askFromBubble(q, screenText) { answer ->
                scope.launch { showCard(answer.ifBlank { "（没有得到回答）" }, withActions = true) }
            }
        }
        row.addView(textButton("取消", 0xFFB5A88F.toInt()) { hideKeyboard(edit); removeAskPanel() })
        row.addView(textButton("发送", 0xFFE0533F.toInt()) { submit() })
        panel.addView(row)
        edit.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
        }

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.9f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(80)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            windowManager.addView(panel, params)
            askPanel = panel
            edit.requestFocus()
            edit.postDelayed({
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
            }, 200)
        } catch (e: Exception) {
            Log.w(TAG, "ask panel failed: ${e.message}")
        }
    }

    private fun hideKeyboard(v: View) {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(v.windowToken, 0)
        } catch (_: Exception) {}
    }

    private fun removeAskPanel() {
        askPanel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        askPanel = null
    }

    private fun textButton(label: String, color: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
    }

    // ───────── 结果卡片 ─────────

    private fun observeResults() {
        observeJob = scope.launch {
            ScreenAssistant.status.collectLatest { st ->
                when (st) {
                    ScreenAssistant.Status.WORKING -> showCard("处理中…", withActions = false)
                    ScreenAssistant.Status.DONE, ScreenAssistant.Status.ERROR -> {
                        showCard(ScreenAssistant.result.value.ifBlank { "完成" }, withActions = true)
                        ScreenAssistant.dismiss()
                    }
                    ScreenAssistant.Status.IDLE -> Unit
                }
            }
        }
    }

    private fun showCard(text: String, withActions: Boolean) {
        removeResultCard()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
            background = panelBackground(16)
            elevation = dp(8).toFloat()
        }
        val scroll = ScrollView(this)
        val tv = TextView(this).apply {
            this.text = text
            setTextColor(0xFFF0E8D8.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setLineSpacing(0f, 1.25f)
            maxHeight = (resources.displayMetrics.heightPixels * 0.45f).toInt()
            setTextIsSelectable(withActions)
        }
        scroll.addView(tv)
        card.addView(scroll)
        if (withActions) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
            }
            row.addView(textButton("复制", 0xFFD4A85A.toInt()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("灵犀", text))
                Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show()
            })
            row.addView(textButton("在对话中继续", 0xFFE0533F.toInt()) {
                removeResultCard()
                ChatBridge.openChat(this)
            })
            row.addView(textButton("关闭", 0xFFB5A88F.toInt()) { removeResultCard() })
            card.addView(row)
        }
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(80)
        }
        try { windowManager.addView(card, params); resultCard = card } catch (e: Exception) { Log.w(TAG, "card add failed: ${e.message}") }

        cardJob?.cancel()
        val seconds = BubbleConfig.style.value.resultSeconds
        if (withActions && seconds > 0) {
            cardJob = scope.launch {
                delay(seconds * 1000L)
                if (resultCard === card) removeResultCard()
            }
        }
    }

    private fun removeResultCard() {
        resultCard?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        resultCard = null
    }

    // ───────── 框选后语音提问 ─────────

    private fun startAskAboutScreen() {
        Toast.makeText(this, "请框选你想问的区域…", Toast.LENGTH_SHORT).show()
        com.dia.app.translate.ScreenTranslateService.startTwoStepAsk(this, onRegionPicked = {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                listen(
                    onText = { q -> com.dia.app.translate.ScreenTranslateService.submitTwoStepAsk(this, q.ifBlank { "这是什么？" }) },
                    onFail = { com.dia.app.translate.ScreenTranslateService.submitTwoStepAsk(this, "这是什么？") },
                )
            } else {
                com.dia.app.translate.ScreenTranslateService.submitTwoStepAsk(this, "这是什么？")
            }
        })
    }

    private fun listen(onText: (String) -> Unit, onFail: () -> Unit) {
        Toast.makeText(this, "请说话…", Toast.LENGTH_SHORT).show()
        if (speechRecognizer == null) speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(p: Float) {}
            override fun onBufferReceived(p: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) {
                Toast.makeText(this@QuickActionService, "没听清", Toast.LENGTH_SHORT).show()
                onFail()
            }
            override fun onResults(results: android.os.Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) onText(text) else onFail()
            }
            override fun onPartialResults(p: android.os.Bundle?) {}
            override fun onEvent(p: Int, q: android.os.Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, DiaSettings.voiceLanguage.value.ifBlank { "zh-CN" })
        }
        try { speechRecognizer?.startListening(intent) } catch (_: Exception) { onFail() }
    }

    // ───────── 语音指令 ─────────

    private fun startVoiceCommand() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "此设备不支持语音识别", Toast.LENGTH_SHORT).show()
            return
        }
        listen(onText = { routeVoiceCommand(it) }, onFail = {})
    }

    private fun routeVoiceCommand(text: String) {
        Toast.makeText(this, "收到：$text", Toast.LENGTH_SHORT).show()
        when {
            text.contains("怎么") || text.contains("教我") || text.contains("在哪") || text.contains("引导") -> {
                showCard("屏幕引导：$text", withActions = false)
                GuideOverlayService.start(this, text)
            }
            text.contains("翻译") -> ScreenAssistant.translateScreen()
            text.startsWith("问") || text.endsWith("吗") || text.endsWith("？") || text.endsWith("?") -> {
                val screen = DiaAccessibilityService.getInstance()?.getAllScreenText()?.take(2500)
                showCard("灵犀思考中…", withActions = false)
                ChatController.askFromBubble(text, screen) { answer -> scope.launch { showCard(answer, withActions = true) } }
            }
            else -> {
                showCard("正在执行：$text", withActions = false)
                PilotAgent.attach(applicationContext)
                PilotAgent.start(text)
            }
        }
    }

    // ───────── 通知 ─────────

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "灵犀 悬浮气泡", NotificationManager.IMPORTANCE_LOW).apply {
                description = "悬浮气泡常驻通知"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP) }
        val pending = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("灵犀")
            .setContentText("悬浮气泡已开启 · 单击气泡展开菜单")
            .setSmallIcon(R.drawable.ic_dia_logo)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(pending)
            .build()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
