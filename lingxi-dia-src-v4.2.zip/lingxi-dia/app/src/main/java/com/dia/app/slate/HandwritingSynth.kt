package com.dia.app.slate

import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.graphics.PathMeasure
import android.graphics.Typeface
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Convert AI text into a sequence of [Stroke]s that look hand-written and
 * can be played back by [SlateAi.animateStrokes].
 *
 * Strategy: use Android's [Paint.getTextPath] to get the real outline of
 * each character from a system typeface (cursive when available, falling
 * back to a serif). Walk that outline with [PathMeasure] to extract
 * stroke samples, then add tiny jitter for a hand-drawn feel.
 *
 * This is what fixes the old screen's complaints:
 *   - Real letters, not the spider-scribble glyph table.
 *   - Stroke samples come from the typeface so they're readable at all sizes.
 *   - Per-character paths means the "lift the pen between letters" gap is
 *     natural (one stroke per glyph contour, not per word).
 */
object HandwritingSynth {

    private val rand = Random.Default
    /** Step (in path units) when sampling a character outline. Smaller = smoother but more state churn. */
    private const val SAMPLE_STEP_PX = 2.5f

    /** Cached typeface — looked up once, then reused. */
    private val typeface: Typeface by lazy { resolveCursiveTypeface() }

    private fun resolveCursiveTypeface(): Typeface {
        // "casual" is the closest to handwriting on most Android fonts.
        // Falls back gracefully if missing.
        return try {
            val candidates = listOf("casual", "cursive", "sans-serif")
            for (name in candidates) {
                val tf = Typeface.create(name, Typeface.NORMAL)
                // Typeface.create never returns null but might return the
                // default — accept it regardless; cursive is our preferred
                // when available.
                if (tf !== Typeface.DEFAULT || name == candidates.last()) return tf
            }
            Typeface.SERIF
        } catch (_: Exception) {
            Typeface.SERIF
        }
    }

    /**
     * Synthesize strokes for [text] starting at [anchor] (page-space px).
     * Each text line will be [lineHeight] px tall; long lines wrap at
     * [maxWidth]. Output strokes use [color] and a width derived from
     * [lineHeight].
     */
    fun synthesize(
        text: String,
        anchor: Offset,
        lineHeight: Float,
        maxWidth: Float,
        color: Color = AiInk,
        /** Optional bottom limit (page-space). Lines that don't fit are dropped. */
        maxBottomY: Float = Float.POSITIVE_INFINITY,
    ): List<Stroke> {
        if (text.isBlank() || lineHeight <= 0f || maxWidth <= 64f) return emptyList()

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = this@HandwritingSynth.typeface
            // Slight italic for a handwritten lean, even on serif fallback.
            textSkewX = -0.12f
            textSize = lineHeight
            style = Paint.Style.FILL
        }
        val strokeWidth = (lineHeight * 0.07f).coerceIn(1.6f, 4.5f)
        val lineSpacing = lineHeight * 1.45f
        val spaceWidth = paint.measureText(" ")

        val out = ArrayList<Stroke>()

        // Word-wrap.
        val lines = wrapToWidth(text, paint, maxWidth, spaceWidth)
        var penY = anchor.y + lineHeight  // baseline of the first line
        for (line in lines) {
            // Drop any line whose baseline would fall below the page.
            if (penY > maxBottomY) break
            var penX = anchor.x
            for (ch in line) {
                if (ch == ' ') {
                    penX += spaceWidth
                    continue
                }
                val s = ch.toString()
                val charW = paint.measureText(s)
                // Get the outline of this character at (penX, penY) in
                // page-space.
                val charPath = AndroidPath()
                paint.getTextPath(s, 0, 1, penX, penY, charPath)

                // Apply tiny per-glyph jitter — vertical wobble + slight rotation.
                val yJit = (rand.nextFloat() - 0.5f) * lineHeight * 0.04f
                val rot = (rand.nextFloat() - 0.5f) * 4f  // ±2°
                val matrix = Matrix().apply {
                    setRotate(rot, penX + charW / 2f, penY)
                    postTranslate(0f, yJit)
                }
                charPath.transform(matrix)

                // Sample the path into one stroke per contour.
                val contours = sampleContours(charPath, strokeWidth, color)
                out += contours

                penX += charW
            }
            penY += lineSpacing
        }
        return out
    }

    /**
     * Sample one Android Path into one [Stroke] per closed contour. Uses
     * [PathMeasure] which walks the outline naturally.
     */
    private fun sampleContours(path: AndroidPath, baseWidth: Float, color: Color): List<Stroke> {
        val out = ArrayList<Stroke>()
        val pm = PathMeasure(path, false)
        val pos = FloatArray(2)
        do {
            val length = pm.length
            if (length <= 0.5f) continue
            val nSamples = max(2, (length / SAMPLE_STEP_PX).toInt())
            val stroke = Stroke(
                id = -1L,  // overwritten when committed by SlateAi.animateStrokes
                color = color,
                width = baseWidth * (0.85f + rand.nextFloat() * 0.3f),
                origin = StrokeOrigin.AI,
                mode = PenMode.PEN,
            )
            for (i in 0..nSamples) {
                val t = (i.toFloat() / nSamples).coerceIn(0f, 1f)
                if (pm.getPosTan(t * length, pos, null)) {
                    val pressure = 0.85f + 0.12f * sin(i * 0.45f)
                    stroke.add(InkPoint(pos[0], pos[1], pressure))
                }
            }
            if (stroke.points.size >= 2) out.add(stroke)
        } while (pm.nextContour())
        return out
    }

    /** Word-wrap using [paint.measureText] which respects the actual font. */
    private fun wrapToWidth(
        text: String,
        paint: Paint,
        maxWidth: Float,
        spaceWidth: Float,
    ): List<String> {
        val out = ArrayList<String>()
        for (rawLine in text.split('\n')) {
            if (rawLine.isBlank()) {
                out.add("")
                continue
            }
            val words = rawLine.split(' ').filter { it.isNotEmpty() }
            val cur = StringBuilder()
            var curW = 0f
            for (w in words) {
                val ww = paint.measureText(w)
                val withSpace = if (cur.isEmpty()) ww else curW + spaceWidth + ww
                if (withSpace <= maxWidth) {
                    if (cur.isNotEmpty()) {
                        cur.append(' ')
                        curW += spaceWidth
                    }
                    cur.append(w)
                    curW += ww
                } else {
                    if (cur.isNotEmpty()) {
                        out.add(cur.toString())
                        cur.clear()
                    }
                    if (ww > maxWidth) {
                        // Hard wrap mid-word: split on character widths.
                        var buf = StringBuilder()
                        var bufW = 0f
                        for (ch in w) {
                            val cw = paint.measureText(ch.toString())
                            if (bufW + cw > maxWidth && buf.isNotEmpty()) {
                                out.add(buf.toString())
                                buf = StringBuilder()
                                bufW = 0f
                            }
                            buf.append(ch); bufW += cw
                        }
                        if (buf.isNotEmpty()) {
                            cur.append(buf)
                            curW = bufW
                        }
                    } else {
                        cur.append(w)
                        curW = ww
                    }
                }
            }
            if (cur.isNotEmpty()) out.add(cur.toString())
        }
        return out
    }

    @Suppress("unused")
    private fun clamp(v: Float, lo: Float, hi: Float) = max(lo, min(hi, v))
}
