package com.dia.app.pilot.tool.impl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Read or write the system clipboard.
 *
 * Note: Android Q+ restricts clipboard reads to the foreground IME or focused
 * window. We attempt the read directly via the ClipboardManager — if the OS
 * blocks us, we return a clear error message rather than failing silently.
 */
class ClipboardTool : BaseTool() {

    override fun getName(): String = "clipboard"

    override fun getDescription(): String =
        "Get or set the system clipboard. action='get' reads, action='set' writes."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("action", "string", "'get' to read or 'set' to write", true),
        ToolParameter("text", "string", "Text to write (required when action='set')", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        val service = requireAccessibilityService()
            ?: return ToolResult.error("Accessibility service is not running")
        val ctx = service.applicationContext
        val action = requireString(params, "action").lowercase().trim()

        return when (action) {
            "get" -> readClipboard(ctx)
            "set" -> {
                val text = requireString(params, "text")
                writeClipboard(ctx, text)
            }
            else -> ToolResult.error("Unknown action '$action' — use 'get' or 'set'")
        }
    }

    private fun readClipboard(ctx: Context): ToolResult {
        val latch = CountDownLatch(1)
        var resultText: String? = null
        var errorMessage: String? = null

        Handler(Looper.getMainLooper()).post {
            try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                resultText = if (clip != null && clip.itemCount > 0) {
                    clip.getItemAt(0).coerceToText(ctx)?.toString()
                } else null
            } catch (e: Exception) {
                errorMessage = e.message
            }
            latch.countDown()
        }

        return try {
            if (!latch.await(2, TimeUnit.SECONDS)) {
                ToolResult.error("Clipboard read timed out")
            } else if (errorMessage != null) {
                ToolResult.error(
                    "Could not read clipboard: $errorMessage. " +
                        "Android restricts clipboard access; ensure Dia is in the foreground."
                )
            } else if (resultText.isNullOrEmpty()) {
                ToolResult.success("Clipboard is empty.")
            } else {
                ToolResult.success(resultText!!.take(2000))
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            ToolResult.error("Interrupted")
        }
    }

    private fun writeClipboard(ctx: Context, text: String): ToolResult {
        val latch = CountDownLatch(1)
        var ok = false
        Handler(Looper.getMainLooper()).post {
            try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("dia_clipboard", text))
                ok = true
            } catch (_: Exception) {}
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
        return if (ok) ToolResult.success("Copied to clipboard: ${text.take(80)}")
        else ToolResult.error("Failed to write to clipboard")
    }
}
