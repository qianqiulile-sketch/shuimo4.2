package com.dia.app.navigation

/**
 * 路由。对话（ChatRoute）是唯一的主界面，其它页面都从对话里的「百宝箱」进入，
 * 完成后回到对话。
 */
data object OnboardingRoute
data object ChatRoute
data object SettingsRoute
data object ModelSetupRoute
data object BubbleRoute
data object LensLiveRoute
data object LensThinkRoute
data object LensTranslateRoute
data object LensGuideRoute
data object PilotRoute
data object GuideRoute
/** Slate landing screen (notebook picker + sub-mode chooser). */
data object SlateRoute
/** Open a specific notebook by id. */
data class SlateNotebookRoute(val notebookId: String)
/** Quiz mode landing. */
data object SlateQuizRoute
/** 智能家居（Home Assistant）。 */
data object HomeModeRoute
/** 4.0：自主长思（列表；带 id 时打开某个长思）。 */
data class DeepRoute(val sessionId: String? = null)
/** 4.0：AI 专属文件夹。 */
data object AiFolderRoute
/** 4.0：主题与图标。 */
data object ThemeRoute
