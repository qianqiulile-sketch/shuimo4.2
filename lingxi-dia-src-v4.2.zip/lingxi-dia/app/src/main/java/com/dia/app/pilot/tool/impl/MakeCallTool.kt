package com.dia.app.pilot.tool.impl

import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.provider.ContactsContract
import android.view.accessibility.AccessibilityNodeInfo
import com.dia.app.DiaAccessibilityService
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult
import java.util.Locale

/**
 * Place a phone call to a contact name or number.
 *
 * Flow:
 *   1. Resolve contact → number via ContactsContract.
 *   2. Fire ACTION_DIAL (no permission needed) — this opens the dialer with
 *      the number prefilled.
 *   3. Wait for the dialer window to come up.
 *   4. Tap the dialer's "call" / "dial" / phone-icon button via accessibility.
 *
 * Step 4 is the bit that the original PokeClaw tool delegates to the user.
 * For demo reliability we automate it — same as Google Assistant's "call X"
 * flow.
 */
class MakeCallTool : BaseTool() {

    override fun getName(): String = "make_call"

    override fun getDescription(): String =
        "Place a phone call by contact name or phone number. Looks up the contact in " +
            "the phone book, opens the dialer, and presses the call button."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("contact", "string", "Contact name (e.g. 'Mom') or phone number", true),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        val service = requireAccessibilityService()
            ?: return ToolResult.error("Accessibility service is not running")
        val ctx = service.applicationContext
        val contact = requireString(params, "contact").trim()
        if (contact.isEmpty()) return ToolResult.error("Contact name or phone number required")

        val numberRegex = Regex("[\\d\\s\\-+()]{7,}")
        val numberToDial = if (numberRegex.matches(contact)) {
            contact.replace(Regex("[\\s\\-()]"), "")
        } else {
            lookupContact(ctx, contact)
                ?: return ToolResult.error(
                    "Contact '$contact' not found in your phone book. Provide the number directly."
                )
        }

        // Step 1 — fire dialer
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$numberToDial"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        } catch (e: Exception) {
            return ToolResult.error("Failed to open dialer: ${e.message}")
        }

        // Step 2 — wait for the dialer window to focus
        if (!waitForDialer(service, 4000)) {
            return ToolResult.error("Dialer did not open. Number is filled in but not dialed.")
        }
        Thread.sleep(500)

        // Step 3 — tap the call button
        val pressed = pressCallButton(service)
        return if (pressed) {
            ToolResult.success("Calling $contact ($numberToDial)…")
        } else {
            ToolResult.success(
                "Dialer opened for $contact ($numberToDial) — tap the call button to connect. " +
                    "(Could not auto-press it.)"
            )
        }
    }

    private fun lookupContact(ctx: android.content.Context, name: String): String? {
        return try {
            val resolver = ctx.contentResolver
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("%$name%")

            resolver.query(uri, projection, selection, args, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: SecurityException) {
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun waitForDialer(service: DiaAccessibilityService, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val root = service.rootInActiveWindow
            val pkg = root?.packageName?.toString().orEmpty()
            // Generic dialer detection — any Google / OEM dialer package.
            if (pkg.contains("dialer", true) ||
                pkg.contains("phone", true) ||
                pkg.contains("incallui", true) ||
                pkg.contains("contacts", true)
            ) return true
            Thread.sleep(300)
        }
        return false
    }

    /**
     * Find and click the dialer's call button. Strategy:
     *   1. Look for a clickable node whose contentDescription contains
     *      "call" / "dial" but NOT "video" / "speaker" / "mute".
     *   2. Prefer the one in the bottom half of the screen (call button is
     *      always centered near the bottom in every dialer UI).
     */
    private fun pressCallButton(service: DiaAccessibilityService): Boolean {
        val root = service.rootInActiveWindow ?: return false
        val all = mutableListOf<AccessibilityNodeInfo>()
        collectAll(root, all)

        val dm = service.resources.displayMetrics
        val midY = dm.heightPixels / 2

        val candidates = all.filter { node ->
            if (!node.isClickable) return@filter false
            val combined = labelOf(node)
            val isCallish = combined.contains("call") || combined.contains("dial")
            if (!isCallish) return@filter false
            val isExcluded = listOf("video", "speaker", "mute", "hold", "add", "merge", "history",
                "reject", "decline", "end", "back", "delete")
                .any { combined.contains(it) }
            !isExcluded
        }

        // Pick the bottom-half candidate first.
        val bottom = candidates.firstOrNull {
            val r = Rect(); it.getBoundsInScreen(r); r.centerY() > midY
        } ?: candidates.firstOrNull()

        if (bottom != null) {
            val clicked = try {
                bottom.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } catch (_: Exception) { false }
            if (clicked) return true
            val r = Rect().apply { bottom.getBoundsInScreen(this) }
            if (r.width() > 0 && r.height() > 0) {
                return service.performTap(r.centerX(), r.centerY())
            }
        }
        return false
    }

    private fun labelOf(node: AccessibilityNodeInfo): String {
        val text = node.text?.toString()?.lowercase(Locale.US).orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase(Locale.US).orEmpty()
        return "$text|$desc"
    }

    private fun collectAll(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectAll(child, out)
        }
    }
}
