package com.dia.app.agent

import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import com.dia.app.web.WebReader
import com.dia.app.web.WebSearch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

/**
 * 分步思考（Step Thinking）。
 *
 * 1. 预检索：先联网搜一下总问题，帮助拆得更准（可关）
 * 2. 拆解：把问题拆成若干相互独立的小问题；小问题仍然复杂就继续拆，逐层递进
 * 3. 求解：叶子问题逐个解决（需要时联网查资料）。无极模式下多个「分身」并行求解 = 分布式思考
 * 4. 归纳：子问题答案自下而上汇总成上一层的结论
 * 5. 会审（无极）：一个「挑刺者」检查整份研究笔记的漏洞与矛盾
 *
 * 结果是一份结构化的「研究笔记」，交给主 Agent 写最终回答（主 Agent 仍可继续调用工具去执行）。
 * 以牺牲速度换取复杂问题的深度和准确度。
 */
object StepThinker {

    class Node(val q: String, val depth: Int, val label: String) {
        @Volatile var status: String = "待解"
        @Volatile var answer: String = ""
        var needSearch: Boolean = false
        var complex: Boolean = false
        val children = ArrayList<Node>()
    }

    /** 进度回调：标题 + 思考树（可展开）。 */
    fun interface Progress {
        fun update(title: String, tree: String, done: Boolean)
    }

    data class Result(val notes: String, val tree: String, val leaves: Int, val calls: Int)

    /** 给用户审阅 / 修改的一条小问题（depth 从 1 开始，2 表示上一条的子问题）。 */
    data class StepItem(val depth: Int, val text: String, val search: Boolean = false)

    /** 把思考树摊平成可编辑的列表（不含根）。 */
    fun flatten(root: Node): List<StepItem> {
        val out = ArrayList<StepItem>()
        fun walk(n: Node) {
            for (c in n.children) {
                out.add(StepItem(c.depth.coerceAtLeast(1), c.q, c.needSearch))
                walk(c)
            }
        }
        walk(root)
        return out
    }

    /** 用用户修改后的列表重建思考树（缩进最多比上一条深一层）。 */
    fun rebuild(root: Node, items: List<StepItem>, web: Boolean) {
        root.children.clear()
        val stack = ArrayList<Node>()
        stack.add(root)
        for (item in items) {
            val text = item.text.trim()
            if (text.isEmpty()) continue
            val d = item.depth.coerceIn(1, stack.size)
            while (stack.size > d) stack.removeAt(stack.lastIndex)
            val parent = stack.last()
            val label = if (parent === root) "${parent.children.size + 1}" else "${parent.label}.${parent.children.size + 1}"
            val n = Node(text, d, label)
            n.needSearch = item.search && web
            parent.children.add(n)
            stack.add(n)
        }
    }

    private val COMPLEX_WORDS = listOf(
        "分析", "比较", "对比", "为什么", "为何", "如何", "怎么做", "怎样", "方案", "规划", "计划", "研究", "调研", "报告", "评估", "优缺点", "利弊",
        "原理", "策略", "建议", "影响", "趋势", "预测", "总结", "综述", "论文", "步骤", "设计", "全面", "详细", "深入", "区别", "选哪", "推荐", "攻略", "路线",
        "解释", "论证", "可行性", "风险", "复盘", "梳理", "体系", "框架", "大纲", "规律", "机制", "演变", "历史",
    )
    private val ACTION_WORDS = listOf("打开", "点击", "发消息", "发给", "打电话", "画", "生成图", "翻译这", "记住", "提醒", "播放", "关掉", "开灯", "关灯", "/")

    /** 启发式判断这个问题值不值得分步思考（不额外花一次模型调用）。 */
    fun shouldUse(text: String, wuji: Boolean): Boolean {
        val mode = DiaSettings.stepThinking.value
        val t = text.trim()
        if (t.length < 6 || mode == "off" && !wuji) return false
        if (mode == "on") return true
        if (ACTION_WORDS.any { t.startsWith(it) } && t.length < 40) return false
        val hits = COMPLEX_WORDS.count { t.contains(it) }
        val qMarks = t.count { it == '？' || it == '?' }
        return when {
            wuji -> (hits >= 1 && t.length >= 10) || t.length >= 50 || qMarks >= 2
            else -> (hits >= 1 && t.length >= 18) || (hits >= 2) || t.length >= 90 || qMarks >= 3
        }
    }

    // ───────── 主流程 ─────────

    suspend fun think(
        question: String,
        background: String,
        progress: Progress,
        wuji: Boolean = DiaSettings.wujiMode.value,
        /** 拆解完成后交给用户审阅（null = 不审阅） */
        review: (suspend (List<StepItem>) -> List<StepItem>?)? = null,
    ): Result {
        val cloud = LlmGateway.canParallel()
        val maxDepth = DiaSettings.stepMaxDepth.value.coerceIn(1, 4).let { if (!cloud && !wuji) minOf(it, 2) else it }
        val branch = DiaSettings.stepMaxBranch.value.coerceIn(2, 6)
        val leafCap = when {
            wuji && cloud -> 36
            wuji -> 16
            cloud -> 20
            else -> 8
        }
        val web = DiaSettings.webEnabled.value || wuji
        val workers = if (wuji && cloud) DiaSettings.wujiWorkers.value.coerceIn(1, 6) else 1
        val calls = AtomicInteger(0)
        val root = Node(question, 0, "总")
        val title = if (wuji) "无极 · 分布式思考" else "分步思考"

        fun render(done: Boolean = false) {
            progress.update(
                "$title · ${countLeaves(root)} 个小问题 · 已解 ${countDone(root)}" + if (done) " · 完成" else "",
                renderTree(root),
                done,
            )
        }

        // ① 预检索
        var bg = background
        if (web && DiaSettings.stepPreSearch.value) {
            root.status = "预检索"
            render()
            val pre = searchSnippets(question, 5, readTop = false)
            if (pre.isNotBlank()) bg = (bg + "\n【预检索资料】\n" + pre).trim()
        }

        // ② 逐层拆解（广度优先，受叶子总数限制）
        root.status = "拆解中"
        render()
        var frontier = listOf(root)
        for (depth in 0 until maxDepth) {
            val next = ArrayList<Node>()
            for (n in frontier) {
                if (depth > 0 && !n.complex) continue
                if (countLeaves(root) + branch - 1 > leafCap && depth > 0) continue
                n.status = "拆解中"
                render()
                val subs = decompose(root.q, n, bg, branch, maxDepth, calls)
                if (subs.isEmpty()) { n.status = "待解"; continue }
                for ((i, s) in subs.withIndex()) {
                    val child = Node(s.first, depth + 1, if (n === root) "${i + 1}" else "${n.label}.${i + 1}")
                    child.complex = s.second && depth + 1 < maxDepth
                    child.needSearch = s.third && web
                    n.children.add(child)
                    next.add(child)
                }
                n.status = "已拆解"
                render()
            }
            if (next.isEmpty()) break
            frontier = next
        }
        if (root.children.isEmpty()) {
            // 拆不开：整体当作一个小问题求解
            root.children.add(Node(question, 1, "1").also { it.needSearch = web })
        }

        // ②½ 用户审阅：可以改写、增删、调整小问题，确认后再求解
        if (review != null && DiaSettings.stepReview.value != "off") {
            root.status = "待审阅"
            render()
            val edited = review(flatten(root))
            if (edited != null && edited.any { it.text.isNotBlank() }) rebuild(root, edited, web)
            root.status = "求解中"
            render()
        }

        // ③ 求解叶子（无极 + 云端：多个分身并行）
        val leaves = collectLeaves(root)
        val gate = Semaphore(workers)
        val done = AtomicInteger(0)
        coroutineScope {
            leaves.map { leaf ->
                async {
                    gate.withPermit {
                        leaf.status = "求解中"
                        render()
                        val siblingsKnown = if (workers == 1) knownSoFar(root, leaf) else ""
                        leaf.answer = solveLeaf(root.q, leaf, bg, siblingsKnown, wuji, calls)
                        leaf.status = "✓"
                        done.incrementAndGet()
                        render()
                    }
                }
            }.awaitAll()
        }

        // ④ 自下而上归纳中间层
        synthesizeUp(root, root.q, calls) { render() }

        // ⑤ 会审（无极）
        var review = ""
        if (wuji) {
            root.status = "会审中"
            render()
            review = critique(root, calls)
        }
        root.status = "✓"
        render(done = true)

        val notes = buildString {
            append("【分步思考研究笔记】（共 ${leaves.size} 个小问题，供你写最终回答；请综合、去重、解决矛盾，不要逐条照抄）\n")
            append(renderNotes(root))
            if (review.isNotBlank()) append("\n【会审意见】\n").append(review).append('\n')
        }
        return Result(notes, renderTree(root), leaves.size, calls.get())
    }

    /** 作为工具被 AI 主动调用。 */
    suspend fun asTool(question: String, host: ToolHost): ToolOutcome {
        if (question.isBlank()) return ToolOutcome("缺少问题 question", ok = false)
        var lastTree = ""
        val r = think(question, "", { title, tree, _ ->
            lastTree = tree
            host.progress(title)
        })
        return ToolOutcome(
            forModel = r.notes.take((LlmGateway.promptCharBudget() / 2).coerceAtLeast(2000)),
            display = lastTree,
        )
    }

    // ───────── 各步骤 ─────────

    private suspend fun decompose(rootQ: String, node: Node, bg: String, branch: Int, maxDepth: Int, calls: AtomicInteger): List<Triple<String, Boolean, Boolean>> {
        val system = "你是擅长拆解问题的研究规划师，思路清晰、覆盖全面、不重复。只输出 JSON。"
        val prompt = buildString {
            append("【总问题】").append(rootQ).append('\n')
            if (node.depth > 0) append("【当前要拆的问题】").append(node.q).append("（第 ${node.depth + 1}/$maxDepth 层）\n")
            if (bg.isNotBlank()) append("【背景资料】\n").append(bg.take(2500)).append('\n')
            append("\n请把").append(if (node.depth > 0) "当前问题" else "总问题").append("拆成 2~$branch 个子问题：\n")
            append("- 每个子问题都能单独回答，合起来能完整解决它；按解决顺序排列；不要空泛、不要重复。\n")
            append("- complex：子问题仍然很复杂、值得再拆，就为 true。\n")
            append("- search：需要联网查最新或具体事实（数据、价格、政策、新闻、版本…）就为 true。\n")
            append("- 如果它已经足够简单、能直接回答，返回 {\"subs\":[]}。\n")
            append("只输出：{\"subs\":[{\"q\":\"子问题\",\"complex\":false,\"search\":true}]}")
        }
        calls.incrementAndGet()
        val out = try {
            LlmGateway.complete(system = system, prompt = prompt, temperature = 0.3)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            return emptyList()
        }
        return parseSubs(out, branch)
    }

    /** 解析拆解结果：优先 JSON，失败时退回逐行列表。 */
    fun parseSubs(out: String, branch: Int): List<Triple<String, Boolean, Boolean>> {
        val list = ArrayList<Triple<String, Boolean, Boolean>>()
        val objStart = out.indexOf("{\"subs\"").let { if (it < 0) out.indexOf("{") else it }
        if (objStart >= 0) {
            val json = ToolCallParser.firstJsonObject(out.substring(objStart))
            if (json != null) {
                try {
                    val arr = JSONObject(json).optJSONArray("subs")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i)
                            if (o != null) {
                                val q = o.optString("q").ifBlank { o.optString("question") }.trim()
                                if (q.isNotBlank()) list.add(Triple(q, o.optBoolean("complex", false), o.optBoolean("search", false)))
                            } else {
                                arr.optString(i).trim().takeIf { it.isNotBlank() }?.let { list.add(Triple(it, false, false)) }
                            }
                        }
                        return list.distinctBy { it.first }.take(branch)
                    }
                } catch (_: Exception) { }
            }
        }
        for (line in out.lines()) {
            val m = Regex("^\\s*(?:\\d{1,2}[.、)）]|[-*•])\\s*(.+)$").find(line) ?: continue
            val q = m.groupValues[1].trim().trim('"')
            if (q.length >= 4) list.add(Triple(q, false, q.contains("最新") || q.contains("现在") || q.contains("价格")))
        }
        return list.distinctBy { it.first }.take(branch)
    }

    private suspend fun searchSnippets(q: String, n: Int, readTop: Boolean): String = withContext(Dispatchers.IO) {
        try {
            val r = WebSearch.search(q, n)
            if (r.hits.isEmpty()) return@withContext ""
            val sb = StringBuilder()
            for ((i, h) in r.hits.withIndex()) sb.append("[${i + 1}] ${h.title}：${h.snippet.take(220)}（${h.url}）\n")
            if (readTop) {
                for (h in r.hits.take(1)) {
                    try {
                        val p = WebReader.read(h.url, 1800)
                        if (p.text.isNotBlank()) sb.append("\n【${h.title} 正文摘录】\n").append(p.text).append('\n')
                    } catch (_: Exception) { }
                }
            }
            sb.toString().trim()
        } catch (_: Exception) {
            ""
        }
    }

    private suspend fun solveLeaf(rootQ: String, leaf: Node, bg: String, known: String, wuji: Boolean, calls: AtomicInteger): String {
        val evidence = if (leaf.needSearch) searchSnippets(leaf.q, if (wuji) 5 else 4, readTop = wuji) else ""
        val system = "你是严谨的研究员，只回答被分配的这个小问题：准确、具体、有依据；资料不足时说明不确定之处，不编造数据。"
        val prompt = buildString {
            append("【总问题】").append(rootQ).append('\n')
            append("【你负责的小问题 ${leaf.label}】").append(leaf.q).append('\n')
            if (known.isNotBlank()) append("【前面已得出的结论】\n").append(known.take(1500)).append('\n')
            if (evidence.isNotBlank()) append("【检索资料】\n").append(evidence.take(4000)).append('\n')
            else if (bg.isNotBlank()) append("【背景资料】\n").append(bg.take(1800)).append('\n')
            append("\n请直接给出这个小问题的答案（").append(if (wuji) "300" else "200").append(" 字以内，要点式，引用资料用 [序号]）：")
        }
        calls.incrementAndGet()
        return try {
            LlmGateway.complete(system = system, prompt = prompt, temperature = 0.4, thinking = wuji).trim()
                .replace(Regex("<think>[\\s\\S]*?</think>"), "").trim().ifBlank { "（未得出结论）" }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            "（求解失败：${e.message}）"
        }
    }

    private suspend fun synthesizeUp(node: Node, rootQ: String, calls: AtomicInteger, onStep: () -> Unit) {
        for (c in node.children) synthesizeUp(c, rootQ, calls, onStep)
        if (node.depth == 0 || node.children.isEmpty()) return
        node.status = "归纳中"
        onStep()
        val prompt = buildString {
            append("【总问题】").append(rootQ).append('\n')
            append("【要回答的问题 ${node.label}】").append(node.q).append('\n')
            append("【子问题的结论】\n")
            for (c in node.children) append("- ").append(c.q).append("：").append(c.answer.take(600)).append('\n')
            append("\n综合以上结论，给出这个问题的完整答案（250 字以内，要点式，保留关键数据与来源序号）：")
        }
        calls.incrementAndGet()
        node.answer = try {
            LlmGateway.complete(system = "你善于归纳总结，去重、理清逻辑、点出关键结论。", prompt = prompt, temperature = 0.3).trim()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            node.children.joinToString("\n") { "· " + it.answer.take(200) }
        }
        node.status = "✓"
        onStep()
    }

    private suspend fun critique(root: Node, calls: AtomicInteger): String {
        calls.incrementAndGet()
        return try {
            LlmGateway.complete(
                system = "你是江湖上最挑剔的「挑刺者」：专门找研究笔记里的事实错误、逻辑漏洞、相互矛盾和重要遗漏。",
                prompt = "【总问题】${root.q}\n\n${renderNotes(root).take(8000)}\n\n请列出需要修正或补充的地方（最多 5 条，每条一句话）；如果没有明显问题，只回答「无」。",
                temperature = 0.3,
            ).trim().let { if (it == "无" || it.length < 3) "" else it }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            ""
        }
    }

    // ───────── 树工具 ─────────

    private fun collectLeaves(n: Node): List<Node> =
        if (n.children.isEmpty()) listOf(n) else n.children.flatMap { collectLeaves(it) }

    private fun countLeaves(n: Node): Int = if (n.children.isEmpty()) (if (n.depth == 0) 0 else 1) else n.children.sumOf { countLeaves(it) }

    private fun countDone(n: Node): Int = if (n.children.isEmpty()) (if (n.status == "✓" && n.depth > 0) 1 else 0) else n.children.sumOf { countDone(it) }

    /** 顺序求解时，把排在前面、已解出的兄弟结论带给后面的小问题。 */
    private fun knownSoFar(root: Node, leaf: Node): String {
        val sb = StringBuilder()
        for (l in collectLeaves(root)) {
            if (l === leaf) break
            if (l.answer.isNotBlank()) sb.append("· ").append(l.q).append("：").append(l.answer.take(240)).append('\n')
        }
        return sb.toString()
    }

    fun renderTree(root: Node): String {
        val sb = StringBuilder()
        sb.append("🧭 ").append(root.q.take(60)).append("  〔").append(root.status).append("〕\n")
        fun walk(n: Node, prefix: String) {
            for ((i, c) in n.children.withIndex()) {
                val last = i == n.children.lastIndex
                val icon = when (c.status) {
                    "✓" -> "✓"
                    "求解中", "拆解中", "归纳中" -> "⏳"
                    "已拆解" -> "◇"
                    else -> "○"
                }
                sb.append(prefix).append(if (last) "└─ " else "├─ ").append(icon).append(' ').append(c.label).append(' ')
                    .append(c.q.take(48)).append(if (c.needSearch) " 🔍" else "").append('\n')
                if (c.answer.isNotBlank() && c.children.isEmpty()) {
                    sb.append(prefix).append(if (last) "    " else "│  ").append("   ↳ ").append(c.answer.replace('\n', ' ').take(90)).append('\n')
                }
                walk(c, prefix + if (last) "    " else "│  ")
            }
        }
        walk(root, "")
        return sb.toString().trimEnd()
    }

    private fun renderNotes(root: Node): String {
        val sb = StringBuilder()
        fun walk(n: Node) {
            for (c in n.children) {
                sb.append("■ ").append(c.label).append(' ').append(c.q).append('\n')
                if (c.answer.isNotBlank()) sb.append(c.answer.trim()).append("\n\n")
                walk(c)
            }
        }
        walk(root)
        return sb.toString().trim()
    }
}
