package com.dia.app.web

/**
 * HTML → 纯文本 / 搜索结果解析（纯 Kotlin，不依赖 Android，可单元测试）。
 */
object HtmlText {

    private val entityMap = mapOf(
        "&nbsp;" to " ", "&amp;" to "&", "&lt;" to "<", "&gt;" to ">", "&quot;" to "\"",
        "&#39;" to "'", "&apos;" to "'", "&ensp;" to " ", "&emsp;" to " ", "&middot;" to "·",
        "&hellip;" to "…", "&mdash;" to "—", "&ndash;" to "–", "&ldquo;" to "“", "&rdquo;" to "”",
        "&lsquo;" to "‘", "&rsquo;" to "’", "&times;" to "×", "&copy;" to "©", "&reg;" to "®",
    )

    fun decodeEntities(s: String): String {
        var t = s
        for ((k, v) in entityMap) t = t.replace(k, v)
        t = Regex("&#(\\d{1,6});").replace(t) { m ->
            val code = m.groupValues[1].toIntOrNull()
            if (code != null && code in 1..0x10FFFF) String(Character.toChars(code)) else m.value
        }
        t = Regex("&#[xX]([0-9a-fA-F]{1,6});").replace(t) { m ->
            val code = m.groupValues[1].toIntOrNull(16)
            if (code != null && code in 1..0x10FFFF) String(Character.toChars(code)) else m.value
        }
        return t
    }

    fun stripTags(s: String): String =
        decodeEntities(s.replace(Regex("<[^>]+>"), "")).replace(Regex("\\s+"), " ").trim()

    /** 把整页 HTML 转成适合给模型阅读的正文。 */
    fun htmlToText(html: String, maxChars: Int = 6000): Pair<String, String> {
        var h = html
        val title = Regex("<title[^>]*>([\\s\\S]*?)</title>", RegexOption.IGNORE_CASE).find(h)
            ?.groupValues?.get(1)?.let { stripTags(it) }.orEmpty()
        // 去掉不可见部分
        for (tag in listOf("script", "style", "noscript", "svg", "head", "template", "iframe")) {
            h = h.replace(Regex("<$tag[\\s\\S]*?</$tag>", RegexOption.IGNORE_CASE), " ")
        }
        h = h.replace(Regex("<!--[\\s\\S]*?-->"), " ")
        // 优先取正文区域
        val main = listOf("article", "main").firstNotNullOfOrNull { tag ->
            Regex("<$tag[^>]*>([\\s\\S]*?)</$tag>", RegexOption.IGNORE_CASE).find(h)?.groupValues?.get(1)
                ?.takeIf { stripTags(it).length > 200 }
        }
        if (main != null) h = main
        // 去掉导航 / 页脚
        for (tag in listOf("nav", "footer", "header", "aside", "form")) {
            h = h.replace(Regex("<$tag[\\s\\S]*?</$tag>", RegexOption.IGNORE_CASE), " ")
        }
        h = h.replace(Regex("<(br|/p|/div|/li|/h[1-6]|/tr|/section|/article)[^>]*>", RegexOption.IGNORE_CASE), "\n")
        h = h.replace(Regex("<li[^>]*>", RegexOption.IGNORE_CASE), "\n• ")
        h = h.replace(Regex("<[^>]+>"), "")
        h = decodeEntities(h)
        val lines = h.split('\n')
            .map { it.replace(Regex("[ \\t\\u00A0\\u3000]+"), " ").trim() }
            .filter { it.length > 1 }
        val sb = StringBuilder()
        var lastBlank = false
        for (l in lines) {
            if (l.isEmpty()) { if (!lastBlank) sb.append('\n'); lastBlank = true; continue }
            sb.append(l).append('\n')
            lastBlank = false
            if (sb.length > maxChars) break
        }
        return title to sb.toString().take(maxChars).trim()
    }

    /** 在 HTML 头部找 charset（中文网站很多是 GBK）。 */
    fun sniffCharset(headBytes: ByteArray): String? {
        val head = String(headBytes, Charsets.ISO_8859_1)
        val m = Regex("charset\\s*=\\s*[\"']?([A-Za-z0-9_\\-]+)", RegexOption.IGNORE_CASE).find(head)
        return m?.groupValues?.get(1)
    }

    data class Hit(val title: String, val url: String, val snippet: String)

    /** 解析 Bing（cn.bing.com / www.bing.com）结果页。 */
    fun parseBing(html: String): List<Hit> {
        val out = ArrayList<Hit>()
        val blocks = html.split(Regex("<li class=\"b_algo\"")).drop(1)
        for (raw in blocks) {
            val b = raw.substringBefore("</li>\n<li class=").let { if (it.length > 8000) it.take(8000) else it }
            val a = Regex("<h2[^>]*>\\s*<a[^>]*href=\"([^\"]+)\"[^>]*>([\\s\\S]*?)</a>", RegexOption.IGNORE_CASE).find(b)
                ?: continue
            val url = decodeBingUrl(decodeEntities(a.groupValues[1]))
            val title = stripTags(a.groupValues[2])
            val snip = Regex("<p[^>]*>([\\s\\S]*?)</p>", RegexOption.IGNORE_CASE).find(b)?.groupValues?.get(1)
                ?: Regex("class=\"b_caption\"[^>]*>([\\s\\S]*?)</div>", RegexOption.IGNORE_CASE).find(b)?.groupValues?.get(1)
                ?: ""
            if (title.isNotBlank() && url.startsWith("http")) out.add(Hit(title, url, stripTags(snip).take(300)))
        }
        return out
    }

    /** Bing 的跳转链接 …/ck/a?…&u=a1<base64url> → 真实地址。 */
    fun decodeBingUrl(url: String): String {
        if (!url.contains("bing.com/ck/a")) return url
        val u = Regex("[?&]u=([^&]+)").find(url)?.groupValues?.get(1) ?: return url
        val enc = if (u.startsWith("a1")) u.substring(2) else u
        return try {
            val padded = enc + "=".repeat((4 - enc.length % 4) % 4)
            val bytes = java.util.Base64.getUrlDecoder().decode(padded)
            val s = String(bytes, Charsets.UTF_8)
            if (s.startsWith("http")) s else url
        } catch (_: Exception) {
            url
        }
    }

    /** 解析 DuckDuckGo HTML 版（html.duckduckgo.com/html）。 */
    fun parseDuckDuckGo(html: String): List<Hit> {
        val out = ArrayList<Hit>()
        val linkRe = Regex("<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>([\\s\\S]*?)</a>", RegexOption.IGNORE_CASE)
        val linkRe2 = Regex("<a[^>]*href=\"([^\"]+)\"[^>]*class=\"result__a\"[^>]*>([\\s\\S]*?)</a>", RegexOption.IGNORE_CASE)
        val snipRe = Regex("class=\"result__snippet\"[^>]*>([\\s\\S]*?)</(?:a|td|div)>", RegexOption.IGNORE_CASE)
        val blocks = html.split(Regex("class=\"result results_links")).drop(1)
        for (b in blocks) {
            val a = linkRe.find(b) ?: linkRe2.find(b) ?: continue
            var url = decodeEntities(a.groupValues[1])
            val uddg = Regex("[?&]uddg=([^&]+)").find(url)?.groupValues?.get(1)
            if (uddg != null) url = java.net.URLDecoder.decode(uddg, "UTF-8")
            if (url.startsWith("//")) url = "https:$url"
            val title = stripTags(a.groupValues[2])
            val snip = snipRe.find(b)?.groupValues?.get(1)?.let { stripTags(it) }.orEmpty()
            if (title.isNotBlank() && url.startsWith("http") && !url.contains("duckduckgo.com/y.js")) {
                out.add(Hit(title, url, snip.take(300)))
            }
        }
        return out
    }
}
