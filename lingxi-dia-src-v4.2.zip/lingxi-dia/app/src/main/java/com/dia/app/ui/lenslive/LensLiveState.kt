package com.dia.app.ui.lenslive

/**
 * UI state for the Lens Live realtime camera screen.
 */
sealed interface LensLiveUiState {
    data object Initializing : LensLiveUiState
    /** Camera is live; waiting for user action */
    data object Scanning : LensLiveUiState
    /** AI is analyzing (deep-think, translate, or guide) */
    data class Thinking(val mode: ThinkMode) : LensLiveUiState
    /** AI response is being spoken */
    data class Speaking(val responseText: String) : LensLiveUiState
    /** Guide mode: listening for user voice input via mic */
    data object Listening : LensLiveUiState
    /** Guide mode: conversational back-and-forth active */
    data class Conversing(val userPrompt: String) : LensLiveUiState
    data class Error(val message: String) : LensLiveUiState
}

enum class ThinkMode { AUTO, DEEP, TRANSLATE, GUIDE }

/**
 * The active Lens mode selected via bottom tab bar.
 */
enum class LensTab { THINK, TRANSLATE, GUIDE }

/**
 * A single entry in the conversation transcript.
 */
data class TranscriptEntry(
    val role: String,       // "user" or "assistant"
    val text: String,
    val meta: String = "",  // e.g. "auto", "deep", "translate", "guide"
)
