package com.dia.app.voice

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

/**
 * 语音转文字（对话里点麦克风说一句话）。
 *
 * 用户说话 → 转成文字 → 当作普通文字消息发给 AI → AI 用文字回复（语音对话模式下再朗读）。
 * 4.0 支持四种引擎（设置 → 语音转文字）：
 *  - vosk  ：嵌入式离线模型，边说边出字，完全离线（下载模型后默认使用）
 *  - system：系统语音识别
 *  - cloud ：录完一句上传云端 Whisper 转写
 *  - gemma ：录完一句交给本机 Gemma 听写
 * 只在用户按下麦克风时识别一句话，说完（停顿约 1.5 秒或点 ✓）即停。
 */
class SpeechInput(private val context: Context) {

    enum class State { IDLE, LISTENING, PROCESSING }

    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    /** 0..1 的音量，用来画声波。 */
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    /** 本次使用的引擎（界面上显示「离线模型 / 系统识别…」）。 */
    private val _engine = MutableStateFlow("")
    val engine: StateFlow<String> = _engine.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var onResult: ((String) -> Unit)? = null
    private var onError: ((String) -> Unit)? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var recordJob: Job? = null
    @Volatile private var stopRequested = false

    private fun systemAvailable(): Boolean = try {
        SpeechRecognizer.isRecognitionAvailable(context) ||
            (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context))
    } catch (_: Exception) {
        false
    }

    /** 有没有任何一种可用的语音转文字方式。 */
    fun isAvailable(): Boolean = Transcriber.micEngine(context, systemAvailable()) != "none"

    private fun create(): SpeechRecognizer? = try {
        when {
            SpeechRecognizer.isRecognitionAvailable(context) -> SpeechRecognizer.createSpeechRecognizer(context)
            Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context) ->
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            else -> null
        }
    } catch (e: Exception) {
        Log.w("SpeechInput", "create failed: ${e.message}")
        null
    }

    /** 开始听一句话。必须在主线程调用。 */
    fun start(language: String, onResult: (String) -> Unit, onError: (String) -> Unit) {
        cancel()
        this.onResult = onResult
        this.onError = onError
        _partial.value = ""
        when (val e = Transcriber.micEngine(context, systemAvailable())) {
            "system" -> startSystem(language)
            "vosk", "cloud", "gemma" -> startRecorder(e)
            else -> { finish(); onError("没有可用的语音识别：请在 设置 → 语音转文字 下载离线模型（约 42MB）") }
        }
    }

    // ───────── 系统语音识别 ─────────

    private fun startSystem(language: String) {
        val r = create() ?: run { val eb = onError; finish(); eb?.invoke("这台手机没有可用的语音识别服务"); return }
        recognizer = r
        _engine.value = Transcriber.engineLabel("system")
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _state.value = State.LISTENING }
            override fun onBeginningOfSpeech() { _state.value = State.LISTENING }
            override fun onRmsChanged(rmsdB: Float) { _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { _state.value = State.PROCESSING; _level.value = 0f }
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "没有听清，请再说一遍"
                    SpeechRecognizer.ERROR_AUDIO -> "录音出错"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "需要麦克风权限"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "系统语音识别需要联网——可以在 设置 → 语音转文字 下载离线模型"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "语音识别正忙，请稍后"
                    else -> "语音识别失败（$error）"
                }
                val p = _partial.value
                val cb = this@SpeechInput.onResult
                val eb = this@SpeechInput.onError
                finish()
                if (p.isNotBlank() && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                    cb?.invoke(p)
                } else eb?.invoke(msg)
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    .ifBlank { _partial.value }
                val cb = this@SpeechInput.onResult
                val eb = this@SpeechInput.onError
                finish()
                if (text.isNotBlank()) cb?.invoke(text) else eb?.invoke("没有听清，请再说一遍")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    ?.takeIf { it.isNotBlank() }?.let { _partial.value = it }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        _state.value = State.LISTENING
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            val eb = onError
            finish()
            eb?.invoke("无法启动语音识别：${e.message}")
        }
    }

    // ───────── 离线模型（边说边出字）/ 录完再转写（云端、本机大模型） ─────────

    @SuppressLint("MissingPermission")
    private fun startRecorder(engine: String) {
        _engine.value = Transcriber.engineLabel(engine)
        _state.value = State.LISTENING
        stopRequested = false
        val cb = onResult
        val eb = onError
        recordJob = scope.launch {
            val result: Result<String> = withContext(Dispatchers.IO) {
                runCatching { record(engine) }
            }
            val text = result.getOrNull().orEmpty().trim()
            val err = result.exceptionOrNull()
            finish()
            when {
                err is kotlinx.coroutines.CancellationException -> Unit
                err != null -> eb?.invoke(err.message ?: "语音识别失败")
                text.isNotBlank() -> cb?.invoke(text)
                else -> eb?.invoke("没有听清，请再说一遍")
            }
        }
    }

    /** 录一句话（停顿约 1.5 秒自动结束，最长 60 秒），返回识别文字。在 IO 线程运行。 */
    @SuppressLint("MissingPermission")
    private suspend fun record(engine: String): String {
        val rate = 16_000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) throw IllegalStateException("无法打开麦克风")
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192))
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            try { rec.release() } catch (_: Exception) { }
            throw IllegalStateException("麦克风被占用或没有权限")
        }
        val vosk = if (engine == "vosk") {
            withContext(Dispatchers.Main) { _partial.value = "（正在加载离线语音模型…）" }
            VoskModels.recognizer(context, rate.toFloat())
        } else null
        val pcm = ByteArrayOutputStream()
        val pieces = ArrayList<String>()
        val buf = ShortArray(1600) // 0.1 秒
        var heardSpeech = false
        var silentMs = 0L
        var totalMs = 0L
        var noise = 300.0
        try {
            rec.startRecording()
            _partial.value = ""
            while (kotlin.coroutines.coroutineContext.isActive && !stopRequested) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                totalMs += n * 1000L / rate
                // 音量与简单的语音检测（自适应噪声底）
                var sum = 0.0
                for (i in 0 until n) { val v = buf[i].toDouble(); sum += v * v }
                val rms = sqrt(sum / n)
                _level.value = (rms / 3000.0).toFloat().coerceIn(0f, 1f)
                val speaking = rms > noise * 2.2 && rms > 400
                if (!speaking) noise = noise * 0.95 + rms * 0.05
                if (speaking) { heardSpeech = true; silentMs = 0 } else silentMs += n * 1000L / rate

                if (vosk != null) {
                    if (vosk.acceptWaveForm(buf, n)) {
                        VoskModels.parse(vosk.result).text.takeIf { it.isNotBlank() }?.let { pieces.add(it) }
                    } else {
                        val p = VoskModels.parse(vosk.partialResult, "partial").text
                        _partial.value = (pieces + listOfNotNull(p.takeIf { it.isNotBlank() })).joinToString("，")
                    }
                } else {
                    for (i in 0 until n) { val v = buf[i].toInt(); pcm.write(v and 0xff); pcm.write((v shr 8) and 0xff) }
                    _partial.value = "（录音中 ${totalMs / 1000} 秒，说完停顿一下或点 ✓）"
                }
                if (heardSpeech && silentMs >= 1500) break
                if (!heardSpeech && totalMs >= 8000) break
                if (totalMs >= 60_000) break
            }
        } finally {
            try { rec.stop() } catch (_: Exception) { }
            try { rec.release() } catch (_: Exception) { }
            _level.value = 0f
        }
        _state.value = State.PROCESSING
        if (vosk != null) {
            try {
                VoskModels.parse(vosk.finalResult).text.takeIf { it.isNotBlank() }?.let { pieces.add(it) }
            } finally {
                try { vosk.close() } catch (_: Throwable) { }
            }
            return pieces.joinToString("，")
        }
        if (!heardSpeech) return ""
        _partial.value = "（${Transcriber.engineLabel(engine)}识别中…）"
        return Transcriber.transcribePcm(context, pcm.toByteArray(), rate, engine)
    }

    /** 说完了：停止录音，等待最终结果。 */
    fun stop() {
        if (_state.value == State.LISTENING) {
            _state.value = State.PROCESSING
            stopRequested = true
            try { recognizer?.stopListening() } catch (_: Exception) { }
        }
    }

    fun cancel() {
        try { recognizer?.cancel() } catch (_: Exception) { }
        recordJob?.cancel()
        recordJob = null
        finish()
    }

    private fun finish() {
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        onResult = null
        onError = null
        _state.value = State.IDLE
        _level.value = 0f
    }

    fun release() {
        cancel()
        try { scope.cancel() } catch (_: Exception) { }
    }
}
