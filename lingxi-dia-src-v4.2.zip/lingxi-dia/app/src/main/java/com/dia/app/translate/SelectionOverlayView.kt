package com.dia.app.translate

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Full-screen semi-transparent overlay. The user draws a rectangle by dragging.
 * When they lift their finger, [onRegionSelected] fires with the pixel rect.
 *
 * Visual: dark scrim everywhere EXCEPT inside the selection rectangle (which
 * is clear with a bright border — like Samsung Smart Select).
 */
@SuppressLint("ClickableViewAccessibility", "ViewConstructor")
class SelectionOverlayView(
    context: Context,
    private val hintLabel: String = "在目标区域周围画一个矩形",
    private val onRegionSelected: (Rect) -> Unit,
) : FrameLayout(context) {

    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f
    private var isDragging = false

    private val scrimPaint = Paint().apply {
        color = Color.argb(160, 0, 0, 0) // dark semi-transparent
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(255, 0, 212, 255) // Dia accent cyan
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(255, 0, 212, 255)
        style = Paint.Style.FILL
    }

    private val hintText: TextView
    private val fullScreenButton: TextView

    init {
        setWillNotDraw(false)

        hintText = TextView(context).apply {
            text = hintLabel
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(200, 18, 18, 26))
                cornerRadius = dp(12).toFloat()
            }
        }
        val hintLp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
            topMargin = dp(80)
        }
        addView(hintText, hintLp)

        // "Whole screen" shortcut. Tapping skips the rectangle drag and
        // sends the entire window as the crop. Sits under the hint so it's
        // discoverable without crowding the drawing area.
        fullScreenButton = TextView(context).apply {
            text = "✦  使用整个屏幕"
            setTextColor(Color.argb(255, 0, 212, 255))
            textSize = 14f
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.argb(220, 18, 18, 26))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.argb(140, 0, 212, 255))
            }
            isClickable = true
            isFocusable = true
            // Give the button its own touch handler so the whole-overlay
            // ACTION_DOWN doesn't swallow this tap.
            setOnClickListener {
                onRegionSelected(Rect(0, 0, width, height))
            }
        }
        val btnLp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
            topMargin = dp(140)
        }
        addView(fullScreenButton, btnLp)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                endX = event.x
                endY = event.y
                isDragging = true
                hintText.visibility = View.GONE
                fullScreenButton.visibility = View.GONE
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                endX = event.x
                endY = event.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                isDragging = false
                endX = event.x
                endY = event.y
                invalidate()

                // Compute the final rect (ensure left < right, top < bottom)
                val left = minOf(startX, endX).toInt()
                val top = minOf(startY, endY).toInt()
                val right = maxOf(startX, endX).toInt()
                val bottom = maxOf(startY, endY).toInt()

                // Minimum size check — ignore accidental taps
                if (right - left > 50 && bottom - top > 50) {
                    onRegionSelected(Rect(left, top, right, bottom))
                } else {
                    // Too small — show hint again
                    hintText.visibility = View.VISIBLE
                    fullScreenButton.visibility = View.VISIBLE
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()

        if (!isDragging && startX == 0f) {
            // No selection yet — just draw the full scrim
            canvas.drawRect(0f, 0f, w, h, scrimPaint)
            return
        }

        val left = minOf(startX, endX)
        val top = minOf(startY, endY)
        val right = maxOf(startX, endX)
        val bottom = maxOf(startY, endY)

        // Draw scrim around the selection (4 rects)
        canvas.drawRect(0f, 0f, w, top, scrimPaint)           // top
        canvas.drawRect(0f, bottom, w, h, scrimPaint)         // bottom
        canvas.drawRect(0f, top, left, bottom, scrimPaint)    // left
        canvas.drawRect(right, top, w, bottom, scrimPaint)    // right

        // Draw selection border
        val selRect = RectF(left, top, right, bottom)
        canvas.drawRoundRect(selRect, 8f, 8f, borderPaint)

        // Draw corner handles
        val cornerSize = 16f
        // Top-left
        canvas.drawRoundRect(RectF(left - 2, top - 2, left + cornerSize, top + 6), 3f, 3f, cornerPaint)
        canvas.drawRoundRect(RectF(left - 2, top - 2, left + 6, top + cornerSize), 3f, 3f, cornerPaint)
        // Top-right
        canvas.drawRoundRect(RectF(right - cornerSize, top - 2, right + 2, top + 6), 3f, 3f, cornerPaint)
        canvas.drawRoundRect(RectF(right - 6, top - 2, right + 2, top + cornerSize), 3f, 3f, cornerPaint)
        // Bottom-left
        canvas.drawRoundRect(RectF(left - 2, bottom - 6, left + cornerSize, bottom + 2), 3f, 3f, cornerPaint)
        canvas.drawRoundRect(RectF(left - 2, bottom - cornerSize, left + 6, bottom + 2), 3f, 3f, cornerPaint)
        // Bottom-right
        canvas.drawRoundRect(RectF(right - cornerSize, bottom - 6, right + 2, bottom + 2), 3f, 3f, cornerPaint)
        canvas.drawRoundRect(RectF(right - 6, bottom - cornerSize, right + 2, bottom + 2), 3f, 3f, cornerPaint)
    }

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()
}
