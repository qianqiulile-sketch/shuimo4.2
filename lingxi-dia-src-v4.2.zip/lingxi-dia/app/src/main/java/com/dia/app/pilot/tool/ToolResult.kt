package com.dia.app.pilot.tool

data class ToolResult private constructor(
    val isSuccess: Boolean,
    val data: String?,
    val error: String?,
) {
    companion object {
        fun success(data: String): ToolResult = ToolResult(true, data, null)
        fun error(error: String): ToolResult = ToolResult(false, null, error)
    }
}
