package com.dia.app.pilot.tool.impl

import android.view.accessibility.AccessibilityNodeInfo
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class TapNodeTool : BaseTool() {
    override fun getName(): String = "tap_node"

    override fun getDescription(): String = "Tap a UI element by node ID from get_screen_info."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("node_id", "string", "Node ID from get_screen_info, e.g. n3", true),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService() ?: return ToolResult.error("Accessibility service is not running")
            var nodeId = requireString(params, "node_id")
            nodeId = extractNodeId(nodeId)

            // Reject taps on mic / camera / voice-search buttons unless the
            // task explicitly asked for voice. Small models keep picking
            // these because their description contains "search".
            val node = service.getNodeById(nodeId)
            if (node != null && isVoiceOrCameraNode(node)) {
                return ToolResult.error(
                    "Node $nodeId is a voice/camera button (MIC / CAM marker). " +
                        "Tapping it will not search or play a video. " +
                        "Pick a different node — for results pages, tap a video / item title, " +
                        "for searching use search_in_app or input_text + system_key(\"enter\")."
                )
            }

            val coords = service.getNodeCoordinates(nodeId) ?: return ToolResult.error("Node $nodeId not found. Call get_screen_info again.")
            val success = service.performTap(coords[0], coords[1])
            return if (success) ToolResult.success("Tapped node $nodeId at (${coords[0]}, ${coords[1]})")
            else ToolResult.error("Failed to tap node $nodeId")
        } catch (e: Exception) {
            ToolResult.error("Tap node error: ${e.message}")
        }
    }

    private fun isVoiceOrCameraNode(node: AccessibilityNodeInfo): Boolean {
        val text = node.text?.toString()?.lowercase().orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
        val cls = node.className?.toString()?.lowercase().orEmpty()
        val combined = "$text|$desc|$cls"
        // Conservative — only refuse when label clearly says voice/mic/camera.
        // We don't want to refuse a normal "Send" button just because it has
        // "search" in some ancestor.
        val voice = listOf("voice search", "voice", "microphone", " mic ", "speak now", "tap to speak")
        val camera = listOf("camera", "lens icon", "scan", "barcode", "qr code", "image search", "google lens")
        return voice.any { combined.contains(it) } || camera.any { combined.contains(it) }
    }
}
