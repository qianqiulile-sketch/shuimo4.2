package com.dia.app.deep

/**
 * 长思的「交付门」（纯 Kotlin，不依赖 Android，可单元测试）。
 *
 * 解决 v4.1 里最要命的问题：**AI 说「已完成 / 已写入《xx.txt》」，其实什么文件都没写**。
 * 做法参考了几类开源 Agent 的经验：
 *  - smolagents 的 final_answer_checks：最终答案要先过校验函数，过不了就不收
 *  - 「工具回执（tool receipts）」：是否写过文件只认工具层 / 磁盘留下的证据，不认模型自己的说法
 *  - Hermes Agent 的 degeneracy guard：流式输出里出现成片重复行就判定为「复读」并截断
 *  - Manus / open_deep_research：文件即记忆，先落盘再登记
 *
 * 这里只放纯逻辑：
 *  1. [expectedOutputs]：从步骤标题 / 说明里读出这一步**必须产出**的文件（「产出《诗歌初稿.txt》」）
 *  2. [parseOutcome]：严格解析【本步结论】【状态】——没写【状态】不再当作「完成」
 *  3. [LoopDetector] / [collapseRepeats] / [stripEcho]：发现复读、复述提示词，及时截断、清理
 *  4. [quality]：文件内容是不是真的有东西（不是空的、不是占位、不是复读）
 *  5. [cleanContent]：把「只输出文件正文」的回答清理成可以直接写进文件的内容
 */
object DeepGate {

    /** 识别为「文件」的扩展名。 */
    val OUTPUT_EXTS = listOf("txt", "md", "docx", "pptx", "xlsx", "pdf", "csv", "html", "json")

    /** 「产出 / 生成 / 写成…」：后面的文件是本步要产出的。 */
    private val PRODUCE_W = Regex("产出|生成|写成|写入|写进|输出|形成|保存为|存为|整理成|做成|汇总成|撰写|创作|完成|改写|修改|润色|更新|重写|起草|草拟|翻译成|转成|另存")
    /** 「阅读 / 根据 / 参考…」：后面的文件是本步要用的资料，不是产出。 */
    private val INPUT_W = Regex("阅读|读取|读|参考|查阅|打开|根据|基于|结合|对照|依据|利用|按照|查看|看")

    private val QUOTED = Regex("[《「“\"`]([^《》「」“”\"`\n]{1,60})[》」”\"`]")
    private val BARE = Regex("([\\w\\u4e00-\\u9fff\\-（）()/]{1,60}\\.(?:txt|md|docx|pptx|xlsx|pdf|csv|html|json))(?![\\w])", RegexOption.IGNORE_CASE)

    /** 资料 / 用户资料 / 步骤 / 备份 是输入或内部目录：要产出的同名文件放进「成果/」。 */
    private val INPUT_DIRS = listOf("资料", DeepMemory.DIR_USER, DeepMemory.DIR_STEPS, DeepMemory.DIR_BACKUP)

    private fun extOf(name: String): String {
        val n = name.substringAfterLast('/')
        if (!n.contains('.')) return ""
        val e = n.substringAfterLast('.').lowercase()
        return if (e in OUTPUT_EXTS) e else ""
    }

    /** 统一成相对本长思目录的路径：没写目录、或写的是资料目录，就放进「成果/」。 */
    fun normalizeOutput(raw: String): String? {
        var n = raw.trim().trim('*', ' ', '：', ':', '，', ',', '。', '/', '「', '」').replace('\\', '/')
        n = n.removePrefix("灵犀AI/").removePrefix("./")
        if (n.isBlank() || n.length > 80) return null
        if (n.startsWith("http", true) || n.contains("://") || n.startsWith("www.", true)) return null
        if (extOf(n).isEmpty()) return null
        val name = n.substringAfterLast('/')
        if (DeepMemory.norm(name.substringBeforeLast('.')).isEmpty()) return null
        if (!n.contains('/')) return "${DeepMemory.DIR_OUT}/$name"
        return if (INPUT_DIRS.any { n.startsWith("$it/") || n == it }) "${DeepMemory.DIR_OUT}/$name" else n
    }

    /** 文件名前面的动词：1 = 产出，-1 = 资料，0 = 看不出来。只看同一个分句里离得最近的那个动词。 */
    private fun roleBefore(before: String): Int {
        val clause = before.takeLast(40).split(Regex("[，。；;\\n,！？!?]")).last()
        val p = PRODUCE_W.findAll(clause).lastOrNull()?.range?.first ?: -1
        val i = INPUT_W.findAll(clause).lastOrNull()?.range?.first ?: -1
        return when {
            p < 0 && i < 0 -> 0
            p > i -> 1
            else -> -1
        }
    }

    /**
     * 这一步必须产出的文件（相对路径，默认在「成果/」下）。
     *  - 「产出《诗歌初稿.txt》」「写成 成果/报告.docx」→ 要产出
     *  - 「根据《主题意象备忘录.txt》构思」「查阅《唐诗三百首》」→ 是资料，不算
     *  - 书名号里没写扩展名、但前面是「产出 / 写成 …」时按 .md 处理
     */
    fun expectedOutputs(title: String, detail: String): List<String> {
        val text = "$title\n$detail"
        val out = LinkedHashSet<String>()
        for (m in QUOTED.findAll(text)) {
            val inner = m.groupValues[1].trim()
            val role = roleBefore(text.substring(0, m.range.first))
            val withExt = when {
                extOf(inner).isNotEmpty() -> if (role >= 0) inner else ""
                role == 1 && inner.length in 2..30 && !inner.contains(' ') && !inner.contains('/') -> "$inner.md"
                else -> ""
            }
            if (withExt.isNotEmpty()) normalizeOutput(withExt)?.let { out.add(it) }
        }
        val clean = text.replace(Regex("(?i)(?:https?://|www\\.)\\S+"), " ")
        for (m in BARE.findAll(clean)) {
            val raw = m.groupValues[1]
            val role = roleBefore(clean.substring(0, m.range.first))
            if (role != 1 && !raw.startsWith(DeepMemory.DIR_OUT + "/")) continue
            normalizeOutput(raw)?.let { p ->
                // 「成果/xx.txt」和「xx.txt」算同一个
                if (out.none { it.substringAfterLast('/').equals(p.substringAfterLast('/'), true) }) out.add(p)
            }
        }
        val seen = HashSet<String>()
        return out.filter { seen.add(it.substringAfterLast('/').lowercase()) }.take(6)
    }

    /** 「改写 / 修改 / 润色《X》」：X 必须在这一步里真的被改过（只是存在不算）。 */
    private val REWRITE_W = Regex("改写|修改|润色|重写|更新|完善|精修|校对|修订|订正|改进|优化")

    fun updateTargets(title: String, detail: String): Set<String> {
        val text = "$title\n$detail"
        val out = HashSet<String>()
        for (m in QUOTED.findAll(text)) {
            val inner = m.groupValues[1].trim()
            if (extOf(inner).isEmpty()) continue
            val clause = text.substring(0, m.range.first).takeLast(40).split(Regex("[，。；;\\n,！？!?]")).last()
            val r = REWRITE_W.findAll(clause).lastOrNull()?.range?.first ?: -1
            val i = INPUT_W.findAll(clause).lastOrNull()?.range?.first ?: -1
            if (r >= 0 && r > i) normalizeOutput(inner)?.let { out.add(it) }
        }
        return out
    }

    // ───────── 结论 / 状态 ─────────

    enum class State { DONE, UNFINISHED, MISSING }

    data class Outcome(val conclusion: String, val state: State, val reason: String)

    private fun unstar(s: String): String = s.replace("**", "").replace("__", "").trim().trim('*', ' ', '：', ':')

    /**
     * 解析【本步结论】和【状态】。
     * 和 v4.1 不同：**没有【状态】行时不再当作完成**（返回 [State.MISSING]），由交付门根据文件证据来判断。
     */
    fun parseOutcome(text: String): Outcome {
        val t = text.trim()
        val line = Regex("【状态】[*\\s：:]*([^\\n]*)").findAll(t).lastOrNull()?.groupValues?.get(1)?.let(::unstar)?.takeIf { it.isNotBlank() }
            ?: Regex("(?m)^[*\\s]*状态[*\\s]*[：:][*\\s]*([^\\n]+)").findAll(t).lastOrNull()?.groupValues?.get(1)?.let(::unstar)
        val state = when {
            line == null || line.isBlank() -> State.MISSING
            Regex("^(未完成|没完成|未做完|没做完|失败|部分完成|进行中|待续|尚未)").containsMatchIn(line) -> State.UNFINISHED
            line.contains("完成") || line.startsWith("done", true) || line.startsWith("ok", true) -> State.DONE
            else -> State.MISSING
        }
        val reason = if (state == State.UNFINISHED) {
            line!!.replace(Regex("^(未完成|没完成|未做完|没做完|失败|部分完成|进行中|待续|尚未)"), "").trimStart('：', ':', ' ', '，', ',').ifBlank { "没有说明原因" }
        } else ""
        val concl = Regex("【本步结论】([\\s\\S]*?)(?=【状态】|$)").find(t)?.groupValues?.get(1)
            ?.lines()?.joinToString("\n") { it.trimEnd() }?.trim()?.trim('*')?.trim().orEmpty()
        return Outcome(concl, state, reason)
    }

    private val INTENT = Regex("(我将|我会|我需要|我要|我先|让我|首先|接下来|下面我|准备|打算|现在开始|开始(执行|创作|构思|搜索)|先(联网|搜索|查|读|看|分析|确定|了解))")
    private val DID = Regex("(已写入|已覆盖|已生成|已更新|已保存|写好了|已完成|已创作)")

    /** 只说了打算、没动手（没有【状态】，结尾还停在「我将… / 首先… / 先联网搜索一下」）。 */
    fun isIntentOnly(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return true
        if (parseOutcome(t).state != State.MISSING) return false
        val tail = t.takeLast(260)
        return INTENT.containsMatchIn(tail) && !DID.containsMatchIn(tail)
    }

    // ───────── 复读 / 复述提示词 ─────────

    /** 用于比较的规范化：只留字母、数字、汉字。 */
    fun norm(s: String): String = DeepMemory.norm(s)

    private fun bigrams(n: String): Set<String> {
        if (n.length < 2) return if (n.isEmpty()) emptySet() else setOf(n)
        val out = HashSet<String>(n.length)
        for (i in 0 until n.length - 1) out.add(n.substring(i, i + 2))
        return out
    }

    private fun sim(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val inter = a.count { it in b }
        return inter.toDouble() / (a.size + b.size - inter)
    }

    /**
     * 流式输出的复读检测：同一行（或几乎一样的行）出现 [maxSame] 次，或结尾出现连续重复的片段，就判定为复读。
     * 线性开销：只检查新完成的行，以及每隔几十个字检查一次结尾。
     */
    class LoopDetector(private val maxSame: Int = 4, private val minLine: Int = 8) {
        private val sb = StringBuilder()
        private var lineStart = 0
        private var lastTailCheck = 0
        private val clusters = ArrayList<Pair<Set<String>, IntArray>>()
        private val exact = HashMap<String, Int>()
        var tripped: Boolean = false
            private set
        var reason: String = ""
            private set

        fun text(): String = sb.toString()

        /** 喂入一段增量，返回 true 表示已经在复读。 */
        fun feed(delta: String): Boolean {
            if (tripped || delta.isEmpty()) return tripped
            sb.append(delta)
            while (true) {
                val nl = sb.indexOf("\n", lineStart)
                if (nl < 0) break
                val raw = sb.substring(lineStart, nl)
                lineStart = nl + 1
                if (checkLine(raw)) return true
            }
            if (sb.length - lastTailCheck >= 40) {
                lastTailCheck = sb.length
                if (periodicTail(sb)) { tripped = true; reason = "结尾在重复同一段话" }
            }
            return tripped
        }

        private fun checkLine(raw: String): Boolean {
            val n = norm(raw)
            if (n.length < minLine) return false
            val c = (exact[n] ?: 0) + 1
            exact[n] = c
            if (c >= maxSame) { tripped = true; reason = "同一句话重复了 $c 次"; return true }
            // 表格行、工具调用只比完全相同
            val tl = raw.trimStart()
            if (tl.startsWith("|") || tl.startsWith("<tool>") || tl.startsWith("{")) return false
            val bg = bigrams(n)
            for (cl in clusters) {
                if (sim(cl.first, bg) >= 0.8) {
                    cl.second[0]++
                    if (cl.second[0] >= maxSame) { tripped = true; reason = "几乎一样的句子重复了 ${cl.second[0]} 次"; return true }
                    return false
                }
            }
            if (clusters.size < 60) clusters.add(bg to intArrayOf(1))
            return false
        }
    }

    /** 结尾是否是同一片段连续重复 ≥3 次（片段 4~200 字，总长 ≥ 60），或同一个字连续 ≥ 40 个。 */
    fun periodicTail(s: CharSequence): Boolean {
        val len = s.length
        if (len < 40) return false
        val tail = s.subSequence((len - 600).coerceAtLeast(0), len).toString()
        val last = tail.last()
        // 「-----」「=====」这类分隔线不算复读，只看文字 / 数字
        if (last.isLetterOrDigit()) {
            var run = 0
            for (i in tail.indices.reversed()) { if (tail[i] == last) run++ else break }
            if (run >= 40) return true
        }
        val t = tail.trimEnd()
        val n = t.length
        for (p in 4..200) {
            // 短片段要重复更多次才算（总长至少 60 字），避免「哈哈哈」这类误判
            val reps = maxOf(3, (60 + p - 1) / p)
            if (p * reps > n) continue
            val a = t.substring(n - p)
            if (a.none { it.isLetterOrDigit() }) continue
            var all = true
            for (k in 2..reps) if (!t.regionMatches(n - k * p, a, 0, p)) { all = false; break }
            if (all) return true
        }
        return false
    }

    /** 去掉复读：几乎一样的长句只保留第一次；去掉结尾的重复片段；合并多余空行。 */
    fun collapseRepeats(text: String): String {
        val kept = ArrayList<String>()
        val seen = ArrayList<Set<String>>()
        val exact = HashSet<String>()
        for (line in text.lines()) {
            val n = norm(line)
            if (n.length >= 8) {
                val tl = line.trimStart()
                val tableOrTool = tl.startsWith("|") || tl.startsWith("<tool>") || tl.startsWith("{")
                if (!exact.add(n)) continue
                if (!tableOrTool) {
                    val bg = bigrams(n)
                    if (seen.any { sim(it, bg) >= 0.8 }) continue
                    if (seen.size < 200) seen.add(bg)
                }
            }
            kept.add(line)
        }
        var out = kept.joinToString("\n").replace(Regex("\n{3,}"), "\n\n")
        // 结尾残留的周期片段
        var guard = 0
        while (periodicTail(out) && guard++ < 50) {
            val t = out.trimEnd()
            val n = t.length
            var cut = -1
            for (p in 4..200) {
                if (p * 2 > n) break
                val a = t.substring(n - p)
                if (t.regionMatches(n - 2 * p, a, 0, p)) { cut = n - p; break }
            }
            if (cut <= 0) break
            out = t.substring(0, cut)
        }
        return out.trim()
    }

    /** 系统提示词里的格式说明 —— 小模型常常把这些原样「复述」出来，要清掉。 */
    private val ECHO_LINE = Regex(
        "^【?(本?轮+(工具)?记录|本轮任务|工具结果[^】]*|当前消息|附带上下文|对话记录|工具记录)】?$|" +
            "请根据工具结果继续|我将根据工具结果继续|根据工具结果继续：|任务没完成就接着调用工具|互不依赖的可以一次写|" +
            "已经完成就给出最终回答|现在开始执行本轮任务|不要再调用工具，请直接",
    )

    /** 去掉复述的提示词格式行和只剩星号的空行（保留【本步结论】【状态】）。 */
    fun stripEcho(text: String): String = text.lines().filter { line ->
        val c = unstar(line)
        if (c.isEmpty()) return@filter line.isBlank() // 只剩 ** 的行去掉，真正的空行保留
        if (c.startsWith("【本步结论】") || c.startsWith("【状态】")) return@filter true
        !ECHO_LINE.containsMatchIn(c)
    }.joinToString("\n").replace(Regex("\n{3,}"), "\n\n").trim()

    /** 清理模型的整段输出：先去复述，再去复读。 */
    fun tidy(text: String): String = collapseRepeats(stripEcho(text))

    // ───────── 文件内容质检 ─────────

    data class Quality(val ok: Boolean, val reason: String, val chars: Int)

    private val PLACEHOLDER = Regex("(待补充|待填写|待完善|此处(填写|省略|补充|插入)|（略）|\\(略\\)|TODO|TBD|lorem ipsum|xxx{2,}|……$)", RegexOption.IGNORE_CASE)

    /** 有效行里「几乎重复」的比例（0~1）。 */
    fun repetitionRatio(text: String): Double {
        val lines = text.lines().map { norm(it) }.filter { it.length >= 6 }
        if (lines.size < 4) return 0.0
        val reps = ArrayList<Set<String>>()
        var dup = 0
        for (n in lines) {
            val bg = bigrams(n)
            if (reps.any { sim(it, bg) >= 0.8 }) dup++ else reps.add(bg)
        }
        return dup.toDouble() / lines.size
    }

    fun minCharsFor(ext: String): Int = when (ext.lowercase()) {
        "xlsx", "csv", "json" -> 4
        "pptx" -> 12
        else -> 16
    }

    /** 文件内容（回读出来的纯文本）是否像样。 */
    fun quality(text: String, ext: String = "txt"): Quality {
        val n = norm(text).length
        val min = minCharsFor(ext)
        return when {
            n == 0 -> Quality(false, "文件是空的", 0)
            n < min -> Quality(false, "内容太短（只有 $n 个字）", n)
            n < 200 && PLACEHOLDER.containsMatchIn(text) -> Quality(false, "只有占位内容（待补充 / 略）", n)
            repetitionRatio(text) >= 0.5 -> Quality(false, "内容大量重复（复读）", n)
            else -> Quality(true, "", n)
        }
    }

    private val CHATTER_HEAD = Regex("^(好的|好|当然|没问题|明白|收到|以下是|下面是|这是|我已|我将|根据).{0,40}[：:。！!]?$")
    private val CHATTER_TAIL = Regex("^(希望|如需|如果需要|以上|如有|需要我|你可以|请告诉我).{0,60}$")

    /**
     * 把「只输出文件正文」的回答清理成可以直接写进文件的内容：
     * 去掉包裹的 ``` 代码块、开头的「好的，以下是…」、结尾的「希望对你有帮助」、【本步结论】【状态】段、复述与复读。
     */
    fun cleanContent(raw: String): String {
        var t = raw.replace(Regex("<think>[\\s\\S]*?</think>"), "").replace(Regex("<tool>[\\s\\S]*?</tool>"), "").trim()
        // 正文被包在代码块里、外面只有几句客套话：只取代码块里的内容
        Regex("```[a-zA-Z]*[ \\t]*\\n([\\s\\S]*?)\\n[ \\t]*```").find(t)?.let { m ->
            val outside = t.removeRange(m.range)
            if (norm(outside).length < 80) t = m.groupValues[1]
        }
        // 去掉【本步结论】之后的部分
        t.indexOf("【本步结论】").takeIf { it > 0 }?.let { t = t.substring(0, it) }
        t = t.lines().filterNot { unstar(it).startsWith("【状态】") }.joinToString("\n")
        val lines = t.lines().toMutableList()
        repeat(2) {
            val i = lines.indexOfFirst { it.isNotBlank() }
            if (i >= 0 && CHATTER_HEAD.matches(unstar(lines[i])) && lines.count { it.isNotBlank() } > 1) lines.removeAt(i)
        }
        repeat(2) {
            val i = lines.indexOfLast { it.isNotBlank() }
            if (i >= 0 && CHATTER_TAIL.matches(unstar(lines[i])) && lines.count { it.isNotBlank() } > 1) lines.removeAt(i)
        }
        t = lines.joinToString("\n").replace(Regex("^-{3,}\\s*$", RegexOption.MULTILINE), "").trim()
        return tidy(t)
    }

    /** 扩展名对应的写法说明（给「只输出文件正文」的提示词用）。 */
    fun formatHint(ext: String): String = when (ext.lowercase()) {
        "docx", "pdf" -> "用 Markdown 写（# 标题、## 小节、- 列表、| 表格 |），系统会自动排版成 ${if (ext == "pdf") "PDF" else "Word"}"
        "pptx" -> "每页以「# 页标题」开头，下面 3~6 行「- 要点」；第一页是标题页"
        "xlsx", "csv" -> "只写 Markdown 表格（第一行是表头）；多张表用「## 表名」分隔"
        "md" -> "用 Markdown 写"
        "html" -> "写完整的 HTML 或 Markdown"
        "json" -> "只写合法的 JSON"
        else -> "写纯文本正文"
    }
}
