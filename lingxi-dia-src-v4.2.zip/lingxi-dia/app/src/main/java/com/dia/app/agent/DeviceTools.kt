package com.dia.app.agent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.dia.app.DiaAccessibilityService
import com.dia.app.MainActivity
import com.dia.app.home.HaTools
import com.dia.app.pilot.tool.ToolRegistry
import com.dia.app.prefs.DiaSettings
import com.dia.app.screen.NavBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.File
import kotlin.coroutines.resume

/**
 * 手机能力工具：把原先 Pilot / 智能家居 / 各个页面里的小工具全部接到对话 Agent 上，
 * 用户用自然语言说一句，AI 自己挑合适的工具组合完成。
 */
object DeviceTools {

    private fun ensureRegistry() {
        if (ToolRegistry.getAllTools().isEmpty()) ToolRegistry.registerAll()
    }

    private fun a11yMissing(): ToolOutcome = ToolOutcome(
        "需要先开启无障碍服务：设置 → 权限 → 无障碍，打开「灵犀 Dia」。开启后我就能读屏幕、点按钮、输入文字。",
        ok = false,
    )

    /** 灵犀在前台时先退到后台，让目标应用露出来。 */
    private suspend fun leaveApp(host: ToolHost) {
        if (MainActivity.isForeground) {
            host.moveAppToBack()
            delay(900)
        }
    }

    /** 读完屏幕后回到灵犀。 */
    fun bringBack(ctx: Context) {
        try {
            ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP,
            ))
        } catch (_: Exception) { }
    }

    /** 执行一个 Pilot 底层工具。 */
    private suspend fun pilot(name: String, params: Map<String, Any>): ToolOutcome = withContext(Dispatchers.IO) {
        ensureRegistry()
        val r = ToolRegistry.executeTool(name, params)
        if (r.isSuccess) ToolOutcome(r.data.orEmpty().ifBlank { "完成" })
        else ToolOutcome("失败：${r.error}", ok = false)
    }

    private fun JSONObject.str(vararg keys: String): String {
        for (k in keys) {
            val v = opt(k)
            if (v != null && v != JSONObject.NULL && v.toString().isNotBlank()) return v.toString().trim()
        }
        return ""
    }

    private fun JSONObject.int(vararg keys: String): Int? {
        for (k in keys) {
            val v = opt(k) ?: continue
            when (v) {
                is Number -> return v.toInt()
                is String -> v.trim().toDoubleOrNull()?.let { return it.toInt() }
            }
        }
        return null
    }

    private fun screenSummary(max: Int = 1800): String {
        val svc = DiaAccessibilityService.getInstance() ?: return ""
        val tree = try { svc.getScreenTree() } catch (_: Exception) { null } ?: return ""
        return if (tree.length > max) tree.take(max) + "\n…（屏幕内容较多，已截断，可用 read_screen 查看全部）" else tree
    }

    // ───────── 屏幕操作 ─────────

    /**
     * 单步操作手机：tap / long_press / swipe / scroll_find / type / key / search / wait。
     * 操作完自动附上新的屏幕结构，方便连续操作。
     */
    suspend fun phoneAction(args: JSONObject, host: ToolHost): ToolOutcome {
        if (!DiaAccessibilityService.isRunning()) return a11yMissing()
        val action = args.str("action", "type_", "op").lowercase().ifBlank {
            when {
                args.has("text") && !args.has("x") -> "tap"
                args.has("key") -> "key"
                else -> "tap"
            }
        }
        leaveApp(host)
        val p = HashMap<String, Any>()
        val outcome = when (action) {
            "tap", "click", "点击", "tap_text" -> {
                val nodeId = args.str("node_id", "node", "id")
                val x = args.int("x")
                val y = args.int("y")
                val text = args.str("text", "label", "target")
                when {
                    nodeId.isNotBlank() -> { p["node_id"] = nodeId; pilot("tap_node", p) }
                    x != null && y != null -> { p["x"] = x; p["y"] = y; pilot("tap", p) }
                    text.isNotBlank() -> { p["text"] = text; pilot("find_and_tap", p) }
                    else -> ToolOutcome("tap 需要 node_id、坐标 x/y 或要点击的文字 text", ok = false)
                }
            }
            "long_press", "长按" -> {
                args.str("node_id").takeIf { it.isNotBlank() }?.let { p["node_id"] = it }
                args.int("x")?.let { p["x"] = it }
                args.int("y")?.let { p["y"] = it }
                args.int("duration_ms")?.let { p["duration_ms"] = it }
                pilot("long_press", p)
            }
            "swipe", "scroll", "滑动" -> {
                val dir = args.str("direction", "dir").lowercase()
                val dm = host.context.resources.displayMetrics
                val w = dm.widthPixels
                val h = dm.heightPixels
                if (dir.isNotBlank()) {
                    val (sx, sy, ex, ey) = when (dir) {
                        "up", "上" -> listOf(w / 2, (h * 0.75).toInt(), w / 2, (h * 0.25).toInt())
                        "down", "下" -> listOf(w / 2, (h * 0.25).toInt(), w / 2, (h * 0.75).toInt())
                        "left", "左" -> listOf((w * 0.85).toInt(), h / 2, (w * 0.15).toInt(), h / 2)
                        else -> listOf((w * 0.15).toInt(), h / 2, (w * 0.85).toInt(), h / 2)
                    }
                    p["start_x"] = sx; p["start_y"] = sy; p["end_x"] = ex; p["end_y"] = ey
                } else {
                    p["start_x"] = args.int("start_x") ?: (w / 2)
                    p["start_y"] = args.int("start_y") ?: (h * 3 / 4)
                    p["end_x"] = args.int("end_x") ?: (w / 2)
                    p["end_y"] = args.int("end_y") ?: (h / 4)
                }
                pilot("swipe", p)
            }
            "scroll_find", "find", "滚动查找" -> {
                p["text"] = args.str("text", "target")
                args.int("max_swipes")?.let { p["max_swipes"] = it }
                pilot("scroll_to_find", p)
            }
            "type", "input", "输入" -> {
                p["text"] = args.str("text", "content")
                args.str("node_id").takeIf { it.isNotBlank() }?.let { p["node_id"] = it }
                if (args.has("submit")) p["submit"] = args.optBoolean("submit", true)
                if (args.has("clear_first")) p["clear_first"] = args.optBoolean("clear_first", true)
                pilot("input_text", p)
            }
            "key", "按键" -> { p["key"] = args.str("key", "text").ifBlank { "back" }; pilot("system_key", p) }
            "back", "返回" -> { p["key"] = "back"; pilot("system_key", p) }
            "home", "桌面" -> { p["key"] = "home"; pilot("system_key", p) }
            "recents" -> { p["key"] = "recents"; pilot("system_key", p) }
            "search", "搜索" -> { p["query"] = args.str("query", "text"); pilot("search_in_app", p) }
            "wait", "等待" -> { delay((args.int("ms", "duration_ms") ?: 1000).toLong().coerceIn(100, 30_000)); ToolOutcome("已等待") }
            else -> ToolOutcome("未知动作：$action。可用：tap / long_press / swipe / scroll_find / type / key / back / home / search / wait", ok = false)
        }
        if (!outcome.ok) return outcome
        delay(700)
        val screen = screenSummary()
        return outcome.copy(
            forModel = outcome.forModel + if (screen.isNotBlank()) "\n\n【操作后的屏幕】\n$screen" else "",
            display = outcome.display,
        )
    }

    /** 读取当前屏幕的界面结构（含节点编号）。 */
    suspend fun readScreen(args: JSONObject, host: ToolHost): ToolOutcome {
        if (!DiaAccessibilityService.isRunning()) return a11yMissing()
        val wasFront = MainActivity.isForeground
        leaveApp(host)
        val tree = withContext(Dispatchers.IO) {
            val svc = DiaAccessibilityService.getInstance()
            svc?.getScreenTree() ?: svc?.getAllScreenText()
        }.orEmpty()
        val stay = args.optBoolean("stay", false)
        if (wasFront && !stay) bringBack(host.context)
        if (tree.isBlank()) return ToolOutcome("屏幕上没有读到内容（可能是游戏 / 视频画面），可以试试 look_screen 看截图。", ok = false)
        val max = (com.dia.app.llm.LlmGateway.promptCharBudget() / 3).coerceIn(1500, 9000)
        return ToolOutcome(
            "当前屏幕（[nX] 是节点编号，可用 phone_action 的 node_id 点击）：\n" + tree.take(max),
            display = tree.take(1500),
        )
    }

    /** 截屏交给视觉模型看（Android 11+）。 */
    suspend fun lookScreen(args: JSONObject, host: ToolHost): ToolOutcome {
        if (!DiaAccessibilityService.isRunning()) return a11yMissing()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return readScreen(args, host)
        val wasFront = MainActivity.isForeground
        leaveApp(host)
        val svc = DiaAccessibilityService.getInstance() ?: return a11yMissing()
        val bmp = withTimeoutOrNull(6000) {
            suspendCancellableCoroutine<android.graphics.Bitmap?> { cont ->
                svc.captureScreenshot { b -> if (cont.isActive) cont.resume(b) }
            }
        }
        if (wasFront && !args.optBoolean("stay", false)) bringBack(host.context)
        if (bmp == null) return readScreen(args, host)
        val scaled = scaleDown(bmp, 1024)
        val q = args.str("question", "q")
        return ToolOutcome(
            "已截取当前屏幕，图片已附在上方，请直接观察回答${if (q.isNotBlank()) "：$q" else "。"}",
            display = "已截屏",
            images = listOf(scaled),
        )
    }

    private fun scaleDown(b: android.graphics.Bitmap, max: Int): android.graphics.Bitmap {
        val s = maxOf(b.width, b.height)
        if (s <= max) return b
        val f = max.toFloat() / s
        return android.graphics.Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }

    // ───────── 信息类 ─────────

    suspend fun notifications(): ToolOutcome {
        val r = pilot("get_notifications", emptyMap())
        if (!r.ok && r.forModel.contains("ccess")) {
            return ToolOutcome("需要通知读取权限：设置 → 文件与权限 → 通知读取，打开「灵犀 Dia」。", ok = false)
        }
        return r
    }

    suspend fun clipboard(args: JSONObject): ToolOutcome {
        val p = HashMap<String, Any>()
        val text = args.str("text", "content")
        p["action"] = args.str("action").ifBlank { if (text.isNotBlank()) "set" else "get" }
        if (text.isNotBlank()) p["text"] = text
        return withContext(Dispatchers.Main) {
            ensureRegistry()
            val r = ToolRegistry.executeTool("clipboard", p)
            if (r.isSuccess) ToolOutcome(r.data.orEmpty()) else ToolOutcome("剪贴板操作失败：${r.error}", ok = false)
        }
    }

    suspend fun deviceInfo(args: JSONObject): ToolOutcome {
        val cat = args.str("category", "type").ifBlank { "battery" }
        val cats = if (cat == "all" || cat == "全部") listOf("battery", "wifi", "storage", "device", "time") else listOf(cat)
        val sb = StringBuilder()
        for (c in cats) {
            val r = pilot("get_device_info", mapOf("category" to c))
            sb.append(r.forModel).append('\n')
        }
        return ToolOutcome(sb.toString().trim())
    }

    suspend fun listApps(args: JSONObject): ToolOutcome {
        val p = HashMap<String, Any>()
        args.str("keyword", "name", "query").takeIf { it.isNotBlank() }?.let { p["keyword"] = it }
        return pilot("get_installed_apps", p)
    }

    suspend fun callPhone(args: JSONObject, host: ToolHost): ToolOutcome {
        val who = args.str("contact", "name", "number", "phone")
        if (who.isBlank()) return ToolOutcome("缺少联系人或号码", ok = false)
        if (!host.confirm("拨打电话给「$who」？", "灵犀会打开拨号并呼叫。")) return ToolOutcome("用户取消了拨号。", ok = false)
        leaveApp(host)
        return pilot("make_call", mapOf("contact" to who))
    }

    suspend fun sendMessage(args: JSONObject, host: ToolHost): ToolOutcome {
        if (!DiaAccessibilityService.isRunning()) return a11yMissing()
        val who = args.str("contact", "to", "name")
        val msg = args.str("message", "text", "content")
        val app = args.str("app").ifBlank { "微信" }
        if (who.isBlank() || msg.isBlank()) return ToolOutcome("需要联系人 contact 和内容 message", ok = false)
        if (!host.confirm("用「$app」给「$who」发消息？", "内容：$msg")) return ToolOutcome("用户取消了发送。", ok = false)
        leaveApp(host)
        return pilot("send_message", mapOf("contact" to who, "message" to msg, "app" to app))
    }

    suspend fun openUrl(args: JSONObject, host: ToolHost): ToolOutcome {
        val p = HashMap<String, Any>()
        args.str("url", "link").takeIf { it.isNotBlank() }?.let { p["url"] = it }
        args.str("query", "q").takeIf { it.isNotBlank() }?.let { p["query"] = it }
        if (p.isEmpty()) return ToolOutcome("缺少 url 或 query", ok = false)
        val r = pilot("open_url", p)
        return r
    }

    suspend fun contacts(args: JSONObject, host: ToolHost): ToolOutcome = withContext(Dispatchers.IO) {
        val ctx = host.context
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return@withContext ToolOutcome("没有通讯录权限：请在系统设置 → 应用 → 灵犀 Dia → 权限 里允许「通讯录」。", ok = false)
        }
        val q = args.str("query", "name", "keyword")
        val out = StringBuilder()
        var n = 0
        val sel = if (q.isNotBlank()) "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?" else null
        val selArgs = if (q.isNotBlank()) arrayOf("%$q%") else null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            sel, selArgs, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC",
        )?.use { c ->
            while (c.moveToNext() && n < 50) {
                out.append(c.getString(0)).append("：").append(c.getString(1)).append('\n'); n++
            }
        }
        ToolOutcome(if (n == 0) "通讯录里没有找到「$q」" else "找到 $n 个号码：\n$out".trim())
    }

    // ───────── 智能家居 ─────────

    suspend fun smartHome(args: JSONObject): ToolOutcome = withContext(Dispatchers.IO) {
        val action = args.str("action").lowercase().ifBlank { if (args.has("service")) "call" else "list" }
        val res = when (action) {
            "list", "列表" -> HaTools.listEntities(args.str("domain").ifBlank { null })
            "state", "状态" -> HaTools.getState(args.str("entity_id", "entity"))
            else -> {
                val entity = args.str("entity_id", "entity")
                val domain = args.str("domain").ifBlank { entity.substringBefore('.', "") }
                val service = args.str("service").ifBlank { "toggle" }
                val extra = args.optJSONObject("data")?.let { d -> d.keys().asSequence().associateWith { d.get(it) } }
                HaTools.callService(domain, service, entity, extra)
            }
        }
        ToolOutcome(res, ok = !res.startsWith("Error"))
    }

    // ───────── 灵犀自身：页面 / 主题 / 背景 ─────────

    private val PAGES = mapOf(
        "lens" to "实时镜头", "camera" to "实时镜头", "镜头" to "实时镜头",
        "slate" to "手写板", "手写" to "手写板", "notebook" to "手写板",
        "home" to "智能家居", "家居" to "智能家居",
        "pilot" to "任务面板", "guide" to "引导面板", "settings" to "设置", "设置" to "设置",
        "model" to "模型管理", "模型" to "模型管理", "bubble" to "悬浮气泡",
    )

    fun openPage(args: JSONObject): ToolOutcome {
        val raw = args.str("page", "name").lowercase()
        val key = PAGES.keys.firstOrNull { raw == it } ?: PAGES.keys.firstOrNull { raw.contains(it) }
            ?: return ToolOutcome("没有页面「$raw」。可选：lens(实时镜头)、slate(手写板)、home(智能家居)、pilot、guide、settings、model、bubble", ok = false)
        val id = when (key) {
            "camera", "镜头" -> "lens"
            "手写", "notebook" -> "slate"
            "家居" -> "home"
            "设置" -> "settings"
            "模型" -> "model"
            else -> key
        }
        NavBus.requestPage(id)
        return ToolOutcome("已打开「${PAGES[key]}」。", shownToUser = true)
    }

    fun setTheme(args: JSONObject): ToolOutcome {
        val m = args.str("mode", "theme", "id", "name")
        val lower = m.lowercase()
        // 已安装的主题包（如水墨太极）按 id / 名字匹配
        com.dia.app.ui.theme.ThemeManager.all().firstOrNull { it.id == lower || it.name == m || (m.length >= 2 && it.name.contains(m)) }?.let { pack ->
            com.dia.app.ui.theme.ThemeManager.apply(pack.id)
            return ToolOutcome("已切换为「${pack.name}」主题。")
        }
        val mode = when {
            lower.contains("太极") || lower.contains("taiji") -> "taiji"
            lower.contains("wuji") || lower.contains("无极") || lower.contains("金") -> "wuji"
            lower.contains("ink") || lower.contains("夜") || lower.contains("深") || lower.contains("dark") || lower.contains("江湖") -> "ink"
            else -> "paper"
        }
        if (com.dia.app.ui.theme.ThemeManager.find(mode) == null) return ToolOutcome("没有找到主题「$m」", ok = false)
        DiaSettings.themeMode.set(mode)
        return ToolOutcome("已切换为「${com.dia.app.ui.theme.ThemeManager.label(mode)}」主题。")
    }

    /** 生成 / 指定 / 清除对话背景。 */
    suspend fun setBackground(args: JSONObject, host: ToolHost): ToolOutcome {
        val clear = args.optBoolean("clear", false) || args.str("action") == "clear" || args.str("prompt") in setOf("默认", "恢复默认", "default")
        if (clear) {
            DiaSettings.customBgPath.set("")
            return ToolOutcome("已恢复内置水墨背景。")
        }
        val image = args.str("image", "path", "file")
        val src: String = if (image.isNotBlank()) {
            val f = com.dia.app.files.FileManager.find(image)
            when {
                f != null -> withContext(Dispatchers.IO) {
                    val bytes = com.dia.app.files.FileManager.readBytes(f)
                    File(host.context.filesDir, "bg").apply { mkdirs() }.let { d ->
                        File(d, "custom_${System.currentTimeMillis()}.img").apply { writeBytes(bytes) }.absolutePath
                    }
                }
                File(image).exists() -> image
                else -> return ToolOutcome("找不到图片「$image」", ok = false)
            }
        } else {
            val prompt = args.str("prompt", "description").ifBlank { "烟雨江南，远山，孤舟" }
            val styled = "$prompt，中国水墨画，写意，宣纸质感，留白，淡墨远山，竖构图，竖版手机壁纸，无文字"
            val r = AgentTools.generateImage(styled, "720x1280", host)
            r.imagePath ?: return ToolOutcome("背景生成失败：${r.forModel}", ok = false)
        }
        val dst = withContext(Dispatchers.IO) {
            val d = File(host.context.filesDir, "bg").apply { mkdirs() }
            val out = File(d, "bg_${System.currentTimeMillis()}.png")
            File(src).copyTo(out, overwrite = true)
            // 清理旧背景
            d.listFiles()?.filter { it.name.startsWith("bg_") && it.absolutePath != out.absolutePath }?.forEach { it.delete() }
            out.absolutePath
        }
        DiaSettings.customBgPath.set(dst)
        return ToolOutcome("已把对话背景换成新图。想换回内置水墨背景说「恢复默认背景」即可。", shownToUser = true)
    }
}
