package com.dia.app.ui.chat

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.dia.app.files.FileRef
import com.dia.app.imagegen.ImageGen
import com.dia.app.llm.LlmGateway
import com.dia.app.llm.ModelLoadState
import com.dia.app.llm.ModelManager
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import com.dia.app.ui.theme.CloudDivider
import com.dia.app.ui.theme.DiaBrush
import com.dia.app.ui.theme.DiaPal
import com.dia.app.ui.theme.DiaPalette
import com.dia.app.ui.theme.DiaSerif
import com.dia.app.ui.theme.InkAvatar
import com.dia.app.ui.theme.InkBubbleShape
import com.dia.app.ui.theme.InkHero
import com.dia.app.ui.theme.SealMark
import com.dia.app.ui.theme.inkStroke
import com.dia.app.ui.theme.inkWashBackground
import com.dia.app.ui.theme.paperGrain
import com.dia.app.ui.theme.scrollFrame
import com.dia.app.ui.theme.themeLabel
import com.dia.app.ui.theme.ThemedGlyph
import com.dia.app.ui.theme.ThemedIcon
import com.dia.app.ui.theme.ToolGlyph
import com.dia.app.ui.theme.LocalThemePack
import com.dia.app.ui.tools.MentionSuggestions
import com.dia.app.ui.tools.ToolPanelSheet
import com.dia.app.deep.DeepEngine
import com.dia.app.voice.AudioScribeRecorder
import com.dia.app.voice.DiaTts
import com.dia.app.voice.SpeechInput
import com.halilibo.richtext.commonmark.Markdown
import com.halilibo.richtext.ui.CodeBlockStyle
import com.halilibo.richtext.ui.RichTextStyle
import com.halilibo.richtext.ui.material3.RichText
import com.halilibo.richtext.ui.string.RichTextStringStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 百宝箱里会跳转到其它页面的入口。 */
enum class ToolPage { SETTINGS, MODEL_SETUP, LENS_LIVE, SLATE, HOME_MODE, PILOT, GUIDE, DEEP, AI_FOLDER, THEME }

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(onOpenPage: (ToolPage) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = DiaPal.current

    val messages by ChatController.messages.collectAsState()
    val isGenerating by ChatController.isGenerating.collectAsState()
    val loadState by ModelManager.state.collectAsState()
    val title by ChatController.title.collectAsState()
    val thinking by ChatController.thinking.collectAsState()
    val pendingImages by ChatController.pendingImages.collectAsState()
    val pendingFiles by ChatController.pendingFiles.collectAsState()
    val selfLoop by ChatController.selfLoop.collectAsState()
    val draft by ChatController.draft.collectAsState()
    val activeChatId by ChatController.activeChatId.collectAsState()
    val threads by ChatHistoryStore.threads.collectAsState()
    val fontScale by DiaPrefs.chatFontScale.collectAsState()
    val autoSpeak by DiaPrefs.autoSpeak.collectAsState()
    val cloudOn by DiaPrefs.cloudEnabled.collectAsState()
    val webOn by DiaSettings.webEnabled.flow.collectAsState()
    val speakingId by DiaTts.speakingId.collectAsState()
    val wuji by DiaSettings.wujiMode.flow.collectAsState()
    val voiceTurn by ChatController.voiceTurn.collectAsState()
    val voiceConversation by DiaSettings.voiceConversation.flow.collectAsState()
    val speech = remember { SpeechInput(context.applicationContext) }
    DisposableEffect(Unit) { onDispose { speech.release() } }

    var input by remember { mutableStateOf("") }
    var showToolbox by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showModels by remember { mutableStateOf(false) }
    var showMemory by remember { mutableStateOf(false) }
    var showBackups by remember { mutableStateOf(false) }
    var showBubble by remember { mutableStateOf(false) }
    var showSelfLoop by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    val planReview by ChatController.planReview.collectAsState()
    val deepSessions by DeepEngine.sessions.collectAsState()
    var editing by remember { mutableStateOf<ChatMessage?>(null) }
    var viewingImage by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) { ChatHistoryStore.init(context.applicationContext) }

    // 外部草稿（悬浮气泡「发到对话」等）
    LaunchedEffect(draft) {
        val d = ChatController.consumeDraft()
        if (!d.isNullOrBlank()) input = if (input.isBlank()) d else input + "\n" + d
    }

    // 界面事件
    LaunchedEffect(Unit) {
        ChatController.events.collect { e ->
            when {
                e == "move_to_back" -> context.findActivity()?.moveTaskToBack(true)
                e == "open_tools" -> showTools = true
                e.startsWith("toast:") -> Toast.makeText(context, e.removePrefix("toast:"), Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    val last = messages.lastOrNull()
    // 语音转文字后发出的问题：回复以文字显示；语音对话模式下再朗读，读完自动继续听
    val speakVoice = voiceTurn && voiceConversation && DiaSettings.voiceSpeakReply.value
    LaunchedEffect(last?.id, last?.isStreaming) {
        if ((autoSpeak || speakVoice) && last != null && !last.isUser && last.kind == ChatMessage.KIND_TEXT &&
            !last.isStreaming && !last.isError && last.text.isNotBlank()
        ) DiaTts.speak(context, last.id, last.text)
    }
    fun listenAgain() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        speech.start(
            DiaSettings.voiceLanguage.value,
            onResult = { t -> if (DiaSettings.voiceAutoSend.value) ChatController.sendVoiceText(t) else input = t },
            onError = { e -> Toast.makeText(context, e, Toast.LENGTH_SHORT).show() },
        )
    }
    // 语音对话：朗读结束（或不朗读时回复完成）后自动开始听下一句
    var wasSpeaking by remember { mutableStateOf(false) }
    LaunchedEffect(speakingId, isGenerating, last?.id) {
        val idle = !isGenerating && last != null && !last.isUser && !last.isStreaming
        if (voiceConversation && voiceTurn && idle && speech.state.value == SpeechInput.State.IDLE) {
            if (speakingId != null) wasSpeaking = true
            else if (wasSpeaking || !speakVoice) { wasSpeaking = false; kotlinx.coroutines.delay(400); listenAgain() }
        }
    }
    DisposableEffect(Unit) { onDispose { DiaTts.stop() } }

    // 开启无极模式时，一次性申请会用到的运行时权限
    val wujiPerms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val denied = res.filterValues { !it }.keys
        if (denied.isNotEmpty()) Toast.makeText(context, "部分权限未授予，相关能力会受限", Toast.LENGTH_SHORT).show()
    }
    var lastWuji by remember { mutableStateOf(wuji) }
    LaunchedEffect(wuji) {
        if (wuji && !lastWuji) {
            val want = buildList {
                add(Manifest.permission.RECORD_AUDIO)
                add(Manifest.permission.CAMERA)
                add(Manifest.permission.READ_CONTACTS)
                if (android.os.Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            }.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
            if (want.isNotEmpty()) wujiPerms.launch(want.toTypedArray())
            if (!com.dia.app.DiaAccessibilityService.isRunning()) {
                ChatController.note("☯ 提示：开启「无障碍服务」后，无极模式才能读屏幕、点按钮、替你操作其它应用（设置 → 文件与权限 → 无障碍服务）。")
            }
        }
        lastWuji = wuji
    }

    // ── 系统选择器 ──
    val pickImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        uris.take(4).forEach { ChatController.addImageUri(it) }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        uris.take(5).forEach { ChatController.addFileUri(it) }
    }
    // 「音频转文字」：选一个音频 / 视频文件，附上后直接发 /转写
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val ref = withContext(Dispatchers.IO) { com.dia.app.files.FileManager.attach(uri) }
                    ChatController.addExistingFile(ref)
                    ChatController.send("/转写 ${ref.id}")
                } catch (e: Exception) {
                    Toast.makeText(context, "文件附加失败：${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) ChatController.addImage(bmp)
    }
    val cameraPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) takePhoto.launch(null) else Toast.makeText(context, "需要相机权限才能拍照", Toast.LENGTH_SHORT).show()
    }
    fun openCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            takePhoto.launch(null)
        } else cameraPerm.launch(Manifest.permission.CAMERA)
    }

    val modelReady = LlmGateway.isAvailable() || (loadState is ModelLoadState.Ready)
    val canSend = (input.isNotBlank() || pendingImages.isNotEmpty() || pendingFiles.isNotEmpty()) &&
        (!isGenerating || selfLoop.running)

    fun doSend() {
        val t = input
        input = ""
        ChatController.send(t)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .inkWashBackground(p)
            .windowInsetsPadding(WindowInsets.statusBars),
    ) {
        ChatHeader(
            p = p,
            title = title,
            loadState = loadState,
            cloudOn = cloudOn && DiaPrefs.cloudIsConfigured(),
            wuji = wuji,
            onWuji = { ChatController.toggleWuji() },
            thinking = thinking,
            fontScale = fontScale,
            onHistory = { showHistory = true },
            onModel = { showModels = true },
            onNew = { ChatController.newChat() },
            onToggleThinking = { ChatController.setThinking(!thinking) },
            onFont = {
                DiaPrefs.setChatFontScale(
                    when {
                        fontScale < 0.95f -> 1.0f
                        fontScale < 1.15f -> 1.2f
                        else -> 0.85f
                    }
                )
            },
            onMemory = { showMemory = true },
            onBackups = { showBackups = true },
            onBubble = { showBubble = true },
            onTheme = { DiaSettings.themeMode.set(if (DiaSettings.themeMode.value == "ink") "paper" else "ink") },
            onClear = { ChatController.clearCurrent() },
            onSettings = { onOpenPage(ToolPage.SETTINGS) },
            onDeep = { onOpenPage(ToolPage.DEEP) },
            deepRunning = deepSessions.count { it.status == "running" || it.status == "planning" },
            onThemePage = { onOpenPage(ToolPage.THEME) },
            onAiFolder = { onOpenPage(ToolPage.AI_FOLDER) },
            onTools = { showTools = true },
        )
        // 自主长思在后台运行时的提示条
        val runningDeep = deepSessions.filter { it.status == "running" || it.status == "planning" || it.status == "review" }
        if (runningDeep.isNotEmpty()) DeepBanner(p, runningDeep.first(), runningDeep.size) { onOpenPage(ToolPage.DEEP) }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                if (messages.isEmpty()) {
                    item {
                        EmptyHero(
                            p = p,
                            wuji = wuji,
                            loadState = loadState,
                            modelReady = modelReady,
                            onPickModel = { showModels = true },
                            onSuggestion = { s ->
                                if (s.endsWith("：") || s.endsWith(" ")) input = s else { input = ""; ChatController.send(s) }
                            },
                        )
                    }
                }
                items(messages, key = { it.id }) { m ->
                    when (m.kind) {
                        ChatMessage.KIND_TOOL -> ToolCard(p, m)
                        ChatMessage.KIND_CONFIRM -> ConfirmCard(p, m) { ok -> ChatController.resolveConfirm(m.id, ok) }
                        ChatMessage.KIND_IMAGE -> GeneratedImageCard(p, m, onOpen = { viewingImage = it }, onSave = { path ->
                            scope.launch {
                                val uri = withContext(Dispatchers.IO) { ImageGen.saveToGallery(context, path) }
                                Toast.makeText(context, if (uri != null) "已保存到相册 Pictures/Dia" else "保存失败", Toast.LENGTH_SHORT).show()
                            }
                        })
                        ChatMessage.KIND_NOTE -> NoteRow(p, m.text)
                        ChatMessage.KIND_PLAN -> PlanCard(p, m, planReview?.takeIf { it.cardId == m.id })
                        else -> if (m.isUser) {
                            UserBubble(p, m, fontScale, onImage = { viewingImage = it }, onEdit = { editing = m }, onCopy = { copy(context, m.text) })
                        } else {
                            AssistantBubble(
                                p = p, m = m, fontScale = fontScale, speaking = speakingId == m.id,
                                onCopy = { copy(context, m.text) },
                                onSpeak = { DiaTts.toggle(context, m.id, m.text) },
                                onRetry = { ChatController.retryLast() },
                                onDelete = { ChatController.deleteMessage(m.id) },
                            )
                        }
                    }
                }
            }
        }

        if (selfLoop.running) SelfLoopBanner(p, selfLoop) { ChatController.stop() }

        if (pendingImages.isNotEmpty() || pendingFiles.isNotEmpty()) {
            PendingRow(p, pendingImages, pendingFiles)
        }
        // 输入「@」时给出可以亲自调用的工具
        MentionSuggestions(p, input) { t -> input = "@${t.title} " }

        InputBar(
            p = p,
            text = input,
            onText = { input = it },
            canSend = canSend,
            generating = isGenerating && !selfLoop.running,
            loopRunning = selfLoop.running,
            webOn = webOn,
            placeholder = when {
                selfLoop.running -> "插话：补充信息或改变讨论方向…"
                !modelReady -> "先选择模型（或输入 /画 描述 直接生图）"
                wuji -> "☯ 无极 · 说出你的目标，灵犀全力以赴…"
                else -> "少侠请讲…（点麦克风说话，输入 / 看命令）"
            },
            onSend = { doSend() },
            onStop = { ChatController.stop() },
            onToolbox = { showToolbox = true },
            onTools = { showTools = true },
            onToggleWeb = { DiaSettings.webEnabled.set(!webOn) },
            onVoice = { clip -> ChatController.send("", audio = clip) },
            speech = speech,
            onSpeechText = { t -> if (DiaSettings.voiceAutoSend.value) ChatController.sendVoiceText(t) else input = if (input.isBlank()) t else "$input $t" },
            modifier = Modifier
                .windowInsetsPadding(WindowInsets.navigationBars)
                .windowInsetsPadding(WindowInsets.ime),
        )
    }

    // ── 弹层 ──
    if (showToolbox) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showToolbox = false }, sheetState = st, containerColor = p.surface) {
            ToolboxSheet(p = p) { action ->
                showToolbox = false
                when (action) {
                    "image" -> pickImages.launch("image/*")
                    "camera" -> openCamera()
                    "file" -> pickFiles.launch(arrayOf("*/*"))
                    "draw" -> input = "/画 "
                    "search" -> input = "/搜 "
                    "translate" -> input = "/译 "
                    "screen_translate" -> {
                        ChatController.send("帮我翻译屏幕上的内容")
                    }
                    "phone" -> input = "/控 "
                    "guide" -> input = "/引导 "
                    "loop" -> showSelfLoop = true
                    "memory" -> showMemory = true
                    "backup" -> showBackups = true
                    "bubble" -> showBubble = true
                    "lens" -> onOpenPage(ToolPage.LENS_LIVE)
                    "slate" -> onOpenPage(ToolPage.SLATE)
                    "home" -> onOpenPage(ToolPage.HOME_MODE)
                    "pilot" -> onOpenPage(ToolPage.PILOT)
                    "guide_page" -> onOpenPage(ToolPage.GUIDE)
                    "settings" -> onOpenPage(ToolPage.SETTINGS)
                    "help" -> ChatController.send("/帮助")
                    "wuji" -> ChatController.toggleWuji()
                    "step" -> input = "/分步 "
                    "rewrite" -> input = "把这份文档润色一遍，保留原有排版"
                    "pdf" -> input = "把这几个 PDF 合并成一个"
                    "create_doc" -> input = "帮我写一份 Word 文档："
                    "create_ppt" -> input = "帮我做一份 PPT，主题是："
                    "read_screen" -> ChatController.send("看看我手机屏幕上现在是什么内容，帮我总结一下")
                    "voice_chat" -> {
                        val on = !DiaSettings.voiceConversation.value
                        DiaSettings.voiceConversation.set(on)
                        Toast.makeText(context, if (on) "语音对话已开启：点麦克风说话，回复读完会自动继续听" else "语音对话已关闭", Toast.LENGTH_SHORT).show()
                    }
                    "background" -> input = "/背景 "
                    "theme" -> onOpenPage(ToolPage.THEME)
                    "deep" -> onOpenPage(ToolPage.DEEP)
                    "tools" -> showTools = true
                    "ai_folder" -> onOpenPage(ToolPage.AI_FOLDER)
                    "transcribe" -> pickAudio.launch(arrayOf("audio/*", "video/*"))
                }
                Unit
            }
        }
    }
    if (showHistory) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showHistory = false }, sheetState = st, containerColor = p.surface) {
            HistorySheet(
                p = p, threads = threads, activeId = activeChatId,
                onPick = { ChatController.openHistory(it); showHistory = false },
                onDelete = { ChatController.deleteThread(it) },
                onNew = { ChatController.newChat(); showHistory = false },
                onClearAll = { scope.launch { ChatHistoryStore.deleteAll() } },
            )
        }
    }
    if (showModels) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showModels = false }, sheetState = st, containerColor = p.surface) {
            ModelSheet(
                p = p, loadState = loadState,
                onPickLocal = { path ->
                    DiaPrefs.setCloudEnabled(false)
                    scope.launch { ModelManager.load(context, path) }
                    showModels = false
                },
                onPickCloud = { DiaPrefs.setCloudEnabled(true); showModels = false },
                onImport = { showModels = false; onOpenPage(ToolPage.MODEL_SETUP) },
                onUnload = { scope.launch { ModelManager.unload() }; showModels = false },
                onSwitchBackend = { b -> scope.launch { ModelManager.reload(context, b) }; showModels = false },
            )
        }
    }
    if (showMemory) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showMemory = false }, sheetState = st, containerColor = p.surface) {
            MemorySheet(p)
        }
    }
    if (showBackups) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showBackups = false }, sheetState = st, containerColor = p.surface) {
            BackupSheet(p, onAttach = { ref: FileRef -> ChatController.addExistingFile(ref); showBackups = false })
        }
    }
    if (showBubble) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showBubble = false }, sheetState = st, containerColor = p.surface) {
            BubbleEditorSheet(p)
        }
    }
    if (showSelfLoop) {
        SelfLoopDialog(p, onDismiss = { showSelfLoop = false }) { topic, a, b, rounds ->
            showSelfLoop = false
            DiaSettings.selfLoopRoleA.set(a)
            DiaSettings.selfLoopRoleB.set(b)
            DiaSettings.selfLoopRounds.set(rounds)
            ChatController.startSelfLoop(topic, a, b, rounds)
        }
    }
    if (showTools) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showTools = false }, sheetState = st, containerColor = p.surface) {
            ToolPanelSheet(
                p = p,
                onRun = { name, args, thenAi ->
                    showTools = false
                    ChatController.runToolNow(name, args, thenAi)
                },
                onSay = { t -> showTools = false; input = t },
            )
        }
    }
    editing?.let { m ->
        EditMessageDialog(p, m.text, onDismiss = { editing = null }) { newText ->
            editing = null
            ChatController.editAndResend(m.id, newText)
        }
    }
    viewingImage?.let { path ->
        Dialog(onDismissRequest = { viewingImage = null }) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.Black).clickable { viewingImage = null }) {
                LocalImage(path, Modifier.fillMaxWidth(), maxDim = 2048, contentScale = ContentScale.FillWidth)
            }
        }
    }
}

private fun copy(context: Context, text: String) {
    val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clip.setPrimaryClip(ClipData.newPlainText("灵犀", text))
    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
}

// ───────── 头部 ─────────

@Composable
private fun ChatHeader(
    p: DiaPalette,
    title: String,
    loadState: ModelLoadState,
    cloudOn: Boolean,
    wuji: Boolean,
    onWuji: () -> Unit,
    thinking: Boolean,
    fontScale: Float,
    onHistory: () -> Unit,
    onModel: () -> Unit,
    onNew: () -> Unit,
    onToggleThinking: () -> Unit,
    onFont: () -> Unit,
    onMemory: () -> Unit,
    onBackups: () -> Unit,
    onBubble: () -> Unit,
    onTheme: () -> Unit,
    onClear: () -> Unit,
    onSettings: () -> Unit,
    onDeep: () -> Unit,
    deepRunning: Int,
    onThemePage: () -> Unit,
    onAiFolder: () -> Unit,
    onTools: () -> Unit,
) {
    val statusColor = when {
        cloudOn -> p.indigo
        loadState is ModelLoadState.Ready -> p.bamboo
        loadState is ModelLoadState.Loading -> p.gold
        loadState is ModelLoadState.Error -> p.error
        else -> p.textTertiary
    }
    val sub = when {
        cloudOn -> "云端 · ${DiaPrefs.cloudModel.collectAsState().value}"
        loadState is ModelLoadState.Ready -> "本地 · ${loadState.modelName} · ${loadState.backend}"
        loadState is ModelLoadState.Loading -> "加载中 · ${loadState.progress}"
        loadState is ModelLoadState.Error -> if (loadState.oom) "内存不足，点此换模型" else "模型加载失败，点此重选"
        else -> "未加载模型 · 点此选择"
    }
    val stepMode by DiaSettings.stepThinking.flow.collectAsState()
    val autoApprove by DiaSettings.autoApprove.flow.collectAsState()
    val voiceConv by DiaSettings.voiceConversation.flow.collectAsState()
    var menu by remember { mutableStateOf(false) }
    Column {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onHistory) { ThemedIcon("header.history", Icons.Rounded.History, "历史对话", p.textSecondary) }
            Row(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable(onClick = onModel)
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                InkAvatar(36.dp, Modifier.inkStroke(p.ink.copy(alpha = 0.5f), CircleShape, 1.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (title == "新对话") (if (wuji) "灵犀 · 无极" else "灵犀") else title,
                        style = MaterialTheme.typography.titleLarge, color = p.text,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(statusColor))
                        Spacer(Modifier.width(5.dp))
                        Text(sub, style = MaterialTheme.typography.labelSmall, color = p.textTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false))
                        Icon(Icons.Rounded.KeyboardArrowDown, null, tint = p.textTertiary, modifier = Modifier.size(14.dp))
                    }
                }
            }
            // 🧠 自主长思入口（有长思在跑时显示数量）
            Box(
                Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onDeep),
                contentAlignment = Alignment.Center,
            ) {
                ThemedGlyph("header.deep", "思", if (deepRunning > 0) p.gold else p.textTertiary, 24.dp)
                if (deepRunning > 0) {
                    Box(Modifier.align(Alignment.TopEnd).padding(5.dp).size(8.dp).clip(CircleShape).background(p.cinnabar))
                }
            }
            // ☯ 无极模式开关
            WujiButton(p, wuji, onWuji)
            IconButton(onClick = onNew) { ThemedIcon("header.new", Icons.Rounded.Add, "新对话", p.textSecondary) }
            Box {
                IconButton(onClick = { menu = true }) { ThemedIcon("header.more", Icons.Rounded.MoreVert, "更多", p.textSecondary) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("🧠 自主长思" + if (deepRunning > 0) "（$deepRunning 个运行中）" else "") }, onClick = { menu = false; onDeep() })
                    DropdownMenuItem(text = { Text("🗡 工具台（亲自调用工具）") }, onClick = { menu = false; onTools() })
                    DropdownMenuItem(text = { Text("🗂 AI 文件夹") }, onClick = { menu = false; onAiFolder() })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text(if (wuji) "☯ 无极模式：开" else "☯ 无极模式：关") }, onClick = { menu = false; onWuji() })
                    DropdownMenuItem(
                        text = { Text("分步思考：" + when (stepMode) { "on" -> "总是"; "off" -> "关闭"; else -> "自动" }) },
                        onClick = {
                            menu = false
                            DiaSettings.stepThinking.set(when (stepMode) { "auto" -> "on"; "on" -> "off"; else -> "auto" })
                        },
                    )
                    DropdownMenuItem(text = { Text(if (thinking) "深度思考：开" else "深度思考：关") }, onClick = { menu = false; onToggleThinking() })
                    DropdownMenuItem(text = { Text(if (autoApprove) "自动批准操作：开" else "自动批准操作：关") }, onClick = { menu = false; DiaSettings.autoApprove.set(!autoApprove) })
                    DropdownMenuItem(text = { Text(if (voiceConv) "语音对话：开" else "语音对话：关") }, onClick = { menu = false; DiaSettings.voiceConversation.set(!voiceConv) })
                    HorizontalDivider()
                    DropdownMenuItem(text = {
                        Text("字号：" + when { fontScale < 0.95f -> "小"; fontScale < 1.15f -> "标准"; else -> "大" })
                    }, onClick = { menu = false; onFont() })
                    DropdownMenuItem(
                        text = { Text("主题：" + LocalThemePack.current.name + " → 切换") },
                        onClick = { menu = false; onTheme() },
                    )
                    DropdownMenuItem(text = { Text("🏮 主题与图标（导入 / 自定义）") }, onClick = { menu = false; onThemePage() })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("记忆管理") }, onClick = { menu = false; onMemory() })
                    DropdownMenuItem(text = { Text("文件备份与还原") }, onClick = { menu = false; onBackups() })
                    DropdownMenuItem(text = { Text("悬浮气泡设置") }, onClick = { menu = false; onBubble() })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("清空当前对话") }, onClick = { menu = false; onClear() })
                    DropdownMenuItem(text = { Text("设置") }, onClick = { menu = false; onSettings() })
                }
            }
        }
        CloudDivider(p, Modifier.padding(horizontal = 18.dp))
    }
}

/** 顶栏的「☯」：开着时金光缓缓旋转。 */
@Composable
private fun WujiButton(p: DiaPalette, on: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "wuji")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "rot")
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .background(if (on) p.gold.copy(alpha = 0.18f) else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.graphicsLayer { rotationZ = if (on) rot else 0f }) {
            ThemedGlyph("header.wuji", "☯", if (on) p.gold else p.textTertiary, 26.dp, brush = false)
        }
    }
}

// ───────── 空状态 ─────────

@Composable
private fun EmptyHero(
    p: DiaPalette,
    wuji: Boolean,
    loadState: ModelLoadState,
    modelReady: Boolean,
    onPickModel: () -> Unit,
    onSuggestion: (String) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp, start = 22.dp, end = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (wuji) {
            Spacer(Modifier.height(24.dp))
            Text("无 极", fontFamily = DiaBrush, fontSize = 64.sp, color = p.gold)
            Text("调动全部权限 · 深度与分布式思考 · 不达目的不罢休", style = MaterialTheme.typography.bodySmall, color = p.textSecondary)
            Spacer(Modifier.height(18.dp))
        } else {
            InkHero(p, Modifier.fillMaxWidth().heightIn(max = 230.dp))
            Text("仗剑天涯 · 有问必答", style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaBrush)
            Spacer(Modifier.height(4.dp))
            Text(
                "聊天、看图、改文档、联网、翻译、画图、操控手机、自主长思——一句话，灵犀自己挑兵器；「器」里也能亲自点兵",
                style = MaterialTheme.typography.bodySmall, color = p.textSecondary,
            )
            Spacer(Modifier.height(16.dp))
        }
        if (!modelReady) {
            val (t, s) = when (loadState) {
                is ModelLoadState.Loading -> "正在加载模型…" to loadState.progress
                is ModelLoadState.Error -> "模型加载失败" to loadState.message.take(120)
                else -> "还没有加载模型" to "点这里选择本地模型，或在设置里配置云端模型"
            }
            val shape = InkBubbleShape(7)
            Column(
                Modifier.fillMaxWidth().clip(shape).background(p.surface.copy(alpha = p.bubbleAlpha)).paperGrain(0.08f)
                    .inkStroke(p.ink.copy(alpha = 0.5f), shape).clickable(onClick = onPickModel).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (loadState is ModelLoadState.Loading) {
                    CircularProgressIndicator(color = p.cinnabar, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.height(8.dp))
                }
                Text(t, style = MaterialTheme.typography.titleMedium, color = p.text)
                Text(s, style = MaterialTheme.typography.bodySmall, color = p.textTertiary)
            }
            Spacer(Modifier.height(14.dp))
        }
        val suggestions = if (wuji) listOf(
            "调研国产新能源车三大技术路线，写成一份带表格的 Word 报告",
            "把我下载目录里最新的 PDF 改写成通俗版并另存",
            "看看我手机上有哪些未读通知，挑重要的告诉我",
            "规划一份三天两夜的杭州旅行，并做成 PPT",
        ) else listOf(
            "/长思 研究国产大模型的技术路线，写成完整报告",
            "换成水墨太极主题",
            "联网查一下今天有什么重要新闻",
            "/分步 年轻人该如何开始理财",
            "@计算 (1280+360)*12",
            "看看你的 AI 文件夹里有什么",
            "/画 烟雨江南，小桥流水，水墨画风",
            "帮我写一份请假条，存成 Word",
        )
        for (row in suggestions.chunked(2)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((i, s) in row.withIndex()) {
                    val shape = InkBubbleShape(s.hashCode() + i, floatArrayOf(6f, 14f, 6f, 14f))
                    Box(
                        Modifier.weight(1f).padding(vertical = 4.dp).clip(shape)
                            .background(p.surface.copy(alpha = p.bubbleAlpha * 0.85f)).paperGrain(0.07f)
                            .inkStroke(p.ink.copy(alpha = 0.35f), shape, 0.9.dp)
                            .clickable { onSuggestion(s) }.padding(horizontal = 12.dp, vertical = 10.dp),
                    ) {
                        Text(s, style = MaterialTheme.typography.bodySmall, color = p.textSecondary, maxLines = 2)
                    }
                }
            }
        }
    }
}

// ───────── 消息 ─────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun UserBubble(
    p: DiaPalette,
    m: ChatMessage,
    fontScale: Float,
    onImage: (String) -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().padding(start = 56.dp, end = 14.dp, top = 6.dp, bottom = 2.dp),
        horizontalAlignment = Alignment.End,
    ) {
        if (m.imagePaths.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (path in m.imagePaths) {
                    LocalImage(
                        path,
                        Modifier.size(96.dp).clip(RoundedCornerShape(10.dp)).clickable { onImage(path) },
                        maxDim = 400, contentScale = ContentScale.Crop,
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        if (m.fileNames.isNotEmpty()) {
            for (n in m.fileNames) FileChip(p, n, null)
            Spacer(Modifier.height(4.dp))
        }
        if (m.text.isNotBlank()) {
            val shape = remember(m.id) { InkBubbleShape(m.id.hashCode(), floatArrayOf(18f, 5f, 18f, 18f)) }
            Box {
                Box(
                    Modifier.clip(shape).background(p.userBubble.copy(alpha = 0.94f)).paperGrain(if (p.isDark) 0.10f else 0.14f)
                        .inkStroke(p.ink.copy(alpha = if (p.isDark) 0.25f else 0.55f), shape, 1.dp)
                        .combinedClickable(onClick = {}, onLongClick = { menu = true })
                        .padding(horizontal = 15.dp, vertical = 10.dp),
                ) {
                    Text(
                        m.text,
                        style = MaterialTheme.typography.bodyLarge.copy(fontSize = (15 * fontScale).sp, lineHeight = (23 * fontScale).sp),
                        color = p.onUserBubble,
                    )
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("复制") }, onClick = { menu = false; onCopy() })
                    DropdownMenuItem(text = { Text("编辑后重新发送") }, onClick = { menu = false; onEdit() })
                }
            }
        }
        if (!m.hiddenContext.isNullOrBlank()) {
            Text("（附带了屏幕内容）", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
        }
    }
}

@Composable
private fun AssistantBubble(
    p: DiaPalette,
    m: ChatMessage,
    fontScale: Float,
    speaking: Boolean,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onRetry: () -> Unit,
    onDelete: () -> Unit,
) {
    val isPersonaB = m.persona != null && m.persona == ChatController.selfLoop.collectAsState().value.roleB
    Row(
        Modifier.fillMaxWidth().padding(start = 10.dp, end = 36.dp, top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (m.persona != null) {
            SealMark(m.persona.take(1), size = 30.dp, color = if (isPersonaB) p.indigo else p.gold)
        } else {
            InkAvatar(32.dp)
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                m.persona ?: (m.source ?: "灵犀"),
                style = MaterialTheme.typography.labelSmall, color = p.textTertiary,
                modifier = Modifier.padding(start = 2.dp, bottom = 3.dp),
            )
            if (!m.thinking.isNullOrBlank() || m.isThinking) {
                ThinkingTrace(p, m.thinking.orEmpty(), m.isThinking, fontScale)
                Spacer(Modifier.height(4.dp))
            }
            val shape = remember(m.id) { InkBubbleShape(m.id.hashCode(), floatArrayOf(5f, 18f, 18f, 18f)) }
            Box(
                Modifier.clip(shape)
                    .background(p.surface.copy(alpha = p.bubbleAlpha))
                    .paperGrain(if (p.isDark) 0.06f else 0.10f)
                    .inkStroke(p.ink.copy(alpha = if (p.isDark) 0.35f else 0.55f), shape)
                    .padding(horizontal = 15.dp, vertical = 11.dp),
            ) {
                when {
                    m.isError -> Column {
                        Text(m.text, style = MaterialTheme.typography.bodyMedium, color = p.error)
                        if (m.isRetryable) {
                            Spacer(Modifier.height(6.dp))
                            Text("点此重试", color = p.cinnabar, style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.clickable(onClick = onRetry))
                        }
                    }
                    m.text.isEmpty() && m.isStreaming -> TypingDots(p)
                    else -> SelectionContainer { MarkdownContent(p, cleanLaTeX(m.text), fontScale) }
                }
            }
            if (!m.isStreaming && m.text.isNotEmpty() && !m.isError) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCopy, modifier = Modifier.size(30.dp)) {
                        ThemedIcon("msg.copy", Icons.Rounded.ContentCopy, "复制", p.textTertiary, 16.dp)
                    }
                    IconButton(onClick = onSpeak, modifier = Modifier.size(30.dp)) {
                        if (speaking) ThemedIcon("msg.mute", Icons.AutoMirrored.Rounded.VolumeOff, "停止朗读", p.cinnabar, 16.dp)
                        else ThemedIcon("msg.speak", Icons.AutoMirrored.Rounded.VolumeUp, "朗读", p.textTertiary, 16.dp)
                    }
                    IconButton(onClick = onRetry, modifier = Modifier.size(30.dp)) {
                        ThemedIcon("msg.retry", Icons.Rounded.Refresh, "重新生成", p.textTertiary, 16.dp)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                        ThemedIcon("msg.delete", Icons.Rounded.Delete, "删除", p.textTertiary, 16.dp)
                    }
                }
            }
        }
    }
}

/**
 * 工具卡片：竹简样式（左侧一道竹青 / 朱砂竖笔）。
 * 明确显示：第几步、AI 说明的意图、调用了哪个工具、参数、耗时、结果；用户亲自调用的标「亲」。
 */
@Composable
private fun ToolCard(p: DiaPalette, m: ChatMessage) {
    var expanded by remember { mutableStateOf(false) }
    var showArgs by remember { mutableStateOf(false) }
    val running = m.status == "running"
    val color = when (m.status) {
        "error" -> p.error
        "done" -> p.bamboo
        else -> p.gold
    }
    val shape = remember(m.id) { InkBubbleShape(m.id.hashCode(), floatArrayOf(4f, 10f, 10f, 4f), 0.8f) }
    Column(
        Modifier.fillMaxWidth().padding(start = 50.dp, end = 24.dp, top = 2.dp, bottom = 2.dp)
            .clip(shape).background(p.surfaceAlt.copy(alpha = p.bubbleAlpha * 0.92f)).paperGrain(0.06f)
            .drawBehind {
                // 竹简：左侧竖笔 + 淡淡的横纹
                drawRect(color.copy(alpha = 0.75f), size = androidx.compose.ui.geometry.Size(3.dp.toPx(), size.height))
                var y = 9.dp.toPx()
                while (y < size.height) {
                    drawLine(p.ink.copy(alpha = 0.05f), Offset(8.dp.toPx(), y), Offset(size.width, y), 0.6.dp.toPx())
                    y += 9.dp.toPx()
                }
            }
            .inkStroke(color.copy(alpha = 0.45f), shape, 0.8.dp)
            .clickable(enabled = !m.detail.isNullOrBlank() || !m.args.isNullOrBlank()) { expanded = !expanded }
            .padding(start = 14.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
    ) {
        // 意图：这一步要做什么（AI 自己说明的；用户亲自调用时显示「你亲自调用」）
        if (!m.reason.isNullOrBlank()) {
            Text(
                "💭 " + m.reason, style = MaterialTheme.typography.labelSmall, color = p.textSecondary,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 22.dp, bottom = 3.dp),
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (running) {
                CircularProgressIndicator(color = color, strokeWidth = 1.5.dp, modifier = Modifier.size(14.dp))
            } else if (m.status == "error") {
                ThemedIcon("card.error", Icons.Rounded.Warning, null, color, 15.dp)
            } else {
                ThemedIcon("card.done", Icons.Rounded.CheckCircle, null, color, 15.dp)
            }
            Spacer(Modifier.width(6.dp))
            if (m.stepNo > 0) {
                Text("步骤${m.stepNo}", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
                Spacer(Modifier.width(4.dp))
            }
            ToolGlyph(m.toolName, p.text, 16.dp)
            Spacer(Modifier.width(4.dp))
            Text(
                m.title ?: m.toolName.orEmpty(),
                style = MaterialTheme.typography.labelLarge, color = p.text,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            if (m.byUser) {
                Box(
                    Modifier.padding(start = 4.dp).clip(RoundedCornerShape(4.dp)).background(p.cinnabar.copy(alpha = 0.85f))
                        .padding(horizontal = 3.dp),
                ) { ThemedGlyph("card.user", "亲", p.onCinnabar, 14.dp) }
            }
            if (m.durationMs > 0) {
                Text(
                    if (m.durationMs < 1000) "${m.durationMs}ms" else "%.1fs".format(m.durationMs / 1000f),
                    style = MaterialTheme.typography.labelSmall, color = p.textTertiary, modifier = Modifier.padding(start = 4.dp),
                )
            }
            if (!m.detail.isNullOrBlank() || !m.args.isNullOrBlank()) {
                Box(Modifier.graphicsLayer { rotationZ = if (expanded) 180f else 0f }) {
                    ThemedIcon("card.expand", Icons.Rounded.KeyboardArrowDown, null, p.textTertiary, 16.dp)
                }
            }
        }
        if (m.text.isNotBlank()) {
            Text(m.text, style = MaterialTheme.typography.bodySmall, color = if (m.status == "error") p.error else p.textSecondary,
                modifier = Modifier.padding(top = 4.dp, start = 22.dp))
        }
        AnimatedVisibility(visible = expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Column(Modifier.padding(top = 6.dp)) {
                val args = m.args
                if (!args.isNullOrBlank()) {
                    Text(
                        if (showArgs) "▾ 调用参数" else "▸ 调用参数（${m.toolName.orEmpty()}）",
                        style = MaterialTheme.typography.labelSmall, color = p.indigo,
                        modifier = Modifier.clickable { showArgs = !showArgs }.padding(vertical = 2.dp),
                    )
                    if (showArgs) {
                        SelectionContainer {
                            Text(args, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), color = p.textSecondary,
                                modifier = Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState()))
                        }
                    }
                }
                val detail = m.detail
                if (!detail.isNullOrBlank()) {
                    SelectionContainer {
                        Text(
                            detail,
                            style = MaterialTheme.typography.bodySmall, color = p.textSecondary,
                            modifier = Modifier.padding(top = 4.dp).heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConfirmCard(p: DiaPalette, m: ChatMessage, onResolve: (Boolean) -> Unit) {
    if (m.status == "auto") {
        var open by remember { mutableStateOf(false) }
        Column(
            Modifier.fillMaxWidth().padding(start = 50.dp, end = 24.dp, top = 1.dp, bottom = 1.dp)
                .clip(RoundedCornerShape(8.dp)).clickable { open = !open }.padding(horizontal = 8.dp, vertical = 4.dp),
        ) {
            Text("⚡ 已自动批准：${m.title.orEmpty()}", style = MaterialTheme.typography.labelMedium, color = p.gold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            AnimatedVisibility(open) {
                Text(m.detail.orEmpty(), style = MaterialTheme.typography.bodySmall, color = p.textSecondary, modifier = Modifier.padding(top = 2.dp))
            }
        }
        return
    }
    val pending = m.status == "pending"
    val shape = remember(m.id) { InkBubbleShape(m.id.hashCode(), floatArrayOf(10f, 10f, 10f, 10f)) }
    Column(
        Modifier.fillMaxWidth().padding(start = 50.dp, end = 24.dp, top = 4.dp, bottom = 4.dp)
            .clip(shape).background(p.surface.copy(alpha = p.bubbleAlpha)).paperGrain(0.08f)
            .inkStroke(p.cinnabar.copy(alpha = if (pending) 0.85f else 0.3f), shape, 1.2.dp)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (LocalThemePack.current.icons["card.confirm"] != null) ThemedGlyph("card.confirm", "令", p.cinnabar, 24.dp)
            else SealMark("令", size = 22.dp)
            Spacer(Modifier.width(8.dp))
            Text(m.title.orEmpty(), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold), color = p.text)
        }
        Spacer(Modifier.height(6.dp))
        Text(m.detail.orEmpty(), style = MaterialTheme.typography.bodySmall, color = p.textSecondary)
        Spacer(Modifier.height(10.dp))
        if (pending) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.clip(RoundedCornerShape(6.dp)).background(p.cinnabar).clickable { onResolve(true) }
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                ) { Text("准", color = p.onCinnabar, fontFamily = DiaBrush, fontSize = 18.sp) }
                Box(
                    Modifier.clip(RoundedCornerShape(6.dp)).border(1.dp, p.border, RoundedCornerShape(6.dp))
                        .clickable { onResolve(false) }.padding(horizontal = 18.dp, vertical = 8.dp),
                ) { Text("驳", color = p.textSecondary, fontFamily = DiaBrush, fontSize = 18.sp) }
                Spacer(Modifier.weight(1f))
                Text("开「☯ 无极」或「自动批准」后不再询问", style = MaterialTheme.typography.labelSmall, color = p.textTertiary, maxLines = 2,
                    modifier = Modifier.widthIn(max = 150.dp))
            }
        } else {
            Text(
                if (m.status == "approved") "✓ 已准" else "✗ 已驳回",
                color = if (m.status == "approved") p.bamboo else p.textTertiary,
                style = MaterialTheme.typography.labelMedium,
            )
        }
    }
}

/** 分步思考 / 无极分布式思考的「思考树」卡片。拆解完成后可以修改、增删小问题再求解。 */
@Composable
private fun PlanCard(p: DiaPalette, m: ChatMessage, review: PlanReview? = null) {
    if (review != null) {
        PlanReviewEditor(p, m, review)
        return
    }
    val running = m.status == "running"
    var expanded by remember { mutableStateOf(true) }
    LaunchedEffect(m.status) { if (m.status == "done") expanded = false }
    val shape = remember(m.id) { InkBubbleShape(m.id.hashCode(), floatArrayOf(4f, 14f, 14f, 14f), 1f) }
    val accent = if (p.id == "wuji") p.gold else p.indigo
    Column(
        Modifier.fillMaxWidth().padding(start = 50.dp, end = 20.dp, top = 3.dp, bottom = 3.dp)
            .clip(shape).background(p.surface.copy(alpha = p.bubbleAlpha)).paperGrain(0.07f)
            .inkStroke(accent.copy(alpha = 0.6f), shape, 1.dp)
            .clickable { expanded = !expanded }
            .padding(horizontal = 12.dp, vertical = 9.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (running) {
                val t = rememberInfiniteTransition(label = "plan")
                val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "r")
                Text("☯", color = accent, fontSize = 16.sp, modifier = Modifier.graphicsLayer { rotationZ = rot })
            } else if (m.status == "stopped") {
                Text("⏹", color = accent, fontSize = 16.sp)
            } else {
                ThemedGlyph("card.plan", "☯", accent, 18.dp, brush = false)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                m.title.orEmpty(), style = MaterialTheme.typography.titleSmall, color = p.text,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            Icon(Icons.Rounded.KeyboardArrowDown, null, tint = p.textTertiary,
                modifier = Modifier.size(16.dp).graphicsLayer { rotationZ = if (expanded) 180f else 0f })
        }
        AnimatedVisibility(visible = expanded && !m.detail.isNullOrBlank()) {
            SelectionContainer {
                Text(
                    m.detail.orEmpty(),
                    style = MaterialTheme.typography.bodySmall.copy(lineHeight = 19.sp),
                    color = p.textSecondary,
                    modifier = Modifier.padding(top = 6.dp).heightIn(max = 460.dp)
                        .verticalScroll(rememberScrollState()),
                )
            }
        }
    }
}

/** 拆解出的小问题：改写、缩进、删除、添加，然后「开始求解」。 */
@Composable
private fun PlanReviewEditor(p: DiaPalette, m: ChatMessage, r: PlanReview) {
    val accent = if (p.id == "wuji") p.gold else p.indigo
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(r.held, r.deadline) {
        while (!r.held) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(400) }
    }
    val left = ((r.deadline - now) / 1000).coerceAtLeast(0)
    val items = r.items
    fun edit(f: (MutableList<com.dia.app.agent.StepThinker.StepItem>) -> Unit) {
        val list = items.toMutableList(); f(list); ChatController.updatePlanReview(list)
    }
    val shape = remember(m.id) { InkBubbleShape(m.id.hashCode(), floatArrayOf(4f, 14f, 14f, 14f), 1f) }
    Column(
        Modifier.fillMaxWidth().padding(start = 40.dp, end = 12.dp, top = 3.dp, bottom = 3.dp)
            .clip(shape).background(p.surface.copy(alpha = p.bubbleAlpha)).paperGrain(0.07f)
            .inkStroke(p.cinnabar.copy(alpha = 0.7f), shape, 1.2.dp)
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ThemedGlyph("card.plan", "☯", accent, 18.dp, brush = false)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("拆成了 ${items.size} 个小问题，可以改了再求解", style = MaterialTheme.typography.titleSmall, color = p.text)
                Text(
                    if (r.held) "已暂停自动开始：改好后点「开始求解」" else "$left 秒后自动开始 · 点「先别动」可以慢慢改",
                    style = MaterialTheme.typography.labelSmall, color = p.textTertiary,
                )
            }
            if (!r.held) {
                Text("先别动", color = p.cinnabar, style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { ChatController.holdPlanReview() }.padding(6.dp))
            }
        }
        Spacer(Modifier.height(6.dp))
        for ((i, it) in items.withIndex()) {
            Row(
                Modifier.fillMaxWidth().padding(start = ((it.depth - 1).coerceIn(0, 3) * 16).dp, top = 2.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (it.depth <= 1) "${items.take(i + 1).count { x -> x.depth <= 1 }}." else "·", color = p.textTertiary,
                    style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(20.dp))
                var text by remember(r.cardId, i, it.text) { mutableStateOf(it.text) }
                BasicTextField(
                    value = text,
                    onValueChange = { v -> text = v; edit { l -> l[i] = l[i].copy(text = v) } },
                    textStyle = TextStyle(color = p.text, fontSize = 13.sp, lineHeight = 19.sp),
                    cursorBrush = SolidColor(p.cinnabar),
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(p.surfaceAlt.copy(alpha = 0.6f))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                )
                Text(if (it.search) "🔍" else "🔎", fontSize = 13.sp, modifier = Modifier.alpha(if (it.search) 1f else 0.35f)
                    .clickable { edit { l -> l[i] = l[i].copy(search = !l[i].search) } }.padding(horizontal = 4.dp))
                Text("⇤", color = p.textSecondary, modifier = Modifier.clickable { edit { l -> l[i] = l[i].copy(depth = (l[i].depth - 1).coerceAtLeast(1)) } }.padding(horizontal = 4.dp))
                Text("⇥", color = p.textSecondary, modifier = Modifier.clickable { edit { l -> l[i] = l[i].copy(depth = (l[i].depth + 1).coerceAtMost(4)) } }.padding(horizontal = 4.dp))
                Text("✕", color = p.error, modifier = Modifier.clickable { edit { l -> l.removeAt(i) } }.padding(horizontal = 4.dp))
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("＋ 添加小问题", color = p.indigo, style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                    edit { l -> l.add(com.dia.app.agent.StepThinker.StepItem(1, "新的小问题", false)) }
                }.padding(6.dp))
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.clip(RoundedCornerShape(8.dp)).background(p.cinnabar).clickable { ChatController.confirmPlanReview() }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text("开始求解", color = p.onCinnabar, style = MaterialTheme.typography.labelLarge) }
        }
    }
}

/** 对话顶部：自主长思正在后台运行。 */
@Composable
private fun DeepBanner(p: DiaPalette, s: com.dia.app.deep.DeepSession, count: Int, onOpen: () -> Unit) {
    val (d, t) = com.dia.app.deep.PlanOps.counts(s.plan)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).clip(RoundedCornerShape(10.dp))
            .background(p.gold.copy(alpha = 0.13f)).border(0.6.dp, p.gold.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
            .clickable(onClick = onOpen).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val tr = rememberInfiniteTransition(label = "deep")
        val a by tr.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
        Box(Modifier.size(7.dp).clip(CircleShape).background(p.gold.copy(alpha = if (s.status == "review") 1f else a)))
        Spacer(Modifier.width(8.dp))
        Text(
            (if (count > 1) "$count 个长思运行中 · " else "长思 · ") + s.topic.take(16) + " · 第 ${s.cycles} 轮 · $d/$t · " + s.activity.take(30),
            style = MaterialTheme.typography.labelSmall, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
        )
        Text("查看", style = MaterialTheme.typography.labelSmall, color = p.cinnabar)
    }
}

@Composable
private fun GeneratedImageCard(p: DiaPalette, m: ChatMessage, onOpen: (String) -> Unit, onSave: (String) -> Unit) {
    val path = m.imagePaths.firstOrNull() ?: return
    Column(Modifier.fillMaxWidth().padding(start = 48.dp, end = 32.dp, top = 4.dp, bottom = 4.dp)) {
        LocalImage(
            path,
            Modifier.fillMaxWidth().heightIn(max = 360.dp).clip(RoundedCornerShape(12.dp)).scrollFrame(p, 12.dp).clickable { onOpen(path) },
            maxDim = 1024, contentScale = ContentScale.FillWidth,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                m.detail.orEmpty(), style = MaterialTheme.typography.labelSmall, color = p.textTertiary,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(top = 4.dp),
            )
            IconButton(onClick = { onSave(path) }) { ThemedIcon("msg.save", Icons.Rounded.Save, "保存到相册", p.textSecondary, 18.dp) }
        }
    }
}

@Composable
private fun NoteRow(p: DiaPalette, text: String) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium, color = p.textTertiary,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(p.surfaceAlt.copy(alpha = p.bubbleAlpha * 0.8f))
                .border(0.6.dp, p.border, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
        )
    }
}

@Composable
fun LocalImage(path: String, modifier: Modifier, maxDim: Int = 1024, contentScale: ContentScale = ContentScale.Fit) {
    val bmp by produceState<Bitmap?>(initialValue = null, path, maxDim) {
        value = withContext(Dispatchers.IO) { ImageUtil.decodeFile(path, maxDim) }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = modifier, contentScale = contentScale)
    } else {
        Box(modifier.background(Color.Gray.copy(alpha = 0.2f)).heightIn(min = 80.dp))
    }
}

@Composable
private fun FileChip(p: DiaPalette, name: String, onRemove: (() -> Unit)?) {
    Row(
        Modifier.padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp)).background(p.surfaceAlt)
            .border(0.6.dp, p.border, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("📎 ", fontSize = 12.sp)
        Text(name, style = MaterialTheme.typography.labelMedium, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 200.dp))
        if (onRemove != null) {
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Rounded.Close, "移除", tint = p.textTertiary, modifier = Modifier.size(14.dp).clickable(onClick = onRemove))
        }
    }
}

@Composable
private fun ThinkingTrace(p: DiaPalette, text: String, inProgress: Boolean, fontScale: Float) {
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(inProgress) { if (inProgress) expanded = true }
    Column {
        Row(
            Modifier.clickable { expanded = !expanded }.padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ThemedIcon("msg.thinking", Icons.Rounded.AutoAwesome, null, p.gold, 14.dp)
            Spacer(Modifier.width(4.dp))
            Text(if (inProgress) "思考中…" else "查看思考过程", style = MaterialTheme.typography.labelMedium, color = p.gold)
        }
        AnimatedVisibility(visible = expanded && text.isNotBlank()) {
            val line = p.gold.copy(alpha = 0.4f)
            Text(
                text,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = (12 * fontScale).sp),
                color = p.textSecondary,
                modifier = Modifier.padding(top = 2.dp)
                    .drawBehind { drawLine(line, Offset(0f, 0f), Offset(0f, size.height), 2.dp.toPx()) }
                    .padding(start = 10.dp),
            )
        }
    }
}

@Composable
private fun MarkdownContent(p: DiaPalette, text: String, fontScale: Float) {
    ProvideTextStyle(
        TextStyle(fontSize = (14.5 * fontScale).sp, lineHeight = (23 * fontScale).sp, color = p.text, letterSpacing = 0.2.sp)
    ) {
        RichText(
            style = RichTextStyle(
                codeBlockStyle = CodeBlockStyle(
                    textStyle = TextStyle(fontSize = (12.5 * fontScale).sp, fontFamily = FontFamily.Monospace, color = p.indigo),
                ),
                stringStyle = RichTextStringStyle(
                    linkStyle = TextLinkStyles(style = SpanStyle(color = p.cinnabar)),
                    boldStyle = SpanStyle(fontWeight = FontWeight.SemiBold, color = p.text),
                    codeStyle = SpanStyle(fontFamily = FontFamily.Monospace, color = p.indigo, background = p.surfaceAlt),
                ),
            ),
        ) { Markdown(content = text) }
    }
}

@Composable
private fun TypingDots(p: DiaPalette) {
    val t = rememberInfiniteTransition(label = "typing")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(vertical = 4.dp)) {
        for (i in 0 until 3) {
            val a by t.animateFloat(0.2f, 0.9f, infiniteRepeatable(tween(600, delayMillis = i * 200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "d$i")
            Box(Modifier.size(6.dp).clip(CircleShape).background(p.cinnabar.copy(alpha = a)))
        }
    }
}

private fun cleanLaTeX(text: String): String {
    var r = text
    r = r.replace(Regex("\\$\\$(.+?)\\$\\$", RegexOption.DOT_MATCHES_ALL)) { it.groupValues[1].trim() }
    r = r.replace(Regex("\\\\frac\\{([^}]*)\\}\\{([^}]*)\\}")) { "${it.groupValues[1]}/${it.groupValues[2]}" }
    r = r.replace(Regex("\\\\sqrt\\{([^}]*)\\}")) { "√${it.groupValues[1]}" }
    r = r.replace("\\times", "×").replace("\\cdot", "·").replace("\\pm", "±")
        .replace("\\leq", "≤").replace("\\geq", "≥").replace("\\neq", "≠").replace("\\approx", "≈")
        .replace("\\infty", "∞").replace("\\pi", "π").replace("\\rightarrow", "→")
    return r
}

// ───────── 自循环横幅 / 附件 / 输入栏 ─────────

@Composable
private fun SelfLoopBanner(p: DiaPalette, s: SelfLoopState, onStop: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(12.dp))
            .background(p.gold.copy(alpha = 0.15f)).border(0.8.dp, p.gold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("🔄", fontSize = 14.sp)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("自循环 · 第 ${s.round}/${s.total} 轮", style = MaterialTheme.typography.labelLarge, color = p.text)
            Text("「${s.roleA}」⇄「${s.roleB}」· ${s.topic}", style = MaterialTheme.typography.labelSmall, color = p.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.clip(RoundedCornerShape(14.dp)).background(p.cinnabar).clickable(onClick = onStop)
                .padding(horizontal = 12.dp, vertical = 6.dp),
        ) { Text("停止", color = p.onCinnabar, style = MaterialTheme.typography.labelMedium) }
    }
}

@Composable
private fun PendingRow(p: DiaPalette, images: List<String>, files: List<FileRef>) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (path in images) {
            Box {
                LocalImage(path, Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)), maxDim = 200, contentScale = ContentScale.Crop)
                Box(
                    Modifier.align(Alignment.TopEnd).size(18.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.6f))
                        .clickable { ChatController.removePendingImage(path) },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Close, "移除", tint = Color.White, modifier = Modifier.size(12.dp)) }
            }
        }
        for (f in files) FileChip(p, "${f.id} · ${f.name}") { ChatController.removePendingFile(f.id) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun InputBar(
    p: DiaPalette,
    text: String,
    onText: (String) -> Unit,
    canSend: Boolean,
    generating: Boolean,
    loopRunning: Boolean,
    webOn: Boolean,
    placeholder: String,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onToolbox: () -> Unit,
    onTools: () -> Unit,
    onToggleWeb: () -> Unit,
    onVoice: (com.dia.app.llm.AudioClip) -> Unit,
    speech: SpeechInput,
    onSpeechText: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val recorder = remember { AudioScribeRecorder() }
    val recState by recorder.state.collectAsState()
    val elapsed by recorder.elapsedMs.collectAsState()
    val sttState by speech.state.collectAsState()
    val partial by speech.partial.collectAsState()
    val level by speech.level.collectAsState()
    val sttEngine by speech.engine.collectAsState()
    var hasMic by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var pendingRaw by remember { mutableStateOf(false) }

    fun startStt() {
        speech.start(
            DiaSettings.voiceLanguage.value,
            onResult = onSpeechText,
            onError = { e -> Toast.makeText(context, e, Toast.LENGTH_SHORT).show() },
        )
    }

    fun startVoice(raw: Boolean) {
        when {
            !raw && speech.isAvailable() -> startStt()
            com.dia.app.llm.DiaEngine.isReady -> recorder.start()
            else -> Toast.makeText(context, "还没有可用的语音识别：设置 → 语音转文字 → 下载离线中文模型（约 42MB）", Toast.LENGTH_LONG).show()
        }
    }

    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasMic = it
        if (it) startVoice(pendingRaw) else Toast.makeText(context, "需要麦克风权限才能语音输入", Toast.LENGTH_SHORT).show()
    }
    DisposableEffect(Unit) { onDispose { recorder.release() } }

    Column(
        modifier.fillMaxWidth().background(p.surface.copy(alpha = 0.94f)).paperGrain(if (p.isDark) 0.05f else 0.09f),
    ) {
        CloudDivider(p, Modifier.padding(horizontal = 4.dp))
        // ── 语音转文字中 ──
        if (sttState != SpeechInput.State.IDLE) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { speech.cancel() }) { ThemedIcon("input.cancel", Icons.Rounded.Close, "取消", p.textSecondary) }
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        for (i in 0 until 5) {
                            val h = (6 + 18 * (level * (0.5f + 0.5f * kotlin.math.sin((i + 1) * 1.7f + level * 6f)).coerceIn(0f, 1f))).dp
                            Box(Modifier.padding(horizontal = 1.5.dp).size(width = 3.dp, height = h).clip(RoundedCornerShape(2.dp)).background(p.cinnabar))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            (if (sttState == SpeechInput.State.PROCESSING) "正在识别…" else "请讲，说完点 ✓") +
                                if (sttEngine.isNotBlank()) "（$sttEngine）" else "",
                            color = p.cinnabar, style = MaterialTheme.typography.labelMedium,
                        )
                    }
                    if (partial.isNotBlank()) {
                        Text(partial, color = p.text, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                }
                IconButton(
                    onClick = { speech.stop() },
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(p.cinnabar),
                ) { ThemedIcon("input.done", Icons.Rounded.Check, "说完了", p.onCinnabar, 22.dp) }
            }
            return@Column
        }
        // ── 录原始语音（交给本机 Gemma 听） ──
        if (recState == AudioScribeRecorder.State.RECORDING) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { recorder.cancel() }) { ThemedIcon("input.cancel", Icons.Rounded.Close, "取消", p.textSecondary) }
                Text(
                    "正在录音 · ${"%.1f".format(elapsed / 1000f)} 秒（本机模型直接听）",
                    color = p.cinnabar, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f),
                )
                IconButton(
                    onClick = {
                        val bytes = recorder.stop()
                        if (bytes.isNotEmpty()) onVoice(com.dia.app.llm.AudioClip(pcm = bytes, sampleRate = recorder.sampleRate))
                    },
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(p.cinnabar),
                ) { ThemedIcon("input.send", Icons.AutoMirrored.Rounded.Send, "发送语音", p.onCinnabar, 20.dp) }
            }
            return@Column
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(p.cinnabar.copy(alpha = 0.12f))
                    .border(0.8.dp, p.cinnabar.copy(alpha = 0.35f), RoundedCornerShape(10.dp)).clickable(onClick = onToolbox),
                contentAlignment = Alignment.Center,
            ) { ThemedGlyph("input.toolbox", "囊", p.cinnabar, 30.dp) }
            val fieldShape = remember { InkBubbleShape(31, floatArrayOf(20f, 20f, 20f, 20f), 1f) }
            Box(
                Modifier.weight(1f).clip(fieldShape).background(p.background.copy(alpha = 0.55f))
                    .inkStroke(p.ink.copy(alpha = 0.35f), fieldShape, 0.9.dp).padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                if (text.isEmpty()) Text(placeholder, color = p.textTertiary, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                BasicTextField(
                    value = text, onValueChange = onText,
                    textStyle = TextStyle(color = p.text, fontSize = 15.sp, lineHeight = 22.sp),
                    cursorBrush = SolidColor(p.cinnabar),
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            // 器：工具台（亲自调用任意工具）
            Box(
                Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onTools),
                contentAlignment = Alignment.Center,
            ) { ThemedGlyph("input.tools", "器", p.gold, 26.dp) }
            Box(
                Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onToggleWeb),
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.alpha(if (webOn) 1f else 0.45f)) {
                    ThemedGlyph("input.web", "网", if (webOn) p.indigo else p.textTertiary, 26.dp)
                }
            }
            when {
                generating -> IconButton(
                    onClick = onStop,
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(p.error),
                ) { ThemedIcon("input.stop", Icons.Rounded.Stop, "停止", p.onCinnabar) }
                canSend || loopRunning -> IconButton(
                    onClick = { if (canSend) onSend() },
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(if (canSend) p.cinnabar else p.surfaceAlt),
                ) { ThemedIcon("input.send", Icons.AutoMirrored.Rounded.Send, "发送", p.onCinnabar, 20.dp) }
                else -> Box(
                    Modifier.size(44.dp).clip(CircleShape).background(p.indigo.copy(alpha = 0.15f))
                        .combinedClickable(
                            onClick = {
                                pendingRaw = false
                                if (hasMic) startVoice(false) else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                            },
                            onLongClick = {
                                pendingRaw = true
                                if (hasMic) startVoice(true) else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                            },
                        ),
                    contentAlignment = Alignment.Center,
                ) { ThemedIcon("input.mic", Icons.Rounded.Mic, "语音（点按转文字，长按录音）", p.indigo) }
            }
        }
    }
}

// ───────── 对话框 ─────────

@Composable
private fun EditMessageDialog(p: DiaPalette, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("编辑消息") },
        text = { OutlinedTextField(value = t, onValueChange = { t = it }, modifier = Modifier.fillMaxWidth(), minLines = 3) },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onConfirm(t) }) { Text("重新发送", color = p.cinnabar) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}

@Composable
private fun SelfLoopDialog(p: DiaPalette, onDismiss: () -> Unit, onStart: (String, String, String, Int) -> Unit) {
    var topic by remember { mutableStateOf("") }
    var a by remember { mutableStateOf(DiaSettings.selfLoopRoleA.value) }
    var b by remember { mutableStateOf(DiaSettings.selfLoopRoleB.value) }
    var rounds by remember { mutableStateOf(DiaSettings.selfLoopRounds.value.toString()) }
    val presets = listOf(
        Triple("提问者", "解答者", "苏格拉底式追问"),
        Triple("正方", "反方", "辩论"),
        Triple("作者", "编辑", "写作打磨"),
        Triple("产品经理", "工程师", "方案评审"),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("AI 自循环") },
        text = {
            Column {
                Text("让两个 AI 角色围绕主题自己对话。进行中你可以随时插话补充信息，或点停止。",
                    style = MaterialTheme.typography.bodySmall, color = p.textSecondary)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("讨论主题") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((x, y, label) in presets) {
                        Text(
                            label, style = MaterialTheme.typography.labelMedium, color = p.text,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(p.surfaceAlt)
                                .clickable { a = x; b = y }.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = a, onValueChange = { a = it }, label = { Text("角色甲") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = b, onValueChange = { b = it }, label = { Text("角色乙") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = rounds, onValueChange = { v -> rounds = v.filter { it.isDigit() }.take(2) }, label = { Text("轮数（每轮双方各说一次）") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (topic.isNotBlank()) onStart(topic.trim(), a.trim(), b.trim(), rounds.toIntOrNull()?.coerceIn(1, 30) ?: 6)
            }) { Text("开始", color = p.cinnabar) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}
