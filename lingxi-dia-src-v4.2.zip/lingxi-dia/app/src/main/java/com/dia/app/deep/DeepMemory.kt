package com.dia.app.deep

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * 长思的「外置记忆」（纯 JVM，不依赖 Android，可单元测试）。
 *
 * 借鉴 Manus「把文件系统当作无限上下文」、LangChain open_deep_research「研究员把结果压缩成带来源的笔记」、
 * BabyAGI「结果库」的做法：模型的上下文是有限的，所以一切有价值的东西都**先落盘、再登记**，
 * 之后每一轮只把「索引 + 与本步相关的要点」放进提示词，需要原文时按路径重读。
 *
 * 它解决三个问题：
 *  1. 找不到文件：所有文件登记在 manifest.json 并生成「00_目录索引.md」；按名字找文件时做模糊匹配
 *     （大小写、扩展名、空格标点、包含关系、相似度），AI 写错一点名字也能找到。
 *  2. 搜到了却没写下来：每次 web_search / read_webpage 的完整结果自动存档到「资料/」，不依赖 AI 记得去写。
 *  3. 重复搜索：同一个（或几乎相同的）搜索词、同一个网址，直接返回存档。
 *
 * 目录约定（都在本长思目录下）：
 * ```
 * 00_目录索引.md   所有文件及用途（自动生成）
 * 计划.md 日志.md 总结.md 知识库.md
 * 资料/搜索/  资料/网页/   自动存档
 * 用户资料/   用户手动添加的文件
 * 步骤/       每一步的完整过程（按步骤 id 命名，计划调整后不会错位）
 * 成果/       最终成果（Word / PPT / PDF / Excel …）
 * 备份/       定期导出的 Word / Markdown 全记录
 * ```
 */
object DeepMemory {

    const val MANIFEST = "manifest.json"
    const val INDEX = "00_目录索引.md"
    const val KNOWLEDGE = "知识库.md"
    const val DIR_SEARCH = "资料/搜索"
    const val DIR_WEB = "资料/网页"
    const val DIR_USER = "用户资料"
    const val DIR_STEPS = "步骤"
    const val DIR_OUT = "成果"
    const val DIR_BACKUP = "备份"

    val LAYOUT = listOf(DIR_SEARCH, DIR_WEB, DIR_USER, DIR_STEPS, DIR_OUT, DIR_BACKUP)

    /** 不登记、不在索引里出现的内部文件。 */
    private val INTERNAL = setOf(MANIFEST, "state.json", "events.json", INDEX)

    data class FileEntry(
        /** 相对本长思目录的路径；外部文件为绝对路径 */
        val path: String,
        val desc: String,
        val step: String = "",
        val time: Long = System.currentTimeMillis(),
        val external: Boolean = false,
        val fileId: String = "",
        /** 标记：used 已用过 / ignore 忽略 / rewrite 待改写 / key 重点参考（用户或 AI 设置） */
        val mark: String = "",
        /** 标记的说明（例如改写要求） */
        val markNote: String = "",
        val markTime: Long = 0,
    )

    data class SearchEntry(val q: String, val norm: String, val file: String, val time: Long, val cycle: Int)
    data class PageEntry(val url: String, val title: String, val file: String, val time: Long, val cycle: Int)
    data class Fact(val text: String, val step: String, val time: Long)

    class Manifest {
        val files = ArrayList<FileEntry>()
        val searches = ArrayList<SearchEntry>()
        val pages = ArrayList<PageEntry>()
        val facts = ArrayList<Fact>()
        var seq = 0
    }

    private val cache = ConcurrentHashMap<String, Manifest>()
    private val dayFmt get() = SimpleDateFormat("M月d日 HH:mm", Locale.CHINA)

    // ───────── 基础 ─────────

    fun ensureLayout(folder: File) {
        folder.mkdirs()
        for (d in LAYOUT) File(folder, d).mkdirs()
    }

    private fun key(folder: File): String = folder.absolutePath

    fun load(folder: File): Manifest = cache.getOrPut(key(folder)) {
        val m = Manifest()
        val f = File(folder, MANIFEST)
        if (f.isFile) {
            try {
                val o = JSONObject(f.readText())
                m.seq = o.optInt("seq", 0)
                o.optJSONArray("files")?.let { a ->
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { x ->
                        m.files.add(
                            FileEntry(
                                x.optString("path"), x.optString("desc"), x.optString("step"), x.optLong("time"), x.optBoolean("external"), x.optString("fileId"),
                                x.optString("mark"), x.optString("markNote"), x.optLong("markTime"),
                            ),
                        )
                    }
                }
                o.optJSONArray("searches")?.let { a ->
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { x ->
                        m.searches.add(SearchEntry(x.optString("q"), x.optString("norm"), x.optString("file"), x.optLong("time"), x.optInt("cycle")))
                    }
                }
                o.optJSONArray("pages")?.let { a ->
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { x ->
                        m.pages.add(PageEntry(x.optString("url"), x.optString("title"), x.optString("file"), x.optLong("time"), x.optInt("cycle")))
                    }
                }
                o.optJSONArray("facts")?.let { a ->
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { x ->
                        m.facts.add(Fact(x.optString("text"), x.optString("step"), x.optLong("time")))
                    }
                }
            } catch (_: Exception) {
                // 清单坏了不要紧：下面 scan 会按磁盘重建
            }
        }
        m
    }

    fun save(folder: File) {
        val m = load(folder)
        // 并行的搜索 / 读网页会同时存档：生成内容与写盘都在同一把锁里，避免把清单写坏
        synchronized(m) {
        val o = run {
            JSONObject()
                .put("seq", m.seq)
                .put("files", JSONArray().also { a ->
                    m.files.forEach { e ->
                        a.put(JSONObject().put("path", e.path).put("desc", e.desc).put("step", e.step).put("time", e.time)
                            .put("external", e.external).put("fileId", e.fileId)
                            .put("mark", e.mark).put("markNote", e.markNote).put("markTime", e.markTime))
                    }
                })
                .put("searches", JSONArray().also { a ->
                    m.searches.forEach { e -> a.put(JSONObject().put("q", e.q).put("norm", e.norm).put("file", e.file).put("time", e.time).put("cycle", e.cycle)) }
                })
                .put("pages", JSONArray().also { a ->
                    m.pages.forEach { e -> a.put(JSONObject().put("url", e.url).put("title", e.title).put("file", e.file).put("time", e.time).put("cycle", e.cycle)) }
                })
                .put("facts", JSONArray().also { a ->
                    m.facts.forEach { e -> a.put(JSONObject().put("text", e.text).put("step", e.step).put("time", e.time)) }
                })
        }
        try {
            folder.mkdirs()
            val tmp = File(folder, "$MANIFEST.tmp")
            tmp.writeText(o.toString(1))
            if (!tmp.renameTo(File(folder, MANIFEST))) {
                File(folder, MANIFEST).writeText(o.toString(1)); tmp.delete()
            }
        } catch (_: Exception) { }
        }
    }

    fun forget(folder: File) { cache.remove(key(folder)) }

    // ───────── 文本工具 ─────────

    /** 文件名里不安全的字符换成下划线（保留中文）。 */
    fun slug(s: String, max: Int = 24): String =
        s.trim().replace(Regex("[\\\\/:*?\"<>|\\s#%&{}$!'@+`=\\[\\]()（）【】，。、；：？！“”‘’]+"), "_")
            .trim('_', '.').take(max).trim('_', '.').ifBlank { "未命名" }

    /** 只保留字母、数字、汉字，转小写（用于比较）。 */
    fun norm(s: String): String = buildString {
        for (c in s.lowercase()) if (c.isLetterOrDigit()) append(c)
    }

    private fun bigrams(s: String): Set<String> {
        val n = norm(s)
        if (n.length < 2) return if (n.isEmpty()) emptySet() else setOf(n)
        val out = HashSet<String>()
        for (i in 0 until n.length - 1) out.add(n.substring(i, i + 2))
        return out
    }

    /** 0~1 的相似度（字符二元组 Jaccard）。 */
    fun similarity(a: String, b: String): Double {
        val x = bigrams(a)
        val y = bigrams(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        val inter = x.count { it in y }
        return inter.toDouble() / (x.size + y.size - inter)
    }

    /** 关键词覆盖度：query 的二元组有多少出现在 text 里（检索用）。 */
    private fun coverage(query: Set<String>, text: String): Double {
        if (query.isEmpty()) return 0.0
        val t = bigrams(text)
        return query.count { it in t }.toDouble() / query.size
    }

    fun normUrl(u: String): String = u.trim().substringBefore('#').removeSuffix("/")
        .replace(Regex("^https?://(www\\.)?"), "").lowercase()

    // ───────── 文件登记 / 查找 ─────────

    private fun relOf(folder: File, f: File): String? = try {
        val r = f.canonicalFile.relativeTo(folder.canonicalFile).path
        if (r.startsWith("..")) null else r.replace('\\', '/')
    } catch (_: Exception) { null }

    /** 登记一个文件（同一路径只保留一条，说明以最新为准；空说明不覆盖旧说明）。 */
    fun registerFile(folder: File, file: File, desc: String, step: String = "", fileId: String = "") {
        val rel = relOf(folder, file)
        val m = load(folder)
        synchronized(m) {
            val path = rel ?: file.absolutePath
            val i = m.files.indexOfFirst { it.path == path }
            val old = if (i >= 0) m.files[i] else null
            val e = FileEntry(
                path = path,
                desc = desc.ifBlank { old?.desc.orEmpty() },
                step = step.ifBlank { old?.step.orEmpty() },
                time = System.currentTimeMillis(),
                external = rel == null,
                fileId = fileId.ifBlank { old?.fileId.orEmpty() },
                mark = old?.mark.orEmpty(),
                markNote = old?.markNote.orEmpty(),
                markTime = old?.markTime ?: 0,
            )
            if (i >= 0) m.files[i] = e else m.files.add(e)
        }
        save(folder)
    }

    private fun walk(folder: File, maxDepth: Int = 6): List<File> =
        if (!folder.isDirectory) emptyList()
        else folder.walkTopDown().maxDepth(maxDepth)
            .filter { it.isFile && it.name !in INTERNAL && !it.name.endsWith(".tmp") }
            .toList()

    /** 按磁盘对账：新出现的文件补登记，已不存在的删掉（外部文件同样检查）。返回新登记的文件。 */
    fun scan(folder: File, defaultStep: String = ""): List<String> {
        val m = load(folder)
        val disk = walk(folder).mapNotNull { f -> relOf(folder, f)?.let { it to f } }.toMap()
        val added = ArrayList<String>()
        synchronized(m) {
            m.files.removeAll { e -> if (e.external) !File(e.path).exists() else e.path !in disk }
            val known = m.files.map { it.path }.toHashSet()
            for ((rel, _) in disk) {
                if (rel in known) continue
                m.files.add(FileEntry(rel, guessDesc(rel), defaultStep))
                added.add(rel)
            }
        }
        save(folder)
        return added
    }

    private fun guessDesc(rel: String): String = when {
        rel.startsWith(DIR_SEARCH) -> "搜索存档"
        rel.startsWith(DIR_WEB) -> "网页存档"
        rel.startsWith(DIR_USER) -> "用户提供的资料"
        rel.startsWith(DIR_STEPS) -> "步骤过程记录"
        rel.startsWith(DIR_OUT) -> "成果文件"
        rel.startsWith(DIR_BACKUP) -> "备份"
        rel == "计划.md" -> "当前计划"
        rel == "日志.md" -> "运行日志"
        rel == "总结.md" -> "阶段总结"
        rel == KNOWLEDGE -> "知识库：所有步骤提炼出的要点与来源"
        else -> ""
    }

    private val EXT_PRIORITY = listOf("docx", "pptx", "pdf", "xlsx", "md", "txt", "csv", "html")

    /**
     * 按名字（模糊）找文件：先本长思目录，找不到返回 null。
     * 依次尝试：原样路径 → 相对路径忽略大小写 → 文件名相同 → 去掉扩展名相同 → 规范化后相同 → 包含 → 相似度。
     */
    fun findFile(folder: File, key: String): File? {
        var k = key.trim().trim('"', '\'', '《', '》', '「', '」', '`').replace('\\', '/')
        if (k.isEmpty()) return null
        k = k.removePrefix("灵犀AI/").removePrefix("/灵犀AI/").removePrefix("./")
        File(k).takeIf { k.startsWith("/") && it.isFile }?.let { return it }
        File(folder, k).takeIf { it.isFile }?.let { return it }
        val files = walk(folder)
        if (files.isEmpty()) return null
        val name = k.substringAfterLast('/')
        val ext = name.substringAfterLast('.', "").lowercase().takeIf { it.length in 1..5 && name.contains('.') }.orEmpty()
        val stem = if (ext.isEmpty()) name else name.substringBeforeLast('.')
        fun pick(list: List<File>): File? {
            if (list.isEmpty()) return null
            if (list.size == 1) return list[0]
            list.firstOrNull { ext.isNotEmpty() && it.extension.equals(ext, true) }?.let { return it }
            for (e in EXT_PRIORITY) list.firstOrNull { it.extension.equals(e, true) }?.let { return it }
            return list.maxByOrNull { it.lastModified() }
        }
        pick(files.filter { relOf(folder, it)?.equals(k, true) == true })?.let { return it }
        pick(files.filter { it.name.equals(name, true) })?.let { return it }
        pick(files.filter { it.nameWithoutExtension.equals(stem, true) })?.let { return it }
        val ns = norm(stem)
        if (ns.isEmpty()) return null
        pick(files.filter { norm(it.nameWithoutExtension) == ns })?.let { return it }
        if (ns.length >= 2) {
            pick(files.filter { val n = norm(it.nameWithoutExtension); n.contains(ns) || (n.length >= 2 && ns.contains(n)) })?.let { return it }
            // 用户可能说的是文件的「说明」
            val m = load(folder)
            val byDesc = synchronized(m) { m.files.filter { !it.external && norm(it.desc).contains(ns) }.map { File(folder, it.path) } }
            pick(byDesc.filter { it.isFile })?.let { return it }
        }
        val best = files.map { it to similarity(stem, it.nameWithoutExtension) }.maxByOrNull { it.second }
        return best?.takeIf { it.second >= 0.5 }?.first
    }

    /** 给模型看的目录索引（按目录分组，带说明）。 */
    fun indexForPrompt(folder: File, maxChars: Int = 2500): String {
        val m = load(folder)
        val all = synchronized(m) { m.files.toList() }
        if (all.isEmpty()) return "（还没有文件）"
        // 「忽略」的不给 AI 看；「已用过」的只报个数（内容已经提炼进知识库），省上下文
        val used = all.count { it.mark == MARK_USED }
        val list = all.filter { it.mark != MARK_IGNORE && it.mark != MARK_USED }
        val sb = StringBuilder()
        if (used > 0) sb.append("（另有 ").append(used).append(" 个资料已标「已用过」，要点已在知识库里，一般不必再读；真要用就看 ").append(INDEX).append("）\n")
        val groups = list.groupBy { if (it.external) "外部（不在本目录，用完整路径或 f 编号）" else it.path.substringBeforeLast('/', "（根目录）") }
        // 成果、用户资料、根目录排前面；搜索 / 网页存档只列最近的
        val order = groups.keys.sortedBy {
            when {
                it == DIR_OUT -> 0; it == DIR_USER -> 1; it == "（根目录）" -> 2; it.startsWith(DIR_STEPS) -> 4
                it == DIR_SEARCH || it == DIR_WEB -> 6; it.startsWith("外部") -> 3; else -> 5
            }
        }
        for (g in order) {
            val items = groups[g].orEmpty().sortedByDescending { it.time }
            val shown = if (g == DIR_SEARCH || g == DIR_WEB || g.startsWith(DIR_STEPS)) items.take(12) else items.take(40)
            sb.append("📁 ").append(g).append("（").append(items.size).append("）\n")
            for (e in shown) {
                sb.append("  - ").append(e.path)
                if (e.fileId.isNotBlank()) sb.append(" [").append(e.fileId).append(']')
                markTag(e).takeIf { it.isNotEmpty() }?.let { sb.append(' ').append(it) }
                if (e.desc.isNotBlank()) sb.append(" —— ").append(e.desc.take(60))
                sb.append('\n')
            }
            if (items.size > shown.size) sb.append("  …还有 ").append(items.size - shown.size).append(" 个（完整清单见 ").append(INDEX).append("）\n")
            if (sb.length > maxChars) break
        }
        return sb.toString().take(maxChars).trimEnd()
    }

    /** 重写「00_目录索引.md」（给人和 AI 看）。 */
    fun writeIndex(folder: File, topic: String) {
        val m = load(folder)
        val list = synchronized(m) { m.files.toList() }
        val sb = StringBuilder("# 目录索引：").append(topic).append("\n\n")
        sb.append("更新于 ").append(dayFmt.format(Date())).append("。所有文件都登记在这里；找文件先看这份索引。\n\n")
        for ((g, items) in list.groupBy { if (it.external) "外部文件" else it.path.substringBeforeLast('/', "根目录") }.toSortedMap()) {
            sb.append("## ").append(g).append("\n\n")
            for (e in items.sortedBy { it.path }) {
                sb.append("- `").append(e.path).append('`')
                if (e.fileId.isNotBlank()) sb.append("（").append(e.fileId).append('）')
                markTag(e).takeIf { it.isNotEmpty() }?.let { sb.append(' ').append(it) }
                if (e.desc.isNotBlank()) sb.append("：").append(e.desc)
                if (e.step.isNotBlank()) sb.append("  〔").append(e.step).append('〕')
                sb.append('\n')
            }
            sb.append('\n')
        }
        try { File(folder, INDEX).writeText(sb.toString()) } catch (_: Exception) { }
    }

    fun userFiles(folder: File): List<FileEntry> {
        val m = load(folder)
        return synchronized(m) { m.files.filter { !it.external && it.path.startsWith(DIR_USER) }.sortedByDescending { it.time } }
    }

    // ───────── 搜索 / 网页存档与缓存 ─────────

    private fun nextSeq(m: Manifest): Int = synchronized(m) { ++m.seq }

    /** 找已搜过的同一个（或几乎一样的）搜索词。 */
    fun findSearch(folder: File, query: String): Pair<SearchEntry, String>? {
        val n = norm(query)
        if (n.isEmpty()) return null
        val m = load(folder)
        val hit = synchronized(m) {
            val ignored = m.files.filter { it.mark == MARK_IGNORE }.map { it.path }.toHashSet()
            val list = m.searches.filter { it.file !in ignored }
            list.lastOrNull { it.norm == n } ?: list.filter { similarity(it.q, query) >= 0.85 }.maxByOrNull { it.time }
        } ?: return null
        val f = File(folder, hit.file)
        if (!f.isFile) return null
        return hit to f.readText()
    }

    fun archiveSearch(folder: File, query: String, text: String, cycle: Int, step: String): String {
        val m = load(folder)
        val no = nextSeq(m)
        val rel = "$DIR_SEARCH/q${no.toString().padStart(3, '0')}_${slug(query)}.md"
        val f = File(folder, rel)
        f.parentFile?.mkdirs()
        f.writeText("# 搜索：$query\n\n第 $cycle 轮 · ${dayFmt.format(Date())} · $step\n\n$text\n")
        synchronized(m) {
            m.searches.add(SearchEntry(query, norm(query), rel, System.currentTimeMillis(), cycle))
            m.files.add(FileEntry(rel, "搜索「${query.take(30)}」的结果", step))
        }
        save(folder)
        return rel
    }

    fun findPage(folder: File, url: String): Pair<PageEntry, String>? {
        val n = normUrl(url)
        if (n.isEmpty()) return null
        val m = load(folder)
        val hit = synchronized(m) { m.pages.lastOrNull { normUrl(it.url) == n } } ?: return null
        val f = File(folder, hit.file)
        if (!f.isFile) return null
        return hit to f.readText()
    }

    fun archivePage(folder: File, url: String, title: String, text: String, cycle: Int, step: String): String {
        val m = load(folder)
        val no = nextSeq(m)
        val label = title.ifBlank { url.replace(Regex("^https?://(www\\.)?"), "").substringBefore('/') }
        val rel = "$DIR_WEB/w${no.toString().padStart(3, '0')}_${slug(label)}.md"
        val f = File(folder, rel)
        f.parentFile?.mkdirs()
        f.writeText("# ${label}\n\n来源：$url\n第 $cycle 轮 · ${dayFmt.format(Date())} · $step\n\n$text\n")
        synchronized(m) {
            m.pages.add(PageEntry(url, title, rel, System.currentTimeMillis(), cycle))
            m.files.add(FileEntry(rel, "网页：${label.take(40)}", step))
        }
        save(folder)
        return rel
    }

    /** 最近搜过的词（提示词里列出，避免重复）。 */
    fun recentQueries(folder: File, n: Int = 25): List<Pair<String, String>> {
        val m = load(folder)
        return synchronized(m) { m.searches.takeLast(n).map { it.q to it.file } }
    }

    // ───────── 知识库 ─────────

    /** 追加要点（自动去重）。返回实际新增的条数。 */
    fun addFacts(folder: File, step: String, facts: List<String>): Int {
        val m = load(folder)
        val fresh = ArrayList<String>()
        synchronized(m) {
            val recent = m.facts.takeLast(400)
            for (raw in facts) {
                val t = raw.trim().removePrefix("-").removePrefix("•").removePrefix("*").trim()
                if (norm(t).length < 4) continue
                val dup = recent.any { norm(it.text) == norm(t) || similarity(it.text, t) >= 0.85 } ||
                    fresh.any { similarity(it, t) >= 0.85 }
                if (!dup) fresh.add(t.take(400))
            }
            val now = System.currentTimeMillis()
            for (t in fresh) m.facts.add(Fact(t, step, now))
        }
        if (fresh.isEmpty()) return 0
        try {
            val f = File(folder, KNOWLEDGE)
            val head = if (!f.exists()) "# 知识库\n\n每一步提炼出的要点（带来源），按时间追加。完整原文见「资料/」与「步骤/」。\n" else ""
            f.appendText(head + "\n## $step · ${dayFmt.format(Date())}\n" + fresh.joinToString("\n") { "- $it" } + "\n")
        } catch (_: Exception) { }
        registerFile(folder, File(folder, KNOWLEDGE), "知识库：所有步骤提炼出的要点与来源")
        save(folder)
        return fresh.size
    }

    fun factCount(folder: File): Int = load(folder).let { m -> synchronized(m) { m.facts.size } }

    /** 和 query 最相关的要点（不够相关时退回最近的），按原顺序输出。 */
    fun relevantFacts(folder: File, query: String, maxChars: Int = 2500): String {
        val m = load(folder)
        val all = synchronized(m) { m.facts.toList() }
        if (all.isEmpty()) return ""
        val q = bigrams(query)
        val scored = all.withIndex().map { (i, f) -> Triple(i, f, coverage(q, f.text) + i.toDouble() / all.size * 0.15) }
        val picked = ArrayList<Pair<Int, Fact>>()
        var used = 0
        for ((i, f, _) in scored.sortedByDescending { it.third }) {
            val line = f.text.length + f.step.length + 6
            if (used + line > maxChars) continue
            picked.add(i to f)
            used += line
        }
        return picked.sortedBy { it.first }.joinToString("\n") { "- [${it.second.step}] ${it.second.text}" }
    }

    fun allFactsMarkdown(folder: File, maxChars: Int = Int.MAX_VALUE): String {
        val m = load(folder)
        val all = synchronized(m) { m.facts.toList() }
        val sb = StringBuilder()
        for ((step, list) in all.groupBy { it.step }) {
            sb.append("### ").append(step).append('\n')
            for (f in list) sb.append("- ").append(f.text).append('\n')
            sb.append('\n')
            if (sb.length > maxChars) break
        }
        return sb.toString().take(maxChars)
    }

    // ───────── 资料标记（已用过 / 忽略 / 待改写 / 重点） ─────────

    const val MARK_USED = "used"
    const val MARK_IGNORE = "ignore"
    const val MARK_REWRITE = "rewrite"
    const val MARK_KEY = "key"

    val MARK_LABELS = linkedMapOf(MARK_USED to "已用过", MARK_IGNORE to "忽略", MARK_REWRITE to "待改写", MARK_KEY to "重点参考")

    /** 中英文都认：已用 / 用过 / used、忽略 / ignore、改写 / rewrite、重点 / key；清除返回空串；认不出返回 null。 */
    fun normalizeMark(s: String): String? = when (s.trim().lowercase()) {
        "used", "已用", "已用过", "用过", "done", "已读" -> MARK_USED
        "ignore", "忽略", "无用", "不用", "skip", "hide" -> MARK_IGNORE
        "rewrite", "改写", "待改写", "优先改写", "修改", "重写", "edit" -> MARK_REWRITE
        "key", "重点", "重要", "重点参考", "star", "important" -> MARK_KEY
        "", "clear", "none", "清除", "取消", "无" -> ""
        else -> null
    }

    fun markTag(e: FileEntry): String = when (e.mark) {
        MARK_USED -> "〔已用过〕"
        MARK_IGNORE -> "〔忽略〕"
        MARK_REWRITE -> "〔⚠待改写" + (if (e.markNote.isNotBlank()) "：" + e.markNote.take(40) else "") + "〕"
        MARK_KEY -> "〔★重点〕"
        else -> ""
    }

    /** 相对本长思目录的路径（外部文件返回绝对路径）。 */
    fun relPath(folder: File, f: File): String = relOf(folder, f) ?: f.absolutePath

    /** 给文件打标记（没登记过的先登记）。返回更新后的登记项。 */
    fun setMark(folder: File, file: File, mark: String, note: String = ""): FileEntry {
        val rel = relOf(folder, file)
        val m = load(folder)
        val e = synchronized(m) {
            val path = rel ?: file.absolutePath
            val i = m.files.indexOfFirst { it.path == path }
            val old = if (i >= 0) m.files[i] else FileEntry(path, guessDesc(path), external = rel == null)
            val e = old.copy(mark = mark, markNote = if (mark.isEmpty()) "" else note.trim(), markTime = System.currentTimeMillis())
            if (i >= 0) m.files[i] = e else m.files.add(e)
            e
        }
        save(folder)
        return e
    }

    fun entryOf(folder: File, file: File): FileEntry? {
        val path = relOf(folder, file) ?: file.absolutePath
        val m = load(folder)
        return synchronized(m) { m.files.firstOrNull { it.path == path } }
    }

    fun marked(folder: File, mark: String): List<FileEntry> {
        val m = load(folder)
        return synchronized(m) { m.files.filter { it.mark == mark }.sortedByDescending { it.markTime } }
    }

    /** 一步做完后：这一步存档的搜索 / 网页 / 研究资料（还没标记的）标成「已用过」，之后的索引里不再逐个列出。 */
    fun markStepArchivesUsed(folder: File, step: String): Int {
        if (step.isBlank()) return 0
        val m = load(folder)
        var n = 0
        synchronized(m) {
            for ((i, e) in m.files.withIndex()) {
                if (e.mark.isEmpty() && e.step == step && !e.external && e.path.startsWith("资料/")) {
                    m.files[i] = e.copy(mark = MARK_USED, markTime = System.currentTimeMillis()); n++
                }
            }
        }
        if (n > 0) save(folder)
        return n
    }

    // ───────── 交付核对 ─────────

    /** 这些目录里的文件不算「产出」（资料存档、步骤记录、备份）。 */
    private val NON_OUTPUT = listOf("资料/", "$DIR_STEPS/", "$DIR_BACKUP/")

    /**
     * 严格地找「应产出的文件」：比 [findFile] 严格得多 —— 只认同名（或去掉扩展名后同名）的文件，
     * 不看资料 / 步骤 / 备份目录（免得「诗歌初稿」被搜索存档「q007_诗歌初稿写法.md」冒充）。
     * 「用户资料/」里的同名文件只有在 [changedSince] 之后改过才算（原地改写用户的文件）。
     */
    fun findOutput(folder: File, rel: String, changedSince: Long): File? {
        val direct = File(folder, rel)
        if (direct.isFile) return direct
        val name = rel.substringAfterLast('/')
        val stem = norm(name.substringBeforeLast('.'))
        if (stem.isEmpty()) return null
        val cands = walk(folder).filter { f ->
            val r = relOf(folder, f) ?: return@filter false
            if (NON_OUTPUT.any { r.startsWith(it) }) return@filter false
            if (r.startsWith("$DIR_USER/") && f.lastModified() < changedSince) return@filter false
            r !in setOf("计划.md", "日志.md", "总结.md", KNOWLEDGE)
        }
        return cands.firstOrNull { it.name.equals(name, true) }
            ?: cands.filter { norm(it.nameWithoutExtension) == stem }.maxByOrNull { it.lastModified() }
    }

    /** 「成果/」里现有的文件（最近的在前），不含系统根据它们生成的总结报告 / 汇报 PPT / 数据表。 */
    fun outputFiles(folder: File): List<File> =
        File(folder, DIR_OUT).walkTopDown().maxDepth(3).filter {
            it.isFile && !it.name.endsWith(".tmp") && !it.name.startsWith("总结报告") && it.name != "汇报.pptx" && it.name != "数据表.xlsx"
        }
            .sortedByDescending { it.lastModified() }.toList()

    // ───────── 核对 ─────────

    private val FILE_MENTION = Regex("([\\w\\u4e00-\\u9fff./\\-（）()]{1,80}\\.(?:docx|pptx|xlsx|pdf|md|txt|csv|html|json))", RegexOption.IGNORE_CASE)

    private val CLAIM = Regex("(已写入|已覆盖|已生成|已更新|已保存|已完成|已创作|写好了|产出|产出文件|写了|写入了|生成了|保存到|存到)")

    /** 结论里「声称已经写好」的文件名（同一行里既有「已写入 / 产出 …」又有文件名）。 */
    fun claimedFiles(text: String): List<String> {
        val clean = text.replace(Regex("(?i)(?:https?://|www\\.)\\S+"), " ")
        val out = LinkedHashSet<String>()
        for (line in clean.lines()) {
            if (!CLAIM.containsMatchIn(line)) continue
            for (m in FILE_MENTION.findAll(line)) {
                val n = m.groupValues[1].trim('/', '.', '（', '(', '《', '「', '`', '*')
                if (n.length > 3) out.add(n)
            }
        }
        return out.toList()
    }

    /** 从一段话里找出提到的文件名，返回其中在本目录里找不到的。 */
    fun missingMentioned(folder: File, text: String): List<String> {
        // 去掉网址（引用来源时常带 .pdf / .html），只核对本地文件名
        val clean = text.replace(Regex("(?i)(?:https?://|www\\.)\\S+"), " ")
        val names = FILE_MENTION.findAll(clean).map { it.groupValues[1].trim('/', '.', '（', '(') }.filter { it.length > 3 && !Regex("^[a-z0-9-]+\\.[a-z]{2,}(?:\\.[a-z]{2,})?/", RegexOption.IGNORE_CASE).containsMatchIn(it) }.toSet()
        return names.filter { n -> findFile(folder, n) == null }
    }
}
