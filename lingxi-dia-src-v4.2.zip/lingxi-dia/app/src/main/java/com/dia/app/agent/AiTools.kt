package com.dia.app.agent

import com.dia.app.MainActivity
import com.dia.app.deep.DeepEngine
import com.dia.app.files.AiFolder
import com.dia.app.files.FileManager
import com.dia.app.files.TextDecode
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import com.dia.app.screen.NavBus
import com.dia.app.ui.theme.ThemeManager
import com.dia.app.voice.Transcriber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/**
 * 4.0 新增的工具：AI 专属文件夹、语音转文字 / 听音频、自主长思、主题。
 */
object AiTools {

    private fun str(a: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = a.opt(k)
            if (v != null && v != JSONObject.NULL && v.toString().isNotBlank()) return v.toString().trim()
        }
        return ""
    }

    private val BINARY_DOCS = setOf("docx", "pptx", "xlsx", "pdf")

    // ───────── AI 专属文件夹 ─────────

    suspend fun aiFiles(args: JSONObject, host: ToolHost): ToolOutcome = withContext(Dispatchers.IO) {
        val path = str(args, "path", "file", "name", "dir")
        val content = args.optString("content", args.optString("text", ""))
        val action = str(args, "action", "op").lowercase().ifBlank {
            when {
                content.isNotEmpty() -> "write"
                path.isBlank() -> "list"
                else -> "read"
            }
        }
        val base: File? = host.deepSessionId?.let { DeepEngine.folderOf(it) }
        val f = try {
            AiFolder.resolve(path, base)
        } catch (e: IllegalArgumentException) {
            return@withContext ToolOutcome(e.message ?: "路径无效", ok = false)
        }
        val shown = "灵犀AI/" + AiFolder.rel(f)
        when (action) {
            "list", "ls", "dir", "tree" -> ToolOutcome(AiFolder.list(f, depth = args.optInt("depth", 2).coerceIn(1, 4)))

            "info", "stat" -> if (f.exists()) ToolOutcome(AiFolder.info(f)) else ToolOutcome("不存在：$shown", ok = false)

            "read", "cat", "open", "view" -> {
                if (!f.exists()) return@withContext ToolOutcome("不存在：$shown。可以先 list 看看有哪些文件。", ok = false)
                if (f.isDirectory) return@withContext ToolOutcome(AiFolder.list(f, 2))
                val offset = args.optInt("offset", 0).coerceAtLeast(0)
                val budget = (LlmGateway.promptCharBudget() / 2).coerceIn(1500, 14000)
                if (AiFolder.isText(f)) {
                    val text = TextDecode.decode(f.readBytes())
                    val start = offset.coerceAtMost(text.length)
                    val end = (start + budget).coerceAtMost(text.length)
                    val more = if (end < text.length) "\n\n（共 ${text.length} 字，当前 $start–$end，继续读用 offset=$end）" else ""
                    ToolOutcome("$shown：\n${text.substring(start, end)}$more", display = text.substring(start, end).take(2000))
                } else {
                    val ref = FileManager.attachPath(f.absolutePath)
                    val r = FileManager.read(ref, offset, budget)
                    val more = if (offset + r.text.length < r.totalChars) "\n\n（共 ${r.totalChars} 字，继续读用 offset=${offset + r.text.length}）" else ""
                    ToolOutcome(
                        "$shown（已登记为 ${ref.id}，可用 doc_outline / edit_file 精修）：\n${r.text}$more${if (r.note.isNotBlank()) "\n（${r.note}）" else ""}",
                        display = r.text.take(2000),
                    )
                }
            }

            "write", "save", "create", "overwrite" -> {
                if (content.isEmpty()) return@withContext ToolOutcome("缺少要写入的 content", ok = false)
                val target = if (f.isDirectory || path.isBlank()) File(f, "笔记_${System.currentTimeMillis()}.md") else f
                target.parentFile?.mkdirs()
                val ext = target.extension.lowercase()
                val data = if (ext in BINARY_DOCS) {
                    FileManager.renderContent(content, ext, target.nameWithoutExtension)
                } else content.toByteArray(Charsets.UTF_8)
                val existed = target.exists()
                target.writeBytes(data)
                AiFolder.touch()
                val ref = if (ext in BINARY_DOCS) FileManager.attachPath(target.absolutePath) else null
                ToolOutcome(
                    "${if (existed) "已覆盖" else "已写入"}「灵犀AI/${AiFolder.rel(target)}」（${AiFolder.sizeLabel(target.length())}）" +
                        (ref?.let { "，已登记为 ${it.id}" } ?: ""),
                )
            }

            "append", "add" -> {
                if (content.isEmpty()) return@withContext ToolOutcome("缺少要追加的 content", ok = false)
                if (f.isDirectory) return@withContext ToolOutcome("$shown 是目录，请给出文件名", ok = false)
                if (f.exists() && !AiFolder.isText(f)) return@withContext ToolOutcome("只能往文本文件里追加；Word/PPT 请用 edit_file。", ok = false)
                f.parentFile?.mkdirs()
                f.appendText((if (f.exists() && f.length() > 0) "\n" else "") + content)
                AiFolder.touch()
                ToolOutcome("已追加到「$shown」（现在 ${AiFolder.sizeLabel(f.length())}）")
            }

            "mkdir", "md" -> {
                f.mkdirs(); AiFolder.touch()
                ToolOutcome("已建立目录「$shown」")
            }

            "move", "rename", "mv", "copy", "cp" -> {
                val toPath = str(args, "to", "dest", "target", "new_path")
                if (toPath.isBlank()) return@withContext ToolOutcome("缺少目标路径 to", ok = false)
                if (!f.exists()) return@withContext ToolOutcome("不存在：$shown", ok = false)
                val dst = try { AiFolder.resolve(toPath, base) } catch (e: IllegalArgumentException) {
                    return@withContext ToolOutcome(e.message ?: "目标路径无效", ok = false)
                }
                val finalDst = if (dst.isDirectory) File(dst, f.name) else dst
                finalDst.parentFile?.mkdirs()
                val copy = action == "copy" || action == "cp"
                val ok = if (copy) {
                    f.copyRecursively(finalDst, overwrite = false)
                } else f.renameTo(finalDst) || (f.copyRecursively(finalDst, overwrite = false) && f.deleteRecursively())
                AiFolder.touch()
                if (ok) ToolOutcome("已${if (copy) "复制" else "移动"}到「灵犀AI/${AiFolder.rel(finalDst)}」") else ToolOutcome("操作失败（目标可能已存在）", ok = false)
            }

            "delete", "rm", "remove" -> {
                if (!f.exists()) return@withContext ToolOutcome("不存在：$shown", ok = false)
                val rootPath = AiFolder.root().canonicalPath
                val top = f.canonicalPath == rootPath || (f.parentFile?.canonicalPath == rootPath && f.name in AiFolder.SUBDIRS)
                if (top) return@withContext ToolOutcome("不能删除根目录或固定的分类目录（${AiFolder.SUBDIRS.joinToString("、")}）。", ok = false)
                if (f.isDirectory) {
                    val n = f.walkTopDown().count { it.isFile }
                    val ok = host.confirm("删除目录「$shown」？", "里面有 $n 个文件，删除后无法恢复。")
                    if (!ok) return@withContext ToolOutcome("用户取消了删除。", ok = false)
                    f.deleteRecursively()
                } else f.delete()
                AiFolder.touch()
                ToolOutcome("已删除「$shown」")
            }

            "attach", "register" -> {
                if (!f.isFile) return@withContext ToolOutcome("不是文件：$shown", ok = false)
                val ref = FileManager.attachPath(f.absolutePath)
                ToolOutcome("已登记为 ${ref.id}《${ref.name}》，可以用 read_file / doc_outline / edit_file / pdf_tool 等工具处理。")
            }

            else -> ToolOutcome("不支持的操作「$action」。可用：list / read / write / append / delete / mkdir / move / copy / attach / info", ok = false)
        }
    }

    // ───────── 语音转文字 / 听音频 ─────────

    suspend fun transcribe(args: JSONObject, host: ToolHost): ToolOutcome {
        val key = str(args, "file", "id", "path", "name")
        val ref = FileManager.find(key)
            ?: return ToolOutcome("找不到音频文件「$key」。请让用户点「囊 → 文件」选择音频，或给出文件编号。", ok = false)
        val engine = str(args, "engine").ifBlank { DiaSettings.sttFileEngine.value }
        host.progress("正在准备转写 ${ref.name}…")
        val r = Transcriber.transcribeRef(host.context, ref, engine) { host.progress(it) }
        if (r.text.isBlank()) return ToolOutcome("没有识别出文字（${r.engine}）。${r.note}", ok = false)
        val saved = withContext(Dispatchers.IO) {
            val body = buildString {
                append("# ").append(ref.name).append(" · 转写\n\n")
                append("引擎：").append(r.engine).append("  时长：").append(Transcriber.formatDuration(r.seconds)).append("\n\n")
                append(r.text)
                if (!r.segments.isNullOrBlank()) append("\n\n---\n## 带时间的分段\n\n").append(r.segments)
            }
            AiFolder.save("转写", ref.name.substringBeforeLast('.') + "_转写.md", body.toByteArray(Charsets.UTF_8))
        }
        val tRef = FileManager.attachPath(saved.absolutePath)
        val budget = (LlmGateway.promptCharBudget() / 2).coerceIn(1500, 14000)
        val head = "《${ref.name}》转写完成（${r.engine}，${Transcriber.formatDuration(r.seconds)}，${r.text.length} 字），" +
            "全文已存到「灵犀AI/${AiFolder.rel(saved)}」（${tRef.id}）。"
        val body = if (r.text.length > budget) r.text.take(budget) + "\n…（后面还有 ${r.text.length - budget} 字，可 read_file ${tRef.id} offset=$budget 继续读）" else r.text
        return ToolOutcome("$head\n\n$body", display = r.text.take(20000))
    }

    suspend fun listen(args: JSONObject, host: ToolHost): ToolOutcome {
        val key = str(args, "file", "id", "path", "name")
        val ref = FileManager.find(key) ?: return ToolOutcome("找不到音频文件「$key」", ok = false)
        val q = str(args, "question", "task", "text").ifBlank { "这段音频里有什么？请描述内容、说话人的语气情绪和背景声音。" }
        val r = Transcriber.listen(host.context, ref, q) { host.progress(it) }
        return ToolOutcome(r, display = r)
    }

    // ───────── 自主长思 ─────────

    suspend fun startDeep(args: JSONObject, host: ToolHost): ToolOutcome {
        val topic = str(args, "topic", "goal", "task", "question", "text")
        if (topic.isBlank()) return ToolOutcome("缺少长思主题 topic", ok = false)
        val web = str(args, "web").ifBlank { DiaSettings.deepWeb.value }.let { if (it in setOf("auto", "on", "off")) it else "auto" }
        val id = DeepEngine.create(host.context, topic, web = web)
        if (MainActivity.isForeground) NavBus.requestPage("deep:$id")
        return ToolOutcome(
            "已开启自主长思「$topic」（编号 $id，联网：${mapOf("auto" to "自行决定", "on" to "允许", "off" to "不联网")[web]}）。" +
                "它会在后台一直运行：先拆解计划，再逐步执行、写入「灵犀AI/长思」，直到用户暂停。用户可以在「长思」页查看、修改计划、随时插话。",
            shownToUser = true,
        )
    }

    // ───────── 主题 ─────────

    suspend fun theme(args: JSONObject, host: ToolHost): ToolOutcome = ThemeManager.toolAction(args, host)
}
