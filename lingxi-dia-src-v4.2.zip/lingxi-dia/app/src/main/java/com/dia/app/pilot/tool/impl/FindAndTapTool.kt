package com.dia.app.pilot.tool.impl

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.dia.app.DiaAccessibilityService
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class FindAndTapTool : BaseTool() {
    override fun getName(): String = "find_and_tap"

    override fun getDescription(): String =
        "Find a visible node by text/content-desc and tap it. Accepts exact or partial substring match."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("text", "string", "Text to find (case-insensitive, substring)", true),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService()
                ?: return ToolResult.error("Accessibility service is not running")
            val query = requireString(params, "text")
            val nodes = service.findNodesByText(query)
            if (nodes.isEmpty()) return ToolResult.error("No elements found for: $query")

            // De-prioritise mic/camera/voice-search matches when the user is
            // looking for a generic concept like "search". Apps label the mic
            // icon "Voice search", so a literal find_and_tap("search") would
            // hit the mic before the actual search bar.
            val ranked = rankCandidates(nodes, query)

            // Prefer clickable, then parent-clickable, then any hit.
            val clickable = ranked.firstOrNull { it.isClickable }
            val target = clickable
                ?: ranked.firstOrNull { findClickableAncestor(it) != null }?.let { findClickableAncestor(it) }
                ?: ranked.first()
            val ok = tapNode(service, target)
            service.recycleNodes(nodes)
            return if (ok) ToolResult.success("Tapped: $query")
            else ToolResult.error("Failed to tap: $query")
        } catch (e: Exception) {
            ToolResult.error("Find and tap error: ${e.message}")
        }
    }

    /**
     * Sort matches so that nodes whose label is exactly the query (or close
     * to it) come first, and "voice / mic / camera" variants of the query
     * come last. This stops `find_and_tap("search")` from landing on a
     * "Voice search" mic icon.
     */
    private fun rankCandidates(
        nodes: List<AccessibilityNodeInfo>,
        query: String,
    ): List<AccessibilityNodeInfo> {
        val q = query.trim().lowercase()
        val queryAsksForVoice = listOf("voice", "mic", "microphone").any { q.contains(it) }
        val queryAsksForCamera = listOf("camera", "lens", "scan", "barcode").any { q.contains(it) }

        return nodes.sortedBy { node ->
            val text = (node.text?.toString().orEmpty()).lowercase()
            val desc = (node.contentDescription?.toString().orEmpty()).lowercase()
            val combined = "$text $desc"

            val isVoice = listOf("voice search", "voice", "microphone", " mic ", "speak now").any { combined.contains(it) }
            val isCamera = listOf("camera", "lens icon", "scan", "barcode", "qr code", "image search").any { combined.contains(it) }
            val isExact = text == q || desc == q
            val startsWith = text.startsWith(q) || desc.startsWith(q)

            // If user explicitly asked for voice / camera, those become the
            // best matches.
            if (queryAsksForVoice && isVoice) return@sortedBy 0
            if (queryAsksForCamera && isCamera) return@sortedBy 0

            // Otherwise: lower rank = better match.
            when {
                isExact && !isVoice && !isCamera -> 0
                startsWith && !isVoice && !isCamera -> 1
                !isVoice && !isCamera -> 2
                isVoice -> 4
                isCamera -> 5
                else -> 3
            }
        }
    }

    private fun findClickableAncestor(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var current = node?.parent
        var hops = 0
        while (current != null && hops < 6) {
            if (current.isClickable) return current
            current = current.parent
            hops++
        }
        return null
    }

    private fun tapNode(service: DiaAccessibilityService, node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) {
            try {
                if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            } catch (_: Exception) {}
        }
        val bounds = Rect().apply { node.getBoundsInScreen(this) }
        if (bounds.width() == 0 || bounds.height() == 0) return false
        return service.performTap(bounds.centerX(), bounds.centerY())
    }
}
