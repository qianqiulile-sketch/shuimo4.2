package com.dia.app.guide.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View

/**
 * Glass-lens cursor. Ported from CursorBuddy but retuned for Dia's palette.
 * Drawn inside a bounded square view; the caller positions the view.
 */
class PointerOverlayView(context: Context) : View(context) {

    var pulseScale: Float = 1f
        set(v) { field = v; invalidate() }

    private val lensBody = Paint(Paint.ANTI_ALIAS_FLAG)
    private val saturation = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val innerShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val specular = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dropShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x55000000.toInt()
        style = Paint.Style.FILL
        setShadowLayer(14f, 0f, 6f, 0x66000000.toInt())
    }

    private var pulseAnim: ValueAnimator? = null

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    /** Samsung touch-through: let all touches fall through to the app below. */
    override fun dispatchTouchEvent(event: android.view.MotionEvent?): Boolean = false
    override fun onTouchEvent(event: android.view.MotionEvent?): Boolean = false

    fun startPulse() {
        stopPulse()
        pulseAnim = ValueAnimator.ofFloat(1f, 1.12f, 1f).apply {
            duration = 700
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { pulseScale = it.animatedValue as Float }
            start()
        }
    }

    fun stopPulse() {
        pulseAnim?.cancel()
        pulseAnim = null
        pulseScale = 1f
    }

    override fun onDetachedFromWindow() {
        stopPulse()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (Math.min(width, height) / 2f - 6f) * 0.82f * pulseScale
        if (radius <= 0f) return

        // shadow
        canvas.drawCircle(cx, cy + 3f, radius, dropShadow)
        // body
        lensBody.shader = RadialGradient(
            cx - radius * 0.25f, cy - radius * 0.25f, radius * 1.1f,
            intArrayOf(0x30FFFFFF, 0x1800E676, 0x22000000),
            floatArrayOf(0f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, lensBody)

        // saturation (Dia green pulse)
        saturation.shader = RadialGradient(
            cx, cy, radius * 0.95f,
            intArrayOf(0x6600E676, 0x3300D4FF, 0x00000000),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, saturation)

        // inner shadow
        innerShadow.strokeWidth = radius * 0.22f
        innerShadow.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(0x00000000, 0x00000000, 0x55000000.toInt()),
            floatArrayOf(0f, 0.78f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius - innerShadow.strokeWidth / 2f, innerShadow)

        // chrome rim
        rim.strokeWidth = 3f
        rim.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                0xFFFFFFFF.toInt(),
                0xFF81E6A1.toInt(),
                0xFF00E676.toInt(),
                0xFFFFFFFF.toInt(),
                0xFF81E6A1.toInt(),
                0xFFFFFFFF.toInt()
            ),
            null
        )
        canvas.drawCircle(cx, cy, radius - 1f, rim)

        // specular
        specular.shader = RadialGradient(
            cx - radius * 0.35f, cy - radius * 0.45f, radius * 0.55f,
            intArrayOf(0xCCFFFFFF.toInt(), 0x33FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawOval(
            RectF(
                cx - radius * 0.7f, cy - radius * 0.8f,
                cx + radius * 0.05f, cy - radius * 0.1f
            ),
            specular
        )
    }
}
