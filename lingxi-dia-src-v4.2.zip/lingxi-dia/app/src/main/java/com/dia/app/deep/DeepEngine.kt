package com.dia.app.deep

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import com.dia.app.agent.AgentListener
import com.dia.app.agent.AgentRequest
import com.dia.app.agent.AgentTools
import com.dia.app.agent.DiaAgent
import com.dia.app.agent.ToolOutcome
import com.dia.app.files.AiFolder
import com.dia.app.files.FileManager
import com.dia.app.files.OfficeXml
import com.dia.app.files.TextDecode
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import com.dia.app.ui.chat.ChatController
import com.dia.app.web.WebSearch
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** 等用户批准的一个操作（长思关闭了「自动批准」时）。 */
data class DeepConfirm(val sessionId: String, val title: String, val detail: String)

/**
 * 自主长思引擎 —— 以速度换深度、可以无限运行的 AI 自循环。
 *
 * 每个长思是一个「计划 → 执行 → 记账 → 提炼 → 核对 → 复盘」的循环（参考 Plan-and-Execute、Reflexion、
 * BabyAGI、LangChain open_deep_research 与 Manus 的上下文工程）：
 *  1. 拆解：先（可选联网）了解主题，结合用户给的资料制定分层计划（用户随时可改）
 *  2. 执行：每一轮挑下一个步骤，调用一切工具完成；搜索 / 网页 / 研究结果由 [DeepHooks] 自动存档，
 *     文件名写错也能模糊找到，搜过的词不会重搜
 *  3. 记账：每步完整过程写进「步骤/<步骤id>_标题.md」（id 稳定，计划调整后不会错位），登记到「00_目录索引.md」
 *  4. 提炼：把本步的要点（带来源）压缩进「知识库.md」，之后每一轮按相关度带上 —— 上下文有限，记忆在文件里
 *  5. 交付门（v4.2）：步骤要求产出的文件必须真的在磁盘上、能打开、内容像样（[DeepGate]）。
 *     AI 只说不做时先在本步内催它动手；还没写成就由系统按它的内容「代写落盘」，回读校验通过才算完成。
 *     结论里附「系统核验」回执，成果报告只认回执。连续失败的步骤会提醒用户补充资料
 *  6. 复盘：一轮计划做完 → 更新成果（Word / PPT / PDF / Excel）→ 复盘找新方向，**一直运行直到用户暂停**
 *  7. 备份：每隔几轮、暂停和完成时，把全部过程导出成「备份/长思全记录.docx」
 *
 * 用户随时可以插话、添加文件（下一轮优先处理；勾「立即」会打断当前步骤）。在后台由 [DeepThinkService] 保活。
 */
object DeepEngine {

    private const val TAG = "DeepEngine"
    private const val MAX_EVENTS = 400

    private lateinit var appCtx: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _sessions = MutableStateFlow<List<DeepSession>>(emptyList())
    val sessions: StateFlow<List<DeepSession>> = _sessions.asStateFlow()

    private val eventFlows = ConcurrentHashMap<String, MutableStateFlow<List<DeepEvent>>>()
    private val loops = ConcurrentHashMap<String, Job>()
    private val stepJobs = ConcurrentHashMap<String, Job>()
    private val confirmWaits = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    /** 同一个长思同时只生成一份成果 / 备份 */
    private val exportLocks = ConcurrentHashMap<String, Mutex>()

    private val _confirm = MutableStateFlow<DeepConfirm?>(null)
    /** 当前等用户批准的操作（界面顶部显示「准 / 驳」）。 */
    val confirm: StateFlow<DeepConfirm?> = _confirm.asStateFlow()

    /** 正在导出 / 生成成果的长思（界面显示进度）。 */
    private val _exporting = MutableStateFlow<Set<String>>(emptySet())
    val exporting: StateFlow<Set<String>> = _exporting.asStateFlow()

    private val timeFmt = SimpleDateFormat("M月d日 HH:mm", Locale.CHINA)

    val FORMAT_LABELS = linkedMapOf("docx" to "Word", "pptx" to "PPT", "pdf" to "PDF", "xlsx" to "Excel", "md" to "Markdown")

    val isReady: Boolean get() = ::appCtx.isInitialized

    fun init(context: Context) {
        if (::appCtx.isInitialized) return
        appCtx = context.applicationContext
        scope.launch(Dispatchers.IO) { loadAll() }
    }

    // ───────── 读写 ─────────

    private fun root(): File = AiFolder.dir("长思")

    private fun loadAll() {
        val list = ArrayList<DeepSession>()
        try {
            for (d in root().listFiles().orEmpty()) {
                val f = File(d, "state.json")
                if (!f.isFile) continue
                try {
                    val s = DeepJson.session(JSONObject(f.readText())).let { it.copy(folder = d.absolutePath) }
                    list.add(s)
                    val ev = File(d, "events.json")
                    val events = if (ev.isFile) DeepJson.events(JSONArray(ev.readText())) else emptyList()
                    eventFlows.getOrPut(s.id) { MutableStateFlow(emptyList()) }.value = events
                } catch (e: Exception) {
                    Log.w(TAG, "skip ${d.name}: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "loadAll: ${e.message}")
        }
        _sessions.value = list.sortedByDescending { it.updatedAt }
    }

    fun get(id: String): DeepSession? = _sessions.value.firstOrNull { it.id == id }

    fun events(id: String): StateFlow<List<DeepEvent>> = eventFlows.getOrPut(id) { MutableStateFlow(emptyList()) }.asStateFlow()

    fun folderOf(id: String): File? = get(id)?.folder?.takeIf { it.isNotBlank() }?.let { File(it) }

    fun isRunning(id: String): Boolean = loops[id]?.isActive == true

    fun runningCount(): Int = loops.values.count { it.isActive }

    /** 当前步骤的简短标记（如「s12 收集资料」），用于登记文件来源。 */
    fun stepTag(id: String): String {
        val s = get(id) ?: return ""
        val sid = s.currentStepId ?: return "第 ${s.cycles} 轮"
        val st = PlanOps.find(s.plan, sid)
        return "$sid ${st?.title?.take(20).orEmpty()}".trim()
    }

    private fun mutate(id: String, persist: Boolean = true, f: (DeepSession) -> DeepSession): DeepSession? {
        var out: DeepSession? = null
        _sessions.update { list ->
            list.map { s -> if (s.id == id) f(s).copy(updatedAt = System.currentTimeMillis()).also { out = it } else s }
        }
        if (persist) out?.let { save(it) }
        return out
    }

    private fun save(s: DeepSession) {
        val dir = File(s.folder)
        scope.launch(Dispatchers.IO) {
            try {
                dir.mkdirs()
                // 先写临时文件再改名：写到一半被杀也不会把 state.json 写坏
                val tmp = File(dir, "state.json.${System.nanoTime()}.tmp")
                tmp.writeText(DeepJson.session(s).toString(1))
                if (!tmp.renameTo(File(dir, "state.json"))) {
                    File(dir, "state.json").writeText(DeepJson.session(s).toString(1)); tmp.delete()
                }
                File(dir, "计划.md").writeText(PlanOps.markdown(s.topic, s.plan))
                AiFolder.touch()
            } catch (e: Exception) {
                Log.w(TAG, "save: ${e.message}")
            }
        }
    }

    private fun saveEvents(id: String) {
        val s = get(id) ?: return
        val list = eventFlows[id]?.value ?: return
        scope.launch(Dispatchers.IO) {
            try { File(s.folder, "events.json").writeText(DeepJson.events(list.takeLast(MAX_EVENTS)).toString()) } catch (_: Exception) { }
        }
    }

    private fun event(id: String, kind: String, title: String, detail: String = "", status: String = "", note: String = "", toolName: String? = null): String {
        val e = DeepEvent(UUID.randomUUID().toString(), System.currentTimeMillis(), kind, title, detail, status, note, toolName)
        eventFlows.getOrPut(id) { MutableStateFlow(emptyList()) }.update { (it + e).takeLast(MAX_EVENTS) }
        return e.id
    }

    private fun updateEvent(id: String, eventId: String, f: (DeepEvent) -> DeepEvent) {
        eventFlows[id]?.update { list -> list.map { if (it.id == eventId) f(it) else it } }
    }

    private fun appendFile(s: DeepSession, name: String, text: String) {
        try {
            val f = File(s.folder, name)
            f.parentFile?.mkdirs()
            f.appendText(text)
        } catch (e: Exception) {
            Log.w(TAG, "append $name: ${e.message}")
        }
    }

    private fun activity(id: String, text: String) {
        mutate(id, persist = false) { it.copy(activity = text) }
        DeepThinkService.refresh(appCtx)
    }

    /** 把文件登记进目录索引并刷新「00_目录索引.md」。 */
    private fun register(s: DeepSession, f: File, desc: String, step: String = "") {
        try {
            val folder = File(s.folder)
            DeepMemory.registerFile(folder, f, desc, step)
            DeepMemory.writeIndex(folder, s.topic)
        } catch (_: Exception) { }
    }

    // ───────── 对外：新建 / 运行 / 暂停 / 删除 ─────────

    fun defaultDeliverables(): List<String> =
        DiaSettings.deepDeliverables.value.split(',', '，', ' ').map { it.trim().lowercase() }.filter { it in FORMAT_LABELS }.ifEmpty { listOf("docx") }

    /** 新建一个长思，默认立即开始。返回编号。 */
    fun create(
        context: Context,
        topic: String,
        web: String = DiaSettings.deepWeb.value,
        autoApprove: Boolean = DiaSettings.deepAutoApprove.value,
        maxCycles: Int = 0,
        reviewFirst: Boolean = false,
        start: Boolean = true,
        deliverables: List<String> = defaultDeliverables(),
    ): String {
        init(context)
        val now = System.currentTimeMillis()
        val id = "d" + java.lang.Long.toString(now, 36)
        val safe = DeepMemory.slug(topic, 18).ifBlank { "长思" }
        val folder = File(root(), SimpleDateFormat("yyyyMMdd-HHmm", Locale.CHINA).format(Date(now)) + "_" + safe)
        DeepMemory.ensureLayout(folder)
        val s = DeepSession(
            id = id, topic = topic.trim(), createdAt = now, status = "idle", web = web, autoApprove = autoApprove,
            maxCycles = maxCycles, reviewFirst = reviewFirst, folder = folder.absolutePath,
            deliverables = deliverables.filter { it in FORMAT_LABELS }.ifEmpty { listOf("docx") },
        )
        _sessions.update { listOf(s) + it }
        save(s)
        try {
            File(folder, "日志.md").writeText("# 长思日志：${s.topic}\n\n开始于 ${timeFmt.format(Date(now))}\n\n")
            DeepMemory.scan(folder)
            DeepMemory.writeIndex(folder, s.topic)
        } catch (_: Exception) { }
        event(id, "system", "长思已创建：${s.topic}", "目录：灵犀AI/${AiFolder.rel(folder)}\n成果格式：${s.deliverables.joinToString("、") { FORMAT_LABELS[it] ?: it }}")
        if (start) start(id)
        return id
    }

    /** 开始 / 继续运行。 */
    fun start(id: String) {
        if (!isReady) return
        if (loops[id]?.isActive == true) return
        val s = get(id) ?: return
        if (s.status == "done" || s.status == "error") mutate(id) { it.copy(status = "paused", emptyReflections = 0) }
        val job = scope.launch { loop(id) }
        loops[id] = job
        DeepThinkService.refresh(appCtx)
    }

    /** 暂停（当前步骤会中断，下次继续时从这一步重新开始）。暂停时顺手导出一份 Word 全记录。 */
    fun pause(id: String, backup: Boolean = true) {
        val wasRunning = loops[id]?.isActive == true
        loops.remove(id)?.cancel()
        stepJobs.remove(id)?.cancel()
        confirmWaits.remove(id)?.complete(false)
        if (_confirm.value?.sessionId == id) _confirm.value = null
        val s = mutate(id) { s ->
            s.copy(
                status = if (s.status == "done") "done" else "paused",
                plan = PlanOps.resetDoing(s.plan),
                currentStepId = null,
                activity = "已暂停",
            )
        }
        event(id, "system", "⏸ 已暂停")
        saveEvents(id)
        if (!ChatController.isGenerating.value) LlmGateway.cancelCurrent()
        DeepThinkService.refresh(appCtx)
        if (backup && wasRunning && s != null && s.cycles > s.backupCycle) scope.launch { exportBackup(id) }
    }

    /** 打断当前正在执行的步骤（它会回到待办，下一轮重新安排）。 */
    private fun interruptStep(id: String) {
        stepJobs[id]?.cancel()
        if (!ChatController.isGenerating.value) LlmGateway.cancelCurrent()
    }

    fun pauseAll() {
        for (id in loops.keys.toList()) pause(id)
    }

    fun delete(id: String, deleteFiles: Boolean) {
        pause(id, backup = false)
        val s = get(id)
        _sessions.update { list -> list.filter { it.id != id } }
        eventFlows.remove(id)
        if (s != null) {
            scope.launch(Dispatchers.IO) {
                val dir = File(s.folder)
                DeepMemory.forget(dir)
                if (deleteFiles) dir.deleteRecursively() else File(dir, "state.json").delete()
                AiFolder.touch()
            }
        }
    }

    /** 打开灵犀时继续上次没暂停的长思。 */
    fun resumeAll(context: Context) {
        init(context)
        if (!DiaSettings.deepResumeOnStart.value) return
        scope.launch {
            // 等列表从磁盘读出来
            var tries = 0
            while (_sessions.value.isEmpty() && tries++ < 20) delay(150)
            for (s in _sessions.value) {
                if ((s.status == "running" || s.status == "planning") && loops[s.id]?.isActive != true) {
                    event(s.id, "system", "▶ 灵犀重新打开，自动继续长思")
                    start(s.id)
                }
            }
        }
    }

    // ───────── 用户随时插话 / 加文件 / 改计划 ─────────

    fun addNote(id: String, text: String, urgent: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty()) return
        val n = DeepNote(UUID.randomUUID().toString().take(8), t, System.currentTimeMillis(), urgent = urgent)
        var retried: List<String> = emptyList()
        val s = mutate(id) { cur ->
            // 用户给了新信息：之前卡住失败的步骤再给一次机会
            val (plan, ids) = PlanOps.resetFailed(cur.plan)
            retried = ids
            cur.copy(notes = cur.notes + n, plan = plan, attempts = cur.attempts - ids.toSet())
        } ?: return
        event(id, "user", t, note = if (urgent) "立即处理" else "下一轮处理")
        if (retried.isNotEmpty()) event(id, "plan", "有了你的新信息，之前卡住的 ${retried.size} 个步骤会重新尝试")
        appendFile(s, "日志.md", "\n> 【用户 ${timeFmt.format(Date())}】$t\n")
        if (urgent && isRunning(id)) {
            interruptStep(id)
            event(id, "system", "已打断当前步骤，先处理你的新指令")
        } else if (!isRunning(id) && s.status != "done") {
            // 暂停中收到消息：不自动开始，等用户点继续
            event(id, "system", "长思已暂停，点「继续」后会先处理这条消息")
        }
    }

    /**
     * 用户手动添加文件（资料、要修改的 Word/PPT/PDF、卡住时补充的东西）：
     * 复制到「用户资料/」、登记编号、写进目录索引，并作为一条消息交给 AI。
     */
    fun importFiles(context: Context, id: String, uris: List<Uri>, note: String = "") {
        val s = get(id) ?: return
        if (uris.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            val folder = File(s.folder)
            val dir = File(folder, DeepMemory.DIR_USER).apply { mkdirs() }
            val cr = context.applicationContext.contentResolver
            val names = ArrayList<String>()
            for (u in uris) {
                try {
                    var name = "文件_${System.currentTimeMillis()}"
                    try {
                        cr.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                            if (c.moveToFirst()) c.getString(0)?.takeIf { it.isNotBlank() }?.let { name = it }
                        }
                    } catch (_: Exception) { }
                    val target = AiFolder.unique(dir, name)
                    val ok = cr.openInputStream(u)?.use { inp -> target.outputStream().use { out -> inp.copyTo(out) }; true } ?: false
                    if (!ok) { event(id, "error", "读不到文件：$name"); continue }
                    val ref = FileManager.attachPath(target.absolutePath)
                    DeepMemory.registerFile(folder, target, "用户提供的资料" + if (note.isNotBlank()) "：${note.take(40)}" else "", "用户添加", ref.id)
                    names.add("${DeepMemory.DIR_USER}/${target.name}（${ref.id}，${AiFolder.sizeLabel(target.length())}）")
                } catch (e: Exception) {
                    event(id, "error", "添加文件失败：${e.message}")
                }
            }
            if (names.isEmpty()) return@launch
            DeepMemory.writeIndex(folder, s.topic)
            AiFolder.touch()
            event(id, "system", "📎 你添加了 ${names.size} 个文件", names.joinToString("\n"))
            addNote(
                id,
                "我添加了文件：\n" + names.joinToString("\n") { "- $it" } +
                    (if (note.isNotBlank()) "\n说明：$note" else "") +
                    "\n请先阅读（ai_files read 或 read_file），把有用的内容提炼进结论，需要的话据此调整计划；如果是要修改的文件，按要求修改后放进 成果/。",
            )
        }
    }

    fun addStep(id: String, title: String, parentId: String? = null, afterId: String? = null, detail: String = "") {
        if (title.isBlank()) return
        mutate(id) { s ->
            val step = DeepStep("s${s.nextId}", title.trim(), detail.trim(), by = "user")
            s.copy(plan = PlanOps.insert(s.plan, step, parentId, afterId), nextId = s.nextId + 1,
                status = if (s.status == "done") "paused" else s.status)
        }
        event(id, "plan", "你新增了步骤：$title")
    }

    fun editStep(id: String, stepId: String, title: String, detail: String) {
        mutate(id) { s -> s.copy(plan = PlanOps.update(s.plan, stepId) { it.copy(title = title.trim().ifBlank { it.title }, detail = detail.trim()) }) }
        event(id, "plan", "你修改了步骤：$title")
    }

    fun setStepStatus(id: String, stepId: String, status: String) {
        val st = PlanOps.normalizeStatus(status)
        mutate(id) { s ->
            s.copy(
                plan = PlanOps.update(s.plan, stepId) { it.copy(status = st) },
                // 手动改回待办：重新计数
                attempts = if (st == DeepStep.TODO) s.attempts - stepId else s.attempts,
            )
        }
        if (st == DeepStep.SKIP && get(id)?.currentStepId == stepId) interruptStep(id)
    }

    fun removeStep(id: String, stepId: String) {
        val title = get(id)?.plan?.let { PlanOps.find(it, stepId)?.title }.orEmpty()
        if (get(id)?.currentStepId == stepId) interruptStep(id)
        mutate(id) { s -> s.copy(plan = PlanOps.remove(s.plan, stepId)) }
        event(id, "plan", "你删除了步骤：$title")
    }

    fun moveStep(id: String, stepId: String, up: Boolean) {
        mutate(id) { s -> s.copy(plan = PlanOps.move(s.plan, stepId, up)) }
    }

    /** 修改长思的运行选项（联网方式 / 自动批准 / 轮数上限 / 成果格式），下一轮生效。 */
    fun setOptions(id: String, web: String? = null, autoApprove: Boolean? = null, maxCycles: Int? = null, deliverables: List<String>? = null) {
        mutate(id) { s ->
            s.copy(
                web = web ?: s.web,
                autoApprove = autoApprove ?: s.autoApprove,
                maxCycles = maxCycles ?: s.maxCycles,
                deliverables = deliverables?.filter { it in FORMAT_LABELS }?.ifEmpty { listOf("docx") } ?: s.deliverables,
            )
        }
        web?.let { event(id, "system", "联网方式改为：" + mapOf("auto" to "自行决定", "on" to "允许联网", "off" to "不联网")[it]) }
        if (deliverables != null) get(id)?.let { cur -> event(id, "system", "成果格式改为：" + formatsLabel(cur)) }
    }

    /** 改主题描述（下一轮生效）。 */
    fun setTopic(id: String, topic: String) {
        if (topic.isBlank()) return
        mutate(id) { it.copy(topic = topic.trim()) }
        event(id, "system", "主题改为：$topic")
    }

    /** 确认计划（「生成计划后先等我确认」时）。 */
    fun approvePlan(id: String) {
        mutate(id) { it.copy(status = "running") }
        event(id, "plan", "你确认了计划，开始执行")
        start(id)
    }

    /** 让 AI 把某一步细化成若干子步骤。 */
    fun refineStep(id: String, stepId: String) {
        scope.launch {
            val s = get(id) ?: return@launch
            val step = PlanOps.find(s.plan, stepId) ?: return@launch
            event(id, "plan", "AI 正在细化：${step.title}")
            val out = try {
                LlmGateway.complete(
                    system = "你是严谨的项目规划师。只输出编号列表。",
                    prompt = "【长思主题】${s.topic}\n【整体计划】\n${PlanOps.render(s.plan, stepId, 0)}\n\n" +
                        "请把步骤「${step.title}」${if (step.detail.isNotBlank()) "（${step.detail}）" else ""}细化成 2~5 个更具体、可直接执行的子步骤。" +
                        "每行「1. 标题：做什么、产出什么」。只输出列表。",
                    temperature = 0.3,
                    timeoutMs = 120_000,
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                event(id, "error", "细化失败：${e.message}")
                return@launch
            }
            val items = PlanOps.parseOutline(out).map { Triple(0, it.second, it.third) }
            if (items.isEmpty()) { event(id, "error", "AI 没给出可用的子步骤"); return@launch }
            mutate(id) { cur ->
                val (kids, next) = PlanOps.build(items, cur.nextId)
                cur.copy(plan = PlanOps.update(cur.plan, stepId) { it.copy(children = it.children + kids, status = DeepStep.TODO) }, nextId = next)
            }
            event(id, "plan", "已把「${step.title}」细化为 ${items.size} 个子步骤")
        }
    }

    fun resolveConfirm(approved: Boolean) {
        val c = _confirm.value ?: return
        _confirm.value = null
        confirmWaits.remove(c.sessionId)?.complete(approved)
        event(c.sessionId, "confirm", if (approved) "✓ 你批准了：${c.title}" else "✗ 你驳回了：${c.title}")
    }

    /** 立即导出 Word 全记录（界面按钮）。 */
    fun backupNow(id: String) {
        scope.launch { exportBackup(id, force = true) }
    }

    /** 立即按设定的格式生成 / 更新成果（界面按钮）。 */
    fun generateNow(id: String) {
        scope.launch {
            try { generateDeliverables(id) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
                event(id, "error", "生成成果失败：${e.message}")
            }
        }
    }

    // ───────── 给 AI 的工具 ─────────

    fun planTool(sessionId: String?, args: JSONObject): ToolOutcome {
        if (sessionId == null || get(sessionId) == null) {
            return ToolOutcome("plan 工具只能在自主长思里使用。要开启长思请用 deep_think。", ok = false)
        }
        val id: String = sessionId
        val action = args.optString("action").trim().lowercase().ifBlank { "view" }
        val s0 = get(id) ?: return ToolOutcome("长思不存在", ok = false)
        fun key(k: String): String? = args.optString(k).takeIf { it.isNotBlank() }?.let { PlanOps.resolveId(s0.plan, it) }
        fun stepList(): List<Triple<Int, String, String>> {
            val arr = args.optJSONArray("steps")
            if (arr != null) {
                return (0 until arr.length()).mapNotNull { i ->
                    val o = arr.optJSONObject(i)
                    if (o != null) {
                        val t = o.optString("title").ifBlank { o.optString("q") }.trim()
                        if (t.isBlank()) null else Triple(0, t, o.optString("detail").ifBlank { o.optString("note") })
                    } else arr.optString(i).trim().takeIf { it.isNotBlank() }?.let { Triple(0, it, "") }
                }
            }
            val text = args.optString("steps").ifBlank { args.optString("title") }
            if (text.contains('\n')) return PlanOps.parseOutline(text).map { Triple(0, it.second, it.third) }
            return if (text.isNotBlank()) listOf(Triple(0, text.trim(), args.optString("detail").ifBlank { args.optString("note") })) else emptyList()
        }
        return when (action) {
            "view", "show", "list" -> ToolOutcome(PlanOps.render(s0.plan, s0.currentStepId, 120))
            "add", "insert", "append" -> {
                val items = stepList()
                if (items.isEmpty()) return ToolOutcome("缺少要新增的步骤 title / steps", ok = false)
                val parent = key("parent")
                val after = key("after")
                mutate(id) { cur ->
                    var plan = cur.plan
                    var next = cur.nextId
                    var anchor = after
                    for ((_, t, d) in items) {
                        val st = DeepStep("s${next++}", t, d, by = "ai")
                        plan = PlanOps.insert(plan, st, parent, anchor)
                        anchor = st.id
                    }
                    cur.copy(plan = plan, nextId = next)
                }
                event(id, "plan", "AI 给自己新增了 ${items.size} 个步骤", items.joinToString("\n") { "· " + it.second })
                ToolOutcome("已新增 ${items.size} 个步骤。当前计划：\n" + PlanOps.render(get(id)!!.plan, get(id)!!.currentStepId, 0))
            }
            "split", "refine", "expand" -> {
                val target = key("id") ?: s0.currentStepId ?: return ToolOutcome("缺少要细化的步骤 id", ok = false)
                val items = stepList()
                if (items.isEmpty()) return ToolOutcome("缺少子步骤 steps", ok = false)
                mutate(id) { cur ->
                    val (kids, next) = PlanOps.build(items, cur.nextId)
                    cur.copy(plan = PlanOps.update(cur.plan, target) { it.copy(children = it.children + kids) }, nextId = next)
                }
                event(id, "plan", "AI 把步骤细化为 ${items.size} 个子步骤", items.joinToString("\n") { "· " + it.second })
                ToolOutcome("已细化。当前计划：\n" + PlanOps.render(get(id)!!.plan, get(id)!!.currentStepId, 0))
            }
            "update", "edit", "set", "mark" -> {
                val target = key("id") ?: return ToolOutcome("缺少步骤 id（如 s3 或 1.2）", ok = false)
                val title = args.optString("title").trim()
                val status = args.optString("status").trim()
                val note = args.optString("note").ifBlank { args.optString("detail") }.trim()
                mutate(id) { cur ->
                    cur.copy(plan = PlanOps.update(cur.plan, target) { st ->
                        st.copy(
                            title = title.ifBlank { st.title },
                            status = if (status.isNotBlank()) PlanOps.normalizeStatus(status) else st.status,
                            detail = if (note.isNotBlank()) note else st.detail,
                        )
                    })
                }
                event(id, "plan", "AI 更新了步骤 ${PlanOps.labelOf(get(id)!!.plan, target) ?: target}", listOf(title, status, note).filter { it.isNotBlank() }.joinToString(" · "))
                ToolOutcome("已更新。当前计划：\n" + PlanOps.render(get(id)!!.plan, get(id)!!.currentStepId, 0))
            }
            "remove", "delete" -> {
                val target = key("id") ?: return ToolOutcome("缺少步骤 id", ok = false)
                val t = PlanOps.find(s0.plan, target)?.title.orEmpty()
                mutate(id) { cur -> cur.copy(plan = PlanOps.remove(cur.plan, target)) }
                event(id, "plan", "AI 删除了步骤：$t")
                ToolOutcome("已删除「$t」。")
            }
            "move" -> {
                val target = key("id") ?: return ToolOutcome("缺少步骤 id", ok = false)
                val up = args.optString("note").ifBlank { args.optString("direction") }.lowercase().let { it == "up" || it.contains("上") }
                mutate(id) { cur -> cur.copy(plan = PlanOps.move(cur.plan, target, up)) }
                ToolOutcome("已${if (up) "上移" else "下移"}。")
            }
            else -> ToolOutcome("不支持的操作「$action」：可用 view / add / split / update / remove / move", ok = false)
        }
    }

    fun askUser(sessionId: String?, question: String): ToolOutcome {
        if (sessionId == null || get(sessionId) == null) return ToolOutcome("ask_user 只能在自主长思里使用；对话里直接问用户即可。", ok = false)
        if (question.isBlank()) return ToolOutcome("缺少问题 question", ok = false)
        event(sessionId, "question", question)
        get(sessionId)?.let { appendFile(it, "日志.md", "\n> 【AI 请示】$question\n") }
        DeepThinkService.notifyQuestion(appCtx, get(sessionId)?.topic.orEmpty(), question)
        return ToolOutcome("已把问题发给用户（不阻塞；用户可以回复或在长思页「添加文件」）。请先按最合理的假设继续推进，并在结论里写明你的假设；用户回复后会出现在【用户新消息】里。")
    }

    // ───────── 主循环 ─────────

    private suspend fun loop(id: String) {
        var errors = 0
        try {
            mutate(id) { if (it.status != "review") it.copy(status = "running") else it }
            event(id, "system", "▶ 长思开始运行")
            // 老版本的长思目录：补齐新目录结构、登记已有文件
            get(id)?.let { s ->
                withContext(Dispatchers.IO) {
                    try {
                        val folder = File(s.folder)
                        DeepMemory.ensureLayout(folder)
                        DeepMemory.scan(folder)
                        DeepMemory.writeIndex(folder, s.topic)
                    } catch (_: Exception) { }
                }
            }
            while (currentCoroutineContext().isActive) {
                val s = get(id) ?: break
                if (s.status == "paused" || s.status == "done") break
                if (s.status == "review") { activity(id, "等你确认计划…"); delay(1500); continue }
                if (!LlmGateway.isAvailable()) { activity(id, "等待模型加载（请在对话页选择模型）…"); delay(15_000); continue }
                // 礼让：本机模型同一时间只能跑一个推理，用户在对话时先让用户
                if (!LlmGateway.canParallel() && ChatController.isGenerating.value) { activity(id, "你正在对话，稍候继续…"); delay(1500); continue }
                if (s.maxCycles > 0 && s.cycles >= s.maxCycles) {
                    finish(id, "已达到设定的 ${s.maxCycles} 轮")
                    break
                }
                try {
                    if (s.plan.isEmpty()) {
                        makePlan(id)
                        continue
                    }
                    val step = PlanOps.nextTodo(s.plan)
                    if (step == null) {
                        // 一轮计划做完：先把成果更新出来，再复盘找新方向
                        if (s.cycles > s.reportCycle) {
                            try { generateDeliverables(id) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
                                event(id, "error", "生成成果失败：${e.message}")
                            }
                        }
                        val added = reflect(id)
                        if (added == 0) {
                            val cur = get(id) ?: break
                            if (!DiaSettings.deepEndless.value || cur.emptyReflections >= 3) {
                                finish(id, "计划已全部完成")
                                break
                            }
                        }
                        continue
                    }
                    coroutineScope {
                        val j = launch { runCycle(id, step) }
                        stepJobs[id] = j
                        j.join()
                        stepJobs.remove(id)
                        if (j.isCancelled && currentCoroutineContext().isActive) {
                            // 被用户「立即处理」或删除 / 跳过打断：这一步回到待办
                            mutate(id) { cur -> cur.copy(plan = PlanOps.resetDoing(cur.plan), currentStepId = null) }
                        }
                    }
                    errors = 0
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    errors++
                    Log.w(TAG, "cycle error", e)
                    event(id, "error", "出错了：${e.message ?: e.javaClass.simpleName}", note = "第 $errors 次")
                    mutate(id) { cur -> cur.copy(plan = PlanOps.resetDoing(cur.plan), currentStepId = null) }
                    // 不限时运行：网络断了、模型超时都只是暂时的，退避后一直重试；设了轮数上限时连续 6 次才停
                    val endless = DiaSettings.deepEndless.value && s.maxCycles == 0
                    if (!endless && errors >= 6) {
                        mutate(id) { it.copy(status = "error", activity = "连续出错，已暂停：${e.message}") }
                        break
                    }
                    val wait = (10_000L * errors).coerceAtMost(10 * 60_000L)
                    activity(id, "出错了，${wait / 1000} 秒后重试（第 $errors 次）…")
                    delay(wait)
                }
                delay(DiaSettings.deepCycleDelay.value.coerceIn(0, 120) * 1000L)
            }
        } finally {
            // 只移除自己（暂停后马上继续时，新的循环已经登记了）
            currentCoroutineContext()[Job]?.let { me -> loops.remove(id, me) }
            saveEvents(id)
            DeepThinkService.refresh(appCtx)
        }
    }

    private fun finish(id: String, reason: String) {
        val s = mutate(id) { it.copy(status = "done", currentStepId = null, activity = reason) } ?: return
        event(id, "system", "✅ $reason", "总结与全部产出都在：灵犀AI/${AiFolder.rel(File(s.folder))}")
        scope.launch {
            try {
                if (s.cycles > s.reportCycle) generateDeliverables(id)
                exportBackup(id, force = true)
            } catch (e: Exception) { Log.w(TAG, "report: ${e.message}") }
        }
    }

    private fun webLabel(web: String): String = when (web) {
        "off" -> "本次长思不联网，只用已有知识、文件和计算"
        "on" -> "可以随时联网（web_search / read_webpage / download）"
        else -> "需要最新信息或资料时自行联网（web_search / read_webpage），不需要时不必联网"
    }

    private fun formatsLabel(s: DeepSession): String = s.deliverables.joinToString("、") { FORMAT_LABELS[it] ?: it }

    private fun mission(s: DeepSession): String = """
【自主长思模式】
你在后台独立完成一个长期主题，身边没有人实时对话，求扎实不求快。系统每一轮交给你计划里的一个步骤，你要把它真正做完。
铁律（系统会逐条核对，做不到就算没完成、要重做）：
1. 先写文件，再说写了。只有工具结果里出现「已写入 / 已生成」才算写过；系统会打开文件检查内容，没写、空的、只有框架或「待补充」的都不算。
2. 本步要求产出的文件，要把**完整正文**写进去（写诗就写出完整的诗句，写大纲就写出每一部分的具体内容），不要只写打算。写法：
<tool>{"name":"ai_files","args":{"action":"write","path":"成果/文件名.txt","content":"完整正文","desc":"一句话说明"}}</tool>
   Word/PPT/PDF/Excel：扩展名写成 .docx/.pptx/.pdf/.xlsx，content 用 Markdown（PPT 用「# 页标题」分页、「- 要点」）。改已有文件：先 doc_outline 看结构再 edit_file 精修，或 rewrite_file 整篇改写。本长思的成果格式：${formatsLabel(s)}。
3. 要做的事直接调用工具去做，不要只说「我将… / 首先…」就结束；不要复述系统给你的格式说明。
4. 资料够用就动手：【已搜索过】的词不要再搜（要原文用 ai_files read 读存档）；标了「已用过」的资料不必再读；用完的资料可以 mark_file 标成 used。
5. 联网：${webLabel(s.web)}。工作目录：成果/ 交付物；资料/ 自动存档的搜索与网页；用户资料/ 用户给的文件；知识库.md 要点；00_目录索引.md 文件清单。读文件用索引里的路径或 f 编号，不要凭记忆猜文件名。
6. 计划不合适就用 plan 改（add / split / update / remove）；只有用户能答的问题用 ask_user，然后按最合理的假设继续；卡住就换方法或拆小，不要原地打转。
7. 【用户新消息】【待改写的文件】优先处理，然后再做本步。
本步结束时最后输出：
【本步结论】2~6 行：得到了什么（注明来源网址或文件）、写了哪些文件（完整相对路径）
【状态】完成  或  未完成：原因
""".trim()

    private fun cyclePrompt(s: DeepSession, step: DeepStep, notes: List<DeepNote>): String {
        val (done, total) = PlanOps.counts(s.plan)
        val label = PlanOps.labelOf(s.plan, step.id) ?: step.id
        val folder = File(s.folder)
        val budget = LlmGateway.promptCharBudget()
        val idxChars = (budget * 0.12).toInt().coerceIn(400, 3000)
        val factChars = (budget * 0.15).toInt().coerceIn(300, 4000)
        val index = try { DeepMemory.indexForPrompt(folder, idxChars) } catch (_: Exception) { "" }
        val facts = try { DeepMemory.relevantFacts(folder, s.topic + " " + step.title + " " + step.detail, factChars) } catch (_: Exception) { "" }
        val factTotal = try { DeepMemory.factCount(folder) } catch (_: Exception) { 0 }
        val queries = try { DeepMemory.recentQueries(folder, if (budget > 8000) 25 else 10) } catch (_: Exception) { emptyList() }
        val userFiles = try { DeepMemory.userFiles(folder).filter { it.mark != DeepMemory.MARK_IGNORE && it.mark != DeepMemory.MARK_USED }.take(10) } catch (_: Exception) { emptyList() }
        val rewrites = try { DeepMemory.marked(folder, DeepMemory.MARK_REWRITE).take(5) } catch (_: Exception) { emptyList() }
        val keys = try { DeepMemory.marked(folder, DeepMemory.MARK_KEY).take(8) } catch (_: Exception) { emptyList() }
        val outs = step.expectedOutputs
        val prior = try { referenceOutputs(folder, outs.toSet(), (budget * 0.1).toInt().coerceIn(300, 2500)) } catch (_: Exception) { "" }
        val recent = PlanOps.flatten(s.plan).filter { it.step.status == DeepStep.DONE && it.step.result.isNotBlank() }.takeLast(4)
        val attempt = s.attempts[step.id] ?: 0
        return buildString {
            append("【长思主题】").append(s.topic).append('\n')
            append("【成果格式】").append(formatsLabel(s)).append("（放在 成果/）\n")
            append("【进度】第 ").append(s.cycles).append(" 轮 · 已完成 ").append(done).append('/').append(total).append(" 步\n\n")
            append("【计划】（✓完成 ▶当前 ○待办 ⊘跳过 ✗失败）\n").append(PlanOps.render(s.plan, step.id, 60)).append("\n\n")
            append("【阶段总结】\n").append(s.summary.ifBlank { "（暂无，这是开头几步）" }).append("\n\n")
            if (facts.isNotBlank()) {
                append("【知识库 · 与本步相关的要点】（共 ").append(factTotal).append(" 条，全文见 知识库.md）\n").append(facts).append("\n\n")
            }
            if (recent.isNotEmpty()) {
                append("【最近完成的步骤】\n")
                for (r in recent) append("- ").append(r.label).append(' ').append(r.step.title).append("：").append(r.step.result.take(300)).append('\n')
                append('\n')
            }
            if (userFiles.isNotEmpty()) {
                append("【用户提供的资料】（优先阅读利用）\n")
                for (f in userFiles) {
                    append("- ").append(f.path)
                    if (f.fileId.isNotBlank()) append("（").append(f.fileId).append('）')
                    if (f.desc.isNotBlank()) append(" —— ").append(f.desc)
                    append('\n')
                }
                append('\n')
            }
            if (rewrites.isNotEmpty()) {
                append("【待改写的文件】（已标记「优先改写」，先处理：读原文 → 按要求改写 → 写回或另存到 成果/）\n")
                for (f in rewrites) append("- ").append(f.path).append(if (f.markNote.isNotBlank()) "：" + f.markNote else "").append('\n')
                append('\n')
            }
            if (keys.isNotEmpty()) {
                append("【重点参考】（标记为重点的资料，优先利用）\n")
                for (f in keys) append("- ").append(f.path).append(if (f.markNote.isNotBlank()) "：" + f.markNote else "").append('\n')
                append('\n')
            }
            if (prior.isNotBlank()) append("【已有成果（节选，在此基础上继续，保持一致）】\n").append(prior).append("\n\n")
            if (index.isNotBlank()) append("【工作目录索引】（相对路径直接用；找文件看这里）\n").append(index).append("\n\n")
            if (queries.isNotEmpty()) {
                append("【已搜索过】（不要重复搜，需要原文就读存档）\n")
                for ((q, f) in queries) append("- ").append(q).append(" → ").append(f).append('\n')
                append('\n')
            }
            if (notes.isNotEmpty()) {
                append("【用户新消息】（优先处理！）\n")
                for (n in notes) append("- ").append(timeFmt.format(Date(n.time))).append("：").append(n.text).append('\n')
                append('\n')
            }
            append("【本轮任务】[").append(step.id).append("] ").append(label).append(' ').append(step.title)
            if (step.detail.isNotBlank()) append(" —— ").append(step.detail)
            if (outs.isNotEmpty()) {
                append("\n【本步必须产出】")
                for (rel in outs) {
                    val f = try { DeepMemory.findOutput(folder, rel, Long.MAX_VALUE) } catch (_: Exception) { null }
                    append("\n- ").append(rel).append(if (f != null) "（已有 ${AiFolder.sizeLabel(f.length())}，在此基础上完善）" else "（还没有，要新建）")
                }
                append("\n系统会打开这些文件检查内容：没写、空的、只有框架都算没完成。")
            }
            if (attempt > 0) {
                append("\n（这一步之前没做完 ").append(attempt).append(" 次")
                if (step.lastIssue.isNotBlank()) append("，原因：").append(step.lastIssue.take(160))
                append("。这次先把文件写出来；换个方法，或把它拆小；缺资料就 ask_user 请用户添加文件）")
            }
            append("\n\n开始执行。")
        }
    }

    /** 步骤文件：按稳定的步骤 id 命名（计划增删、调整顺序后编号会变，id 不会）。 */
    private fun stepFile(folder: File, step: DeepStep): File {
        val dir = File(folder, DeepMemory.DIR_STEPS).apply { mkdirs() }
        dir.listFiles()?.firstOrNull { it.isFile && it.name.startsWith(step.id + "_") && it.extension == "md" }?.let { return it }
        return File(dir, step.id + "_" + DeepMemory.slug(step.title) + ".md")
    }

    private suspend fun runCycle(id: String, step: DeepStep) {
        val before = mutate(id) { s ->
            s.copy(
                plan = PlanOps.update(s.plan, step.id) { it.copy(status = DeepStep.DOING) },
                currentStepId = step.id,
                cycles = s.cycles + 1,
                activity = "执行 ${PlanOps.labelOf(s.plan, step.id) ?: ""} ${step.title}",
            )
        } ?: return
        val label = PlanOps.labelOf(before.plan, step.id) ?: step.id
        val notes = before.notes.filter { !it.handled }
        val folder = File(before.folder)
        event(id, "cycle", "第 ${before.cycles} 轮 · $label ${step.title}", step.detail, note = if (notes.isNotEmpty()) "带上 ${notes.size} 条你的新消息" else "")
        DeepThinkService.refresh(appCtx)

        val listener = DeepListener(id)
        val started = System.currentTimeMillis()
        val raw = DiaAgent.run(
            AgentRequest(
                history = emptyList(),
                userText = cyclePrompt(before, step, notes),
                extraSystem = mission(before),
                toolsOverride = AgentTools.deepNames(before.web, before.topic + " " + step.title),
                maxStepsOverride = DiaSettings.deepToolsPerStep.value,
                deep = true,
                finishCheck = { answer -> finishCheck(id, step, started, answer) },
            ),
            listener,
        )
        // 去掉复读和复述的提示词（小模型常见），再解析
        val text = DeepGate.tidy(raw)
        // 这一轮正常结束才把带上的用户消息标记为已处理（被打断时下一轮还会带上）
        if (notes.isNotEmpty()) {
            val ids = notes.map { it.id }.toSet()
            mutate(id) { s -> s.copy(notes = s.notes.map { if (it.id in ids) it.copy(handled = true) else it }) }
        }
        val outcome = DeepGate.parseOutcome(text)
        val intentOnly = DeepGate.isIntentOnly(text)
        val prevAttempts = get(id)?.attempts?.get(step.id) ?: 0
        val tag = "${step.id} ${step.title.take(20)}"

        // ── 交付门：先登记磁盘上的文件，再逐个核对本步应产出的文件 ──
        withContext(Dispatchers.IO) { try { DeepMemory.scan(folder, tag) } catch (_: Exception) { } }
        val verify = DiaSettings.deepVerify.value
        val claimed = if (verify) claimedOutputs(outcome.conclusion.ifBlank { text.takeLast(800) }) else emptyList()
        val expected = (step.expectedOutputs + claimed).distinctBy { it.substringAfterLast('/').lowercase() }
        val mustUpdate = mustUpdateOf(step)
        val receipts = ArrayList<Receipt>()
        if (verify) {
            for (rel in expected) {
                var r = withContext(Dispatchers.IO) { inspect(folder, rel, started, rel in mustUpdate) }
                // AI 明说「未完成」时第一次不代写（可能缺资料）；之后照样落盘，保证进度
                val canWrite = DiaSettings.deepMaterialize.value && (outcome.state != DeepGate.State.UNFINISHED || prevAttempts >= 1)
                if (!r.ok && canWrite) {
                    event(id, "system", "🧱 交付门：${r.path} ${r.note}", "AI 没把文件写好，系统按本步的内容写出完整正文，落盘后回读校验…")
                    activity(id, "落盘 ${r.path}…")
                    r = try { materialize(before, step, rel, text, listener.toolLog(), r.note, rel in mustUpdate) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
                        r.copy(note = r.note + "；系统代写出错：${e.message}")
                    }
                }
                receipts.add(r)
            }
        }
        val bad = receipts.filter { !it.ok }
        val wroteBySystem = receipts.any { it.ok && it.by.isNotEmpty() }
        val toolCount = listener.toolCount()
        val finished: Boolean
        val reason: String
        when {
            outcome.state == DeepGate.State.UNFINISHED && !(receipts.isNotEmpty() && bad.isEmpty() && wroteBySystem) -> {
                finished = false; reason = outcome.reason
            }
            receipts.isNotEmpty() -> {
                finished = bad.isEmpty()
                reason = if (finished) "" else "文件没有真正写好：" + bad.joinToString("；") { "${it.path}（${it.note}）" }
            }
            outcome.state == DeepGate.State.DONE -> { finished = true; reason = "" }
            // 没有要产出的文件（查资料之类）：真的调用过工具、资料已自动存档，就算做完
            toolCount >= 3 || (toolCount > 0 && !intentOnly) -> { finished = true; reason = "" }
            intentOnly -> { finished = false; reason = "只说了打算，没有真正动手" }
            else -> { finished = false; reason = "没有给出【本步结论】和【状态】" }
        }

        var conclusion = outcome.conclusion.ifBlank {
            if (intentOnly || text.isBlank()) "（AI 没有写本步结论）" else text.takeLast(500).trim()
        }
        // 结论里提到、但目录里没有的其它文件：如实标注
        if (verify) {
            val known = expected.map { it.substringAfterLast('/').lowercase() }.toSet()
            val missing = withContext(Dispatchers.IO) {
                try {
                    DeepMemory.missingMentioned(folder, conclusion)
                        .filter { n -> n.substringAfterLast('/').lowercase() !in known && FileManager.find(n) == null }
                } catch (_: Exception) { emptyList() }
            }
            if (missing.isNotEmpty()) conclusion += "\n（⚠ 提到但不存在：${missing.joinToString("、")}）"
        }
        val receiptText = receipts.joinToString("\n") { r ->
            (if (r.ok) "✓ " else "✗ ") + r.path + "（" + r.note + (if (r.by.isNotEmpty()) "，" + r.by else "") + "）"
        }
        val fullConclusion = conclusion + if (receiptText.isNotEmpty()) "\n\n【系统核验 · 以磁盘上的文件为准】\n$receiptText" else ""
        if (receipts.isNotEmpty()) {
            event(id, if (bad.isEmpty()) "system" else "error", if (bad.isEmpty()) "✅ 交付门通过：${receipts.size} 个文件已核验" else "⛔ 交付门未通过", receiptText,
                note = if (bad.isEmpty()) "" else "这一步会重做")
        }

        val cur = get(id) ?: return
        val nowStep = PlanOps.find(cur.plan, step.id)
        val attempts = prevAttempts + if (finished) 0 else 1
        val newStatus = when {
            nowStep == null -> null // 被删了
            nowStep.status == DeepStep.SKIP -> nowStep.status
            // AI 自己用 plan 标了完成，但交付门没过：不算
            nowStep.status == DeepStep.DONE && (finished || receipts.isEmpty()) -> nowStep.status
            !nowStep.isLeaf -> DeepStep.TODO // 本轮被细化成子步骤：交给子步骤
            finished -> DeepStep.DONE
            attempts >= 3 -> DeepStep.FAILED
            else -> DeepStep.TODO
        }
        val resultText = (if (receiptText.isNotEmpty()) "【核验】" + receiptText.replace('\n', ' ') + "\n" else "") + conclusion
        val updated = mutate(id) { s ->
            s.copy(
                plan = if (newStatus == null) s.plan else PlanOps.update(s.plan, step.id) {
                    it.copy(status = newStatus, result = resultText.take(500).ifBlank { it.result }, lastIssue = if (finished) "" else reason)
                },
                currentStepId = null,
                attempts = s.attempts + (step.id to attempts),
                activity = if (finished) "完成 $label ${step.title}" else "未完成：${reason.take(40)}",
            )
        } ?: return
        event(id, "result", "${if (finished) "✓" else "…"} $label ${step.title}", fullConclusion.ifBlank { text.take(1500) },
            status = if (finished) "done" else "error", note = if (!finished) reason else "用时 ${(System.currentTimeMillis() - started) / 1000} 秒")

        // 写文件：本步全文（按步骤 id 命名，重做时追加）+ 日志
        withContext(Dispatchers.IO) {
            try {
                val f = stepFile(folder, step)
                val section = "## 第 ${before.cycles} 轮 · ${timeFmt.format(Date())} · ${if (finished) "完成" else "未完成：$reason"}\n\n" +
                    (if (notes.isNotEmpty()) "处理的用户消息：${notes.joinToString("；") { it.text.take(80) }}\n\n" else "") +
                    text.trim().ifBlank { "（AI 没有输出文字）" } +
                    (if (receiptText.isNotEmpty()) "\n\n### 系统核验（以磁盘上的文件为准）\n\n$receiptText" else "") +
                    "\n\n### 工具记录\n\n" + listener.toolLog() + "\n"
                if (f.exists()) f.appendText("\n---\n\n$section")
                else f.writeText("# [${step.id}] ${step.title}\n\n" + (if (step.detail.isNotBlank()) "> ${step.detail}\n\n" else "") + section)
                register(updated, f, "步骤「${step.title.take(30)}」的完整过程", tag)
                appendFile(
                    updated, "日志.md",
                    "\n## 第 ${before.cycles} 轮 · ${timeFmt.format(Date())} · $label ${step.title}\n" +
                        (if (notes.isNotEmpty()) "- 处理了用户消息：${notes.joinToString("；") { it.text.take(60) }}\n" else "") +
                        (if (listener.toolNames().isNotEmpty()) "- 用了工具：${listener.toolNames().joinToString("、")}\n" else "") +
                        "- ${if (finished) "结论" else "未完成（$reason）"}：${conclusion.replace('\n', ' ').take(600)}\n" +
                        (if (receiptText.isNotEmpty()) "- 核验：${receiptText.replace('\n', '；')}\n" else "") +
                        "- 过程：${DeepMemory.DIR_STEPS}/${f.name}\n",
                )
                if (finished) {
                    // 这一步存档的资料标成「已用过」：要点已进知识库，之后的索引不再逐个列出
                    if (DiaSettings.deepAutoMarkUsed.value) DeepMemory.markStepArchivesUsed(folder, tag)
                    // 改写类步骤做完：原文件的「待改写」标记改掉
                    if (step.source.isNotBlank()) {
                        val src = File(folder, step.source)
                        if (src.exists()) {
                            val same = expected.any { it == step.source }
                            DeepMemory.setMark(folder, src, if (same) "" else DeepMemory.MARK_USED, if (same) "" else "已改写到 ${expected.firstOrNull().orEmpty()}")
                        }
                    }
                }
                DeepMemory.writeIndex(folder, updated.topic)
                AiFolder.touch()
            } catch (e: Exception) {
                Log.w(TAG, "write step: ${e.message}")
            }
        }
        saveEvents(id)

        // 卡住了：提醒用户可以补资料，先去做别的
        if (newStatus == DeepStep.FAILED) {
            val q = "「$label ${step.title}」连续 $attempts 次没完成（$reason）。可以在长思页「添加文件」或在下方补充提示，我会重新尝试；现在先做别的步骤。"
            event(id, "question", "卡住了：$q")
            appendFile(updated, "日志.md", "\n> 【卡住】$q\n")
            DeepThinkService.notifyQuestion(appCtx, updated.topic, q)
        }

        // 提炼要点进知识库（研究员把结果压缩成带来源的笔记）
        if (DiaSettings.deepDistill.value && text.isNotBlank() && (finished || toolCount > 0)) {
            try { distill(id, step, label, text, fullConclusion, listener.toolLog()) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
                Log.w(TAG, "distill: ${e.message}")
            }
        }

        // 每 3 轮（或计划刚做完）更新一次阶段总结
        val (d, t) = PlanOps.counts(updated.plan)
        if (updated.cycles % 3 == 0 || d == t) {
            try { updateSummary(id) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { Log.w(TAG, "summary: ${e.message}") }
        }
        // 定期导出 Word 全记录
        val every = DiaSettings.deepBackupEvery.value
        val latest = get(id)
        if (every > 0 && latest != null && latest.cycles - latest.backupCycle >= every) {
            try { exportBackup(id) } catch (e: Exception) { Log.w(TAG, "backup: ${e.message}") }
        }
    }

    /** 从本步输出里取「本步结论」和「状态」（兼容旧接口；没写【状态】时不算完成）。 */
    fun parseOutcome(text: String): Triple<String, Boolean, String> {
        val o = DeepGate.parseOutcome(DeepGate.tidy(text))
        return Triple(o.conclusion, o.state == DeepGate.State.DONE, if (o.state == DeepGate.State.UNFINISHED) o.reason else if (o.state == DeepGate.State.MISSING) "没有给出【状态】" else "")
    }

    // ───────── 交付门：核对 / 回读 / 代写落盘 ─────────

    /** 一个应产出文件的核验回执（只认磁盘上的证据）。by：空 = AI 自己写的；「系统代写」= 交付门落盘。 */
    private data class Receipt(val path: String, val ok: Boolean, val note: String, val by: String = "")

    /** 结论里「声称写好了」的产出文件（资料 / 用户资料 / 步骤 / 备份目录里的是存档或输入，不算）。 */
    private fun claimedOutputs(conclusion: String): List<String> =
        DeepMemory.claimedFiles(conclusion)
            .filter { raw -> val r = raw.removePrefix("灵犀AI/").removePrefix("./"); listOf("资料", DeepMemory.DIR_USER, DeepMemory.DIR_STEPS, DeepMemory.DIR_BACKUP).none { r.startsWith(it) } }
            .mapNotNull { DeepGate.normalizeOutput(it) }

    /** 必须在本步里真的被改过的文件：「改写 / 润色《X》」，以及改写步骤的原文件。 */
    private fun mustUpdateOf(step: DeepStep): Set<String> {
        val set = HashSet(DeepGate.updateTargets(step.title, step.detail))
        if (step.source.isNotBlank()) step.expectedOutputs.filter { it == step.source }.forEach { set.add(it) }
        return set
    }

    /** 回读文件的纯文本：Word/PPT/Excel 解压读 XML，PDF 提取文字（提不出来时只检查文件头），读不出来返回 null。 */
    private fun readBack(f: File): String? = try {
        val bytes = f.readBytes()
        when (f.extension.lowercase()) {
            "docx" -> OfficeXml.docxText(bytes)
            "pptx" -> OfficeXml.pptxText(bytes)
            "xlsx" -> OfficeXml.xlsxText(bytes)
            "pdf" -> {
                if (bytes.size < 200 || String(bytes, 0, 5, Charsets.ISO_8859_1) != "%PDF-") null
                else {
                    val t = try { FileManager.read(FileManager.attachPath(f.absolutePath), 0, 4000).text } catch (_: Exception) { "" }
                    t.ifBlank { "PDF 文件有效，大小 ${bytes.size} 字节，但无法直接提取文字" }
                }
            }
            else -> TextDecode.decode(bytes)
        }
    } catch (_: Exception) {
        null
    }

    /** 核对一个应产出的文件：存在、能打开、回读出来的内容像样；[mustUpdate] 时还要求本步改过。 */
    private fun inspect(folder: File, rel: String, cycleStart: Long, mustUpdate: Boolean): Receipt {
        val f = DeepMemory.findOutput(folder, rel, cycleStart - 2000) ?: return Receipt(rel, false, "文件不存在")
        val shown = DeepMemory.relPath(folder, f)
        if (mustUpdate && f.lastModified() < cycleStart - 2000) return Receipt(shown, false, "这一步没有改动过它")
        val text = readBack(f) ?: return Receipt(shown, false, "文件打不开（格式损坏）")
        val q = DeepGate.quality(text, f.extension)
        return if (q.ok) Receipt(shown, true, "${AiFolder.sizeLabel(f.length())}，${q.chars} 字，回读校验通过")
        else Receipt(shown, false, q.reason)
    }

    /** 「成果/」里已有文件的正文节选（给后面的步骤、代写时参考，保持前后一致）。 */
    private fun referenceOutputs(folder: File, exclude: Set<String>, maxChars: Int): String {
        val ex = exclude.map { it.substringAfterLast('/').lowercase() }.toSet()
        val sb = StringBuilder()
        for (f in DeepMemory.outputFiles(folder).take(8)) {
            if (f.name.lowercase() in ex) continue
            val left = maxChars - sb.length
            if (left < 120) break
            val t = readBack(f)?.let { DeepGate.tidy(it) }?.takeIf { it.isNotBlank() } ?: continue
            val per = (left - 40).coerceAtMost(1200)
            sb.append("### ").append(DeepMemory.relPath(folder, f)).append('\n').append(t.take(per)).append(if (t.length > per) "…\n\n" else "\n\n")
        }
        return sb.toString().trim()
    }

    /** 写一个产出文件：旧版先备份，按扩展名排版，登记。返回写好的文件。 */
    private fun writeOutput(s: DeepSession, rel: String, content: String, desc: String, step: String): File {
        val folder = File(s.folder)
        val target = File(folder, rel)
        target.parentFile?.mkdirs()
        keepOld(folder, target)
        val ext = target.extension.lowercase()
        target.writeBytes(FileManager.renderContent(content, ext, target.nameWithoutExtension))
        register(s, target, desc, step)
        AiFolder.touch()
        return target
    }

    /**
     * 代写落盘：AI 说做了但文件没写好时，让模型**只输出这个文件的完整正文**，由系统写进文件、回读校验。
     * 这样「说写了」之前，文件一定已经真实存在、内容像样。
     */
    private suspend fun materialize(s: DeepSession, step: DeepStep, rel: String, work: String, toolLog: String, problem: String, rewrite: Boolean): Receipt {
        if (!LlmGateway.isAvailable()) return Receipt(rel, false, "$problem；没有可用的模型来补写")
        val folder = File(s.folder)
        val name = rel.substringAfterLast('/')
        val ext = name.substringAfterLast('.', "md").lowercase()
        val budget = LlmGateway.promptCharBudget()
        val facts = try { DeepMemory.relevantFacts(folder, s.topic + " " + step.title + " " + step.detail, (budget * 0.12).toInt().coerceIn(300, 3000)) } catch (_: Exception) { "" }
        val prior = withContext(Dispatchers.IO) { try { referenceOutputs(folder, setOf(rel), (budget * 0.22).toInt().coerceIn(400, 6000)) } catch (_: Exception) { "" } }
        val srcFile = step.source.takeIf { it.isNotBlank() }?.let { File(folder, it) }?.takeIf { it.isFile }
            ?: DeepMemory.findOutput(folder, rel, Long.MAX_VALUE)
        val existing = srcFile?.let { f -> withContext(Dispatchers.IO) { readBack(f) } }?.let { DeepGate.tidy(it) }.orEmpty()
        val sys = "你是认真负责的写作者。你现在只做一件事：写出文件《$name》的完整正文。" +
            "只输出正文本身：不要解释、不要说「好的」、不要写【本步结论】或【状态】、不要用代码块包起来、不要调用工具。"
        val prompt = buildString {
            append("【长思主题】").append(s.topic).append('\n')
            append("【本步任务】").append(step.title)
            if (step.detail.isNotBlank()) append(" —— ").append(step.detail)
            append('\n')
            append("【要写的文件】").append(rel).append("（").append(DeepGate.formatHint(ext)).append("）\n")
            append("【之前的问题】").append(problem).append('\n')
            if (existing.isNotBlank()) {
                append(if (rewrite || step.source.isNotBlank()) "\n【原文】（按本步要求改写；改写后要完整，不能只写改动的部分）\n" else "\n【这个文件现有的内容】（在此基础上补全、完善）\n")
                append(existing.take((budget * 0.3).toInt().coerceIn(600, 9000))).append('\n')
            }
            if (prior.isNotBlank()) append("\n【前面几步已经产出的文件】（保持一致，在此基础上继续）\n").append(prior).append('\n')
            if (facts.isNotBlank()) append("\n【知识库要点】\n").append(facts).append('\n')
            val w = DeepGate.tidy(work).take((budget * 0.15).toInt().coerceIn(300, 4000))
            if (w.isNotBlank()) append("\n【这一步刚才的工作记录】（可能不完整，取其中有用的内容）\n").append(w).append('\n')
            if (!toolLog.startsWith("（本步没有调用工具）")) append("\n【本步工具结果摘要】\n").append(toolLog.take((budget * 0.12).toInt().coerceIn(300, 3000))).append('\n')
            append("\n现在直接输出《").append(name).append("》的完整正文。内容要具体、完整、可以直接交付（例如诗歌就写出完整的诗句，大纲就写出每一部分的具体内容），不要只写框架、打算或「待补充」。")
        }
        var last = problem
        for (attempt in 0 until 2) {
            val det = DeepGate.LoopDetector()
            val out = try {
                LlmGateway.complete(system = sys, prompt = prompt, temperature = if (attempt == 0) 0.35 else 0.6, timeoutMs = 300_000) { d, _ ->
                    if (d.isNotEmpty() && det.feed(d) && !LlmGateway.usingCloud()) LlmGateway.cancelCurrent()
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (det.tripped) det.text() else { last = "模型出错：${e.message}"; continue }
            }
            val content = DeepGate.cleanContent(out.ifBlank { det.text() })
            val q = DeepGate.quality(content, ext)
            if (!q.ok) { last = "补写的内容不合格：${q.reason}"; continue }
            val f = withContext(Dispatchers.IO) {
                writeOutput(s, rel, content, "「${step.title.take(20)}」的产出（AI 没写成，系统按它的内容写出并落盘）", "${step.id} ${step.title.take(20)}")
            }
            val r = withContext(Dispatchers.IO) { inspect(folder, DeepMemory.relPath(folder, f), 0, false) }
            if (r.ok) {
                event(id = s.id, kind = "system", title = "🧱 已落盘：${r.path}", detail = content.take(1500), note = r.note)
                return r.copy(by = "系统代写")
            }
            last = r.note
        }
        return Receipt(rel, false, "$problem；系统补写也没成功（$last）")
    }

    /**
     * 本步内的「完成前核对」（交给 [DiaAgent]）：AI 想收尾时先看文件是否真的写好、是不是只说了打算。
     * 返回 null = 可以收尾；否则返回催它动手的话，Agent 会接着让它调用工具。
     */
    private suspend fun finishCheck(id: String, step: DeepStep, started: Long, answer: String): String? {
        val s = get(id) ?: return null
        if (!DiaSettings.deepVerify.value) return null
        val folder = File(s.folder)
        val t = DeepGate.tidy(answer)
        val o = DeepGate.parseOutcome(t)
        if (o.state == DeepGate.State.UNFINISHED) return null // 明说没完成：交给交付门处理
        val expected = (step.expectedOutputs + claimedOutputs(o.conclusion)).distinctBy { it.substringAfterLast('/').lowercase() }
        val must = mustUpdateOf(step)
        val bad = withContext(Dispatchers.IO) { expected.map { inspect(folder, it, started, it in must) }.filter { !it.ok } }
        if (bad.isNotEmpty()) {
            val first = bad.first().path
            val ext = first.substringAfterLast('.', "txt")
            return "本步要求的文件还没有真正写好：" + bad.joinToString("；") { "${it.path}（${it.note}）" } +
                "。现在就调用工具把完整正文写进去（${DeepGate.formatHint(ext)}），例如 <tool>{\"name\":\"ai_files\",\"args\":{\"action\":\"write\",\"path\":\"$first\",\"content\":\"…完整正文…\"}}</tool>" +
                "（content 里写真正的内容，不要照抄这句）。工具结果显示「已写入」之后，再输出【本步结论】和【状态】。"
        }
        if (o.state == DeepGate.State.MISSING && DeepGate.isIntentOnly(t)) {
            return "你只说了打算，还没有动手。不要复述计划，现在直接调用工具去做；做完后输出【本步结论】和【状态】。"
        }
        if (o.state == DeepGate.State.MISSING && DeepGate.norm(t).length < 30) {
            return "请给出【本步结论】（2~6 行）和【状态】完成 / 未完成：原因。"
        }
        return null
    }

    /** 当前步骤必须产出的文件（相对路径）。 */
    fun currentOutputs(id: String): List<String> {
        val s = get(id) ?: return emptyList()
        return s.currentStepId?.let { PlanOps.find(s.plan, it) }?.expectedOutputs.orEmpty()
    }

    /** 给工具钩子用：当前步骤要产出什么（催 AI 停止重复搜索、去写文件）。 */
    fun outputsHint(id: String): String {
        val s = get(id) ?: return ""
        val st = s.currentStepId?.let { PlanOps.find(s.plan, it) } ?: return ""
        val outs = st.expectedOutputs
        return if (outs.isEmpty()) "现在就根据已有资料给出【本步结论】，需要的话把结论写进文件。"
        else "本步要产出：${outs.joinToString("、")}。现在就用 ai_files write 把完整正文写进去。"
    }

    // ───────── 资料标记 ─────────

    /**
     * 给文件打标记（用户在「成果」页长按菜单，或 AI 用 mark_file）：
     * used 已用过（之后索引里不再列出）/ ignore 忽略 / key 重点参考 / rewrite 优先改写（在计划里插一步「改写《X》」，下一轮就做）/ "" 清除。
     */
    fun markFile(id: String, file: File, mark: String, note: String = "", byUser: Boolean = true): String {
        val s = get(id) ?: return "长思不存在"
        val folder = File(s.folder)
        val e = DeepMemory.setMark(folder, file, mark, note)
        try { DeepMemory.writeIndex(folder, s.topic) } catch (_: Exception) { }
        AiFolder.touch()
        val label = DeepMemory.MARK_LABELS[mark] ?: "无标记"
        val who = if (byUser) "你" else "AI"
        if (mark == DeepMemory.MARK_REWRITE) {
            val out = if (e.path.startsWith(DeepMemory.DIR_OUT + "/")) e.path else DeepMemory.DIR_OUT + "/" + file.name
            val detail = note.ifBlank { "按要求改写、完善" } + "；原文 ${e.path}，产出《$out》"
            mutate(id) { cur ->
                val existing = PlanOps.flatten(cur.plan).firstOrNull { it.step.source == e.path && it.step.status == DeepStep.TODO }
                if (existing != null) {
                    cur.copy(plan = PlanOps.update(cur.plan, existing.step.id) { it.copy(detail = detail) })
                } else {
                    val st = DeepStep("s${cur.nextId}", "改写《${file.name}》", detail, by = if (byUser) "user" else "ai", outputs = listOf(out), source = e.path)
                    cur.copy(plan = PlanOps.insertBeforeNext(cur.plan, st), nextId = cur.nextId + 1, status = if (cur.status == "done") "paused" else cur.status)
                }
            }
            event(id, "plan", "$who 标记「${file.name}」优先改写：已排到下一步", note)
            return "已把「${e.path}」标为「待改写」，并在计划里插入「改写《${file.name}》」，下一轮就做（产出 $out）。"
        }
        event(id, "system", "$who 把「${e.path}」标为「$label」", note)
        return "已把「${e.path}」标为「$label」。"
    }

    /** mark_file 工具。 */
    fun markTool(sessionId: String?, args: JSONObject): ToolOutcome {
        if (sessionId == null || get(sessionId) == null) return ToolOutcome("mark_file 只能在自主长思里使用。", ok = false)
        val folder = folderOf(sessionId) ?: return ToolOutcome("长思目录不存在", ok = false)
        val path = listOf("path", "file", "name", "id").map { args.optString(it).trim() }.firstOrNull { it.isNotBlank() }.orEmpty()
        if (path.isBlank()) return ToolOutcome("缺少文件 path", ok = false)
        val mark = DeepMemory.normalizeMark(args.optString("mark").ifBlank { args.optString("status") })
            ?: return ToolOutcome("mark 只能是 used（已用过）/ ignore（忽略）/ key（重点）/ rewrite（待改写）/ clear（清除）", ok = false)
        val f = DeepMemory.findFile(folder, path)
            ?: FileManager.find(path)?.let { ref -> android.net.Uri.parse(ref.uri).path?.let { File(it) } }?.takeIf { it.isFile }
            ?: return ToolOutcome("找不到文件「$path」。本长思目录里的文件：\n" + DeepMemory.indexForPrompt(folder, 1500), ok = false)
        return ToolOutcome(markFile(sessionId, f, mark, args.optString("note").ifBlank { args.optString("reason") }, byUser = false))
    }

    // ───────── 提炼 / 规划 / 复盘 / 总结 ─────────

    /** 把本步的要点（带来源）压缩进知识库，之后每一轮按相关度带上。 */
    private suspend fun distill(id: String, step: DeepStep, label: String, text: String, conclusion: String, toolLog: String) {
        val s = get(id) ?: return
        activity(id, "整理本步要点进知识库…")
        val budget = LlmGateway.promptCharBudget()
        val body = text.take((budget * 0.45).toInt().coerceIn(1200, 9000))
        val tools = toolLog.take((budget * 0.25).toInt().coerceIn(600, 5000))
        val out = LlmGateway.complete(
            system = "你是严谨的研究助理，负责把一步工作的产出压缩成可复用的笔记。只输出列表或「无」。",
            prompt = "【长思主题】${s.topic}\n【本步】$label ${step.title}\n【本步结论】\n$conclusion\n\n【本步全文】\n$body\n\n【工具记录（含存档路径）】\n$tools\n\n" +
                "请提炼 3~10 条之后还用得上的要点：具体的事实、数据、结论、做出的决定、写好的文件。\n" +
                "每行「- 要点（来源：网址 / 文件路径）」，没有来源就写（来源：推理）。不要写空话，不要重复。没有值得记的只输出「无」。",
            temperature = 0.2,
            timeoutMs = 120_000,
        ).trim()
        if (out.isBlank() || (out.startsWith("无") && out.length < 6)) return
        val facts = out.lines().map { it.trim() }.filter { it.startsWith("-") || it.startsWith("•") || it.startsWith("*") || Regex("^\\d+[.、]").containsMatchIn(it) }
            .map { it.replace(Regex("^\\d+[.、]\\s*"), "") }
        if (facts.isEmpty()) return
        val n = withContext(Dispatchers.IO) { DeepMemory.addFacts(File(s.folder), "${step.id} ${step.title.take(20)}", facts) }
        if (n > 0) event(id, "system", "🧩 知识库 +$n 条", facts.take(10).joinToString("\n"))
    }

    private suspend fun makePlan(id: String) {
        val s = mutate(id) { it.copy(status = "planning", activity = "正在拆解主题、制定计划…") } ?: return
        event(id, "plan", "正在拆解主题、制定计划…")
        DeepThinkService.refresh(appCtx)
        var bg = ""
        if (s.web != "off" && DiaSettings.stepPreSearch.value) {
            activity(id, "先联网了解一下这个主题…")
            bg = withContext(Dispatchers.IO) {
                try {
                    val r = WebSearch.search(s.topic, 5)
                    val txt = r.hits.mapIndexed { i, h -> "[${i + 1}] ${h.title}\n${h.url}\n${h.snippet}" }.joinToString("\n\n")
                    // 预检索结果同样存档，执行时不用再搜一遍
                    if (txt.isNotBlank()) try { DeepMemory.archiveSearch(File(s.folder), s.topic, txt, 0, "制定计划") } catch (_: Exception) { }
                    r.hits.mapIndexed { i, h -> "[${i + 1}] ${h.title}：${h.snippet.take(200)}" }.joinToString("\n")
                } catch (_: Exception) { "" }
            }
        }
        val notes = s.notes.filter { !it.handled }.joinToString("\n") { "- " + it.text }
        val userFiles = try { DeepMemory.userFiles(File(s.folder)) } catch (_: Exception) { emptyList() }
        val out = LlmGateway.complete(
            system = "你是顶尖的研究与项目规划师，擅长把一个大主题拆成清晰、可执行、循序渐进的步骤。只输出计划大纲。",
            prompt = buildString {
                append("【主题】").append(s.topic).append('\n')
                append("【最终成果格式】").append(formatsLabel(s)).append('\n')
                if (notes.isNotBlank()) append("【用户补充】\n").append(notes).append('\n')
                if (userFiles.isNotEmpty()) append("【用户提供的文件】\n").append(userFiles.joinToString("\n") { "- " + it.path }).append('\n')
                if (bg.isNotBlank()) append("【预检索资料】\n").append(bg).append('\n')
                append("\n请为这个主题制定一份由 AI 自己逐步执行的计划：\n")
                append("- 4~8 个一级步骤，复杂的步骤下面列 2~4 个子步骤（用 1. / 1.1 这样的编号，子步骤缩进两个空格）\n")
                append("- 每步一行：「编号 标题：做什么，产出《文件名.扩展名》」。凡是要产出内容的步骤都写明产出文件（例如 产出《诗歌初稿.txt》），文件名不要重复；系统会检查这些文件是否真的写好\n")
                append("- 后面的步骤要用前面的产出时，写成「根据《前一步的文件名》…」\n")
                append("- 步骤要具体、可直接动手（查资料、整理、计算、写作、验证……），按先后顺序排列\n")
                if (userFiles.isNotEmpty()) append("- 第一步先阅读、整理用户提供的文件\n")
                append("- 最后一步汇总成果：按「").append(formatsLabel(s)).append("」写成完整的文件放进 成果/\n")
                append("只输出计划。")
            },
            temperature = 0.35,
            timeoutMs = 180_000,
        )
        var items = PlanOps.parseOutline(out)
        if (items.isEmpty()) {
            items = listOf(
                Triple(0, "弄清主题与目标", "界定范围、关键问题、成功标准"),
                Triple(0, "收集资料与事实", "检索、阅读、摘录要点"),
                Triple(0, "分析与思考", "比较、推理、得出结论"),
                Triple(0, "产出成果", "按 ${formatsLabel(s)} 写成完整的文件放进 成果/"),
            )
        }
        val cur = get(id) ?: return
        val (plan, next) = PlanOps.build(items, cur.nextId)
        val review = cur.reviewFirst
        mutate(id) { it.copy(plan = plan, nextId = next, status = if (review) "review" else "running", activity = if (review) "计划已生成，等你确认" else "计划已生成") }
        event(id, "plan", "计划已生成：${plan.size} 个一级步骤，共 ${PlanOps.counts(plan).second} 个具体步骤", PlanOps.render(plan, null, 0))
        if (review) DeepThinkService.notifyQuestion(appCtx, cur.topic, "计划已生成，请确认或修改后点「开始执行」")
    }

    /** 计划做完了：复盘并提出新步骤。返回新增的步骤数。 */
    private suspend fun reflect(id: String): Int {
        val s = mutate(id) { it.copy(activity = "计划已做完，正在复盘、寻找新的方向…") } ?: return 0
        event(id, "plan", "计划已做完，正在复盘、寻找值得继续深挖的方向…")
        val doneList = PlanOps.flatten(s.plan).filter { it.step.isLeaf && it.step.status == DeepStep.DONE }
            .joinToString("\n") { "- ${it.label} ${it.step.title}：${it.step.result.take(160)}" }
        val failedList = PlanOps.failed(s.plan).joinToString("\n") { "- ${it.label} ${it.step.title}：${it.step.result.take(120)}" }
        val notes = s.notes.filter { !it.handled }.joinToString("\n") { "- " + it.text }
        val folder = File(s.folder)
        val outFiles = try { DeepMemory.indexForPrompt(folder, 1200) } catch (_: Exception) { "" }
        val strong = s.emptyReflections > 0 || DiaSettings.deepEndless.value
        val out = LlmGateway.complete(
            system = "你是一个永不满足的研究者，善于复盘、发现漏洞、提出更有价值的下一步。只输出编号列表或「无」。",
            prompt = buildString {
                append("【长思主题】").append(s.topic).append('\n')
                append("【成果格式】").append(formatsLabel(s)).append('\n')
                append("【阶段总结】\n").append(s.summary.ifBlank { "（无）" }).append('\n')
                append("【已完成的步骤】\n").append(doneList.take(5000)).append('\n')
                if (failedList.isNotBlank()) append("【没做成的步骤】（可以换个思路重新安排）\n").append(failedList.take(1500)).append('\n')
                if (outFiles.isNotBlank()) append("【现有文件】\n").append(outFiles).append('\n')
                if (notes.isNotBlank()) append("【用户新消息】\n").append(notes).append('\n')
                append("\n计划里的步骤都做完了。请复盘：哪些结论还不够扎实（需要交叉验证）、哪里有遗漏、有什么更深一层或相关的问题值得研究、")
                append("成果文件还能怎样做得更好（更完整的报告、图表数据、对比表、可执行清单、跟进最新变化…）。\n")
                append("提出接下来最有价值的 2~5 个新步骤（「1. 标题：做什么，产出《文件名.扩展名》」），不要重复已完成的。")
                if (strong) append("用户希望你持续思考、不要停止，请务必提出新的方向。") else append("如果主题确实已经穷尽，只输出「无」。")
            },
            temperature = 0.6,
            timeoutMs = 180_000,
        )
        val items = if (out.trim().startsWith("无") && out.trim().length < 6) emptyList() else PlanOps.parseOutline(out).map { Triple(0, it.second, it.third) }
        if (items.isEmpty()) {
            mutate(id) { it.copy(emptyReflections = it.emptyReflections + 1) }
            event(id, "plan", "复盘：暂时没有新的方向")
            return 0
        }
        val round = (PlanOps.flatten(s.plan).count { it.depth == 0 && it.step.title.startsWith("深挖") } + 1)
        mutate(id) { cur ->
            val (kids, next) = PlanOps.build(items, cur.nextId + 1)
            val parent = DeepStep("s${cur.nextId}", "深挖 · 第 $round 轮", "复盘后自己提出的新方向", children = kids)
            cur.copy(plan = cur.plan + parent, nextId = next, emptyReflections = 0)
        }
        event(id, "plan", "复盘后给自己新增了 ${items.size} 个步骤", items.joinToString("\n") { "· " + it.second })
        return items.size
    }

    private suspend fun updateSummary(id: String) {
        val s = get(id) ?: return
        val done = PlanOps.flatten(s.plan).filter { it.step.status == DeepStep.DONE && it.step.result.isNotBlank() }
        if (done.isEmpty()) return
        activity(id, "更新阶段总结…")
        val out = LlmGateway.complete(
            system = "你善于提炼要点，写简洁准确的阶段总结。",
            prompt = "【长思主题】${s.topic}\n【之前的阶段总结】\n${s.summary.ifBlank { "（无）" }}\n\n【各步骤结论】\n" +
                done.joinToString("\n") { "- ${it.label} ${it.step.title}：${it.step.result.take(300)}" }.take(7000) +
                "\n\n请更新阶段总结（不超过 500 字，要点式）：已经弄清了什么、产出了哪些文件（写路径）、还缺什么 / 下一步重点。",
            temperature = 0.3,
            timeoutMs = 120_000,
        ).trim()
        if (out.isBlank()) return
        val u = mutate(id) { it.copy(summary = out) } ?: return
        withContext(Dispatchers.IO) {
            try {
                val f = File(u.folder, "总结.md")
                f.writeText("# 阶段总结：${u.topic}\n\n更新于 ${timeFmt.format(Date())}（第 ${u.cycles} 轮）\n\n$out\n")
                register(u, f, "阶段总结（每 3 轮更新）")
                AiFolder.touch()
            } catch (_: Exception) { }
        }
        event(id, "system", "📝 阶段总结已更新", out)
    }

    // ───────── 成果与备份 ─────────

    private fun lockOf(id: String): Mutex = exportLocks.getOrPut(id) { Mutex() }

    private fun setExporting(id: String, on: Boolean) {
        _exporting.update { if (on) it + id else it - id }
    }

    /** 覆盖成果文件前，把旧版放进「备份/历史」。 */
    private fun keepOld(folder: File, f: File) {
        if (!f.isFile) return
        try {
            val hist = File(folder, DeepMemory.DIR_BACKUP + "/历史").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.CHINA).format(Date(f.lastModified()))
            f.copyTo(File(hist, f.nameWithoutExtension + "_" + stamp + "." + f.extension), overwrite = true)
        } catch (_: Exception) { }
    }

    /** 全部过程的 Markdown（导出 Word 用；不需要模型）。 */
    private fun fullRecordMarkdown(s: DeepSession): String {
        val folder = File(s.folder)
        val (d, t) = PlanOps.counts(s.plan)
        val sb = StringBuilder()
        sb.append("# 长思全记录：").append(s.topic).append("\n\n")
        sb.append("导出于 ").append(timeFmt.format(Date())).append(" · 第 ").append(s.cycles).append(" 轮 · ").append(s.statusLabel)
            .append(" · 完成 ").append(d).append('/').append(t).append(" 步\n\n")
        sb.append("目录：灵犀AI/").append(AiFolder.rel(folder)).append("\n\n")
        sb.append("## 阶段总结\n\n").append(s.summary.ifBlank { "（暂无）" }).append("\n\n")
        sb.append("## 计划与各步结论\n\n")
        for (f in PlanOps.flatten(s.plan)) {
            val st = f.step
            sb.append("#".repeat((3 + f.depth).coerceAtMost(6))).append(' ').append(f.label).append(' ').append(st.title)
                .append("（").append(PlanOps.statusLabel(st.status)).append("）\n\n")
            if (st.detail.isNotBlank()) sb.append(st.detail).append("\n\n")
            if (st.result.isNotBlank()) sb.append(st.result).append("\n\n")
        }
        val facts = try { DeepMemory.allFactsMarkdown(folder, 80_000) } catch (_: Exception) { "" }
        if (facts.isNotBlank()) sb.append("## 知识库\n\n").append(facts).append('\n')
        val userNotes = s.notes.takeLast(50)
        if (userNotes.isNotEmpty()) {
            sb.append("## 你的消息\n\n")
            for (n in userNotes) sb.append("- ").append(timeFmt.format(Date(n.time))).append("：").append(n.text.replace('\n', ' ')).append('\n')
            sb.append('\n')
        }
        sb.append("## 文件索引\n\n").append(try { DeepMemory.indexForPrompt(folder, 20_000) } catch (_: Exception) { "" }).append('\n')
        return sb.toString()
    }

    /** 导出「备份/长思全记录.md / .docx」（可读性好、手机上任何 Office 都能打开）。 */
    private suspend fun exportBackup(id: String, force: Boolean = false) {
        val s0 = get(id) ?: return
        if (!force && s0.cycles <= s0.backupCycle) return
        lockOf(id).withLock {
            setExporting(id, true)
            try {
                val s = get(id) ?: return
                withContext(Dispatchers.IO) {
                    val folder = File(s.folder)
                    if (get(id) == null || !folder.isDirectory) return@withContext
                    val dir = File(folder, DeepMemory.DIR_BACKUP).apply { mkdirs() }
                    val md = fullRecordMarkdown(s)
                    val mdFile = File(dir, "长思全记录.md")
                    mdFile.writeText(md)
                    register(s, mdFile, "全部过程（Markdown 版）")
                    try {
                        val docx = File(dir, "长思全记录.docx")
                        docx.writeBytes(FileManager.renderContent(md, "docx", "长思全记录"))
                        register(s, docx, "全部过程（Word 版，定期自动导出）")
                    } catch (e: Exception) {
                        Log.w(TAG, "backup docx: ${e.message}")
                    }
                    AiFolder.touch()
                }
                mutate(id) { it.copy(backupCycle = it.cycles) }
                event(id, "system", "💾 已导出 Word 全记录", "备份/长思全记录.docx（第 ${s.cycles} 轮）")
            } catch (e: Exception) {
                Log.w(TAG, "exportBackup: ${e.message}")
                event(id, "error", "导出备份失败：${e.message}")
            } finally {
                setExporting(id, false)
            }
        }
    }

    /**
     * 按设定的格式生成 / 更新成果：总结报告（Markdown → Word / PDF），汇报 PPT，数据表 Excel。
     * 文件名固定（成果/总结报告.docx …），每次更新前把旧版放进「备份/历史」。
     */
    private suspend fun generateDeliverables(id: String) {
        val s0 = get(id) ?: return
        if (!LlmGateway.isAvailable()) return
        lockOf(id).withLock {
            setExporting(id, true)
            try {
                val s = get(id) ?: return
                activity(id, "正在整理成果：${formatsLabel(s)}…")
                event(id, "plan", "📦 正在生成 / 更新成果（${formatsLabel(s)}）…")
                val folder = File(s.folder)
                val outDir = File(folder, DeepMemory.DIR_OUT).apply { mkdirs() }
                val budget = LlmGateway.promptCharBudget()
                val done = PlanOps.flatten(s.plan).filter { it.step.result.isNotBlank() }
                val facts = try { DeepMemory.allFactsMarkdown(folder, (budget * 0.45).toInt().coerceIn(1500, 20_000)) } catch (_: Exception) { "" }
                val steps = done.joinToString("\n") { "- ${it.label} ${it.step.title}（${PlanOps.statusLabel(it.step.status)}）：${it.step.result.take(400)}" }.take((budget * 0.3).toInt().coerceIn(1200, 12_000))
                // 只认磁盘上真实存在、能打开的成果文件（回执），并把正文交给报告引用
                val verified = withContext(Dispatchers.IO) {
                    DeepMemory.outputFiles(folder).mapNotNull { f ->
                        val t = readBack(f) ?: return@mapNotNull null
                        if (!DeepGate.quality(t, f.extension).ok) null else Triple(DeepMemory.relPath(folder, f), f.length(), DeepGate.tidy(t))
                    }
                }
                val verifiedText = buildString {
                    var left = (budget * 0.25).toInt().coerceIn(800, 12_000)
                    for ((rel, size, t) in verified) {
                        append("### ").append(rel).append("（").append(AiFolder.sizeLabel(size)).append("）\n")
                        val take = t.take(left.coerceAtMost(2500).coerceAtLeast(0))
                        append(take).append(if (take.length < t.length) "…" else "").append("\n\n")
                        left -= take.length
                    }
                }.trim().ifBlank { "（还没有通过核验的成果文件）" }
                val rawReport = LlmGateway.complete(
                    system = "你是资深的报告撰写人，把研究过程的结论整理成结构清晰、有理有据、数据翔实的 Markdown 报告。只输出报告本身。",
                    prompt = "【主题】${s.topic}\n【阶段总结】\n${s.summary}\n\n【已核验的成果文件（以磁盘为准，只有这些算已产出）】\n$verifiedText\n\n" +
                        "【知识库要点（带来源）】\n$facts\n\n【各步骤结论】\n$steps\n\n" +
                        "请写一份完整的总结报告（Markdown：# 标题、摘要、主要成果（直接引用成果文件里的关键正文，例如诗歌就把全诗写进来）、主要发现（分小节，关键数据用表格）、结论与建议、仍待研究的问题、参考来源）。" +
                        "规则：只有【已核验的成果文件】里列出的文件才能写成「已完成 / 已产出」；没在里面的，只能写成「尚未完成」。",
                    temperature = 0.4,
                    timeoutMs = 300_000,
                )
                var report = DeepGate.tidy(rawReport)
                if (report.isBlank()) { event(id, "error", "生成成果失败：模型没有输出"); return }
                // 报告里提到、但并不存在的文件：如实注明
                val ghost = withContext(Dispatchers.IO) { try { DeepMemory.missingMentioned(folder, report).filter { FileManager.find(it) == null } } catch (_: Exception) { emptyList() } }
                if (ghost.isNotEmpty()) report += "\n\n> 核验说明：报告中提到的 ${ghost.joinToString("、")} 目前并不存在（以磁盘上的文件为准）。\n"
                report += "\n\n## 附：成果文件核验\n\n" + (if (verified.isEmpty()) "（暂无）" else verified.joinToString("\n") { "- ✓ `${it.first}`（${AiFolder.sizeLabel(it.second)}）" }) + "\n"
                val made = ArrayList<String>()
                withContext(Dispatchers.IO) {
                    val md = File(outDir, "总结报告.md")
                    keepOld(folder, md)
                    md.writeText(report + "\n")
                    register(s, md, "总结报告（Markdown 原文）", "成果")
                    made.add("成果/总结报告.md")
                    for (ext in s.deliverables.filter { it == "docx" || it == "pdf" }) {
                        try {
                            val f = File(outDir, "总结报告.$ext")
                            keepOld(folder, f)
                            f.writeBytes(FileManager.renderContent(report, ext, s.topic.take(30)))
                            register(s, f, "总结报告（${FORMAT_LABELS[ext]}）", "成果")
                            made.add("成果/${f.name}")
                        } catch (e: Exception) {
                            Log.w(TAG, "render $ext: ${e.message}")
                        }
                    }
                }
                if ("pptx" in s.deliverables) {
                    activity(id, "正在做汇报 PPT…")
                    val slides = LlmGateway.complete(
                        system = "你是演示文稿设计师。把报告改写成 PPT 大纲。只输出大纲。",
                        prompt = "【报告】\n${report.take((budget * 0.7).toInt().coerceIn(2000, 20_000))}\n\n" +
                            "改写成 8~15 页的汇报 PPT：每页以「# 页标题」开头，下面 3~6 行「- 要点」（每条不超过 30 字，关键数字保留）。第一页是标题页，最后一页是结论与建议。",
                        temperature = 0.3,
                        timeoutMs = 240_000,
                    ).trim()
                    if (slides.isNotBlank()) withContext(Dispatchers.IO) {
                        try {
                            val f = File(outDir, "汇报.pptx")
                            keepOld(folder, f)
                            f.writeBytes(FileManager.renderContent(slides, "pptx", s.topic.take(30)))
                            register(s, f, "汇报 PPT", "成果")
                            made.add("成果/汇报.pptx")
                        } catch (e: Exception) { Log.w(TAG, "pptx: ${e.message}") }
                    }
                }
                if ("xlsx" in s.deliverables) {
                    activity(id, "正在整理数据表…")
                    val tables = LlmGateway.complete(
                        system = "你是数据整理员。只输出 Markdown 表格。",
                        prompt = "【报告】\n${report.take((budget * 0.6).toInt().coerceIn(2000, 16_000))}\n\n【知识库要点】\n${facts.take(6000)}\n\n" +
                            "把其中可量化 / 可比较的信息整理成 1~4 张表格。每张表前一行写「## 表名」，然后是 Markdown 表格（第一行表头）。没有数据就输出一张「要点清单」表（序号 | 要点 | 来源）。",
                        temperature = 0.2,
                        timeoutMs = 180_000,
                    ).trim()
                    if (tables.isNotBlank()) withContext(Dispatchers.IO) {
                        try {
                            val f = File(outDir, "数据表.xlsx")
                            keepOld(folder, f)
                            f.writeBytes(FileManager.renderContent(tables, "xlsx", "数据表"))
                            register(s, f, "数据表 Excel", "成果")
                            made.add("成果/数据表.xlsx")
                        } catch (e: Exception) { Log.w(TAG, "xlsx: ${e.message}") }
                    }
                }
                AiFolder.touch()
                mutate(id) { it.copy(reportCycle = it.cycles) }
                event(id, "result", "📄 成果已更新：${made.size} 个文件", made.joinToString("\n") + "\n\n" + report.take(2500), status = "done")
                saveEvents(id)
            } finally {
                setExporting(id, false)
            }
        }
        exportBackup(id)
    }

    // ───────── 长思里的工具执行宿主 ─────────

    private class DeepListener(private val sid: String) : AgentListener {
        override val context: Context get() = appCtx
        override val wuji: Boolean get() = true
        override val deepSessionId: String get() = sid

        private val starts = ConcurrentHashMap<String, Long>()
        private val log = StringBuilder()
        private val names = LinkedHashSet<String>()
        private val calls = java.util.concurrent.atomic.AtomicInteger(0)
        @Volatile private var current: String? = null

        /** 本步调用了几次工具（交付门判断「有没有真的动手」）。 */
        fun toolCount(): Int = calls.get()

        fun toolLog(): String = synchronized(log) { log.toString().ifBlank { "（本步没有调用工具）" } }
        fun toolNames(): List<String> = synchronized(names) { names.toList() }

        override fun onText(text: String) {}
        override fun onThought(delta: String) {}

        override fun onToolStart(name: String, title: String): String =
            onToolCall(name, title, JSONObject(), "", 0, false)

        override fun onToolCall(name: String, title: String, args: JSONObject, reason: String, stepNo: Int, byUser: Boolean): String {
            val eid = event(sid, "tool", (if (stepNo > 0) "步骤 $stepNo · " else "") + title, args.toString(2).take(3000), "running", reason, name)
            calls.incrementAndGet()
            starts[eid] = System.currentTimeMillis()
            current = eid
            synchronized(names) { names.add(AgentTools.spec(name)?.title ?: name) }
            activity(sid, (if (reason.isNotBlank()) "$reason → " else "") + title)
            return eid
        }

        override fun onToolEnd(cardId: String, outcome: ToolOutcome) {
            val ms = System.currentTimeMillis() - (starts.remove(cardId) ?: System.currentTimeMillis())
            updateEvent(sid, cardId) {
                it.copy(status = if (outcome.ok) "done" else "error", detail = (it.detail + "\n\n── 结果 ──\n" + outcome.display).take(6000), durationMs = ms)
            }
            val title = eventFlows[sid]?.value?.firstOrNull { it.id == cardId }?.title.orEmpty()
            // 存档 / 生成的文件路径单独记下（结果正文截断后也不会丢）
            val paths = Regex("(?:存档|路径)[：:「]\\s*([^\\s，,。）)」]+)").findAll(outcome.forModel).map { it.groupValues[1] }.distinct().toList()
            synchronized(log) {
                log.append("- ").append(if (outcome.ok) "✓ " else "✗ ").append(title).append("（").append(ms / 1000.0).append("s）：")
                    .append(outcome.forModel.replace('\n', ' ').take(400))
                if (paths.isNotEmpty()) log.append(" 〔文件：").append(paths.joinToString("、")).append("〕")
                log.append('\n')
            }
            if (current == cardId) current = null
        }

        override fun progress(text: String) {
            val c = current ?: return
            updateEvent(sid, c) { it.copy(note = text) }
        }

        override suspend fun confirm(title: String, detail: String): Boolean {
            val s = get(sid)
            if (s == null || s.autoApprove) {
                event(sid, "confirm", "⚡ 已自动批准：$title", detail, "approved")
                return true
            }
            val d = CompletableDeferred<Boolean>()
            confirmWaits[sid] = d
            _confirm.value = DeepConfirm(sid, title, detail)
            event(sid, "confirm", "等待你批准：$title", detail, "pending")
            activity(sid, "等待你批准：$title")
            DeepThinkService.notifyQuestion(appCtx, s.topic, "需要你批准：$title")
            return try {
                d.await()
            } finally {
                confirmWaits.remove(sid)
                if (_confirm.value?.sessionId == sid) _confirm.value = null
            }
        }

        override fun moveAppToBack() {
            ChatController.emitEvent("move_to_back")
        }
    }
}
