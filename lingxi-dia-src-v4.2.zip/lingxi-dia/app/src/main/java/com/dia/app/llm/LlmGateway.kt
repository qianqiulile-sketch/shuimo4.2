package com.dia.app.llm

import android.graphics.Bitmap
import android.util.Base64
import com.dia.app.pilot.cloud.CloudLlmClient
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import java.io.ByteArrayOutputStream

/**
 * 灵犀对话使用的统一大模型入口：
 *  - 本地（LiteRT-LM / Gemma）走 [DiaEngine.generate]，流式输出；本地引擎同一时刻只能跑一个推理，所以串行
 *  - 云端（OpenAI 兼容接口）走 [CloudLlmClient]，可以并发（分布式思考的「分身」会同时提问）
 */
object LlmGateway {

    private val localMutex = Mutex()
    /** 云端并发上限，避免触发服务商限流。 */
    private val cloudPermits = Semaphore(4)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** 当前是否走云端。 */
    fun usingCloud(): Boolean = DiaPrefs.cloudEnabled.value && DiaPrefs.cloudIsConfigured()

    /** 是否有可用的大模型（本地已加载 或 云端已配置）。 */
    fun isAvailable(): Boolean = usingCloud() || DiaEngine.isReady

    /** 能否真正并行（云端可以，本地只能排队）。 */
    fun canParallel(): Boolean = usingCloud()

    /** 当前模型的显示名称。 */
    fun label(): String = if (usingCloud()) {
        "云端 · ${DiaPrefs.cloudModel.value}"
    } else {
        val path = DiaEngine.currentModelPath
        if (path == null) "未加载模型" else "本地 · ${java.io.File(path).nameWithoutExtension}"
    }

    /**
     * 拼接提示词时可用的字符预算（粗略按 1 字 ≈ 1 token 估算，
     * 预留约 1100 token 给模型输出）。
     */
    fun promptCharBudget(): Int = if (usingCloud()) {
        if (DiaSettings.wujiMode.value) 48_000 else 28_000
    } else {
        (DiaSettings.contextTokens.value - 1100).coerceAtLeast(1500)
    }

    suspend fun complete(
        system: String,
        prompt: String,
        images: List<Bitmap> = emptyList(),
        audio: List<AudioClip> = emptyList(),
        temperature: Double = 0.6,
        thinking: Boolean = false,
        timeoutMs: Long = 240_000L,
        maxTokens: Int = 8192,
        onDelta: (delta: String, thought: String?) -> Unit = { _, _ -> },
    ): String = if (usingCloud()) {
        cloudPermits.withPermit {
            val client = CloudLlmClient(
                baseUrl = DiaPrefs.cloudBaseUrl.value,
                apiKey = DiaPrefs.cloudApiKey.value,
                model = DiaPrefs.cloudModel.value,
                readTimeoutMs = timeoutMs.coerceIn(30_000L, 600_000L).toInt(),
            )
            val imageB64 = images.firstOrNull()?.let { encodePng(it) }
            // 用 async + await：取消时立即返回，不必等 HTTP 超时。
            val deferred = ioScope.async {
                client.chat(
                    systemPrompt = system,
                    userPrompt = prompt,
                    screenshotPngBase64 = imageB64,
                    history = emptyList(),
                    temperature = temperature,
                    maxTokens = maxTokens,
                )
            }
            val res = deferred.await()
            val content = res.content
            if (content.isNullOrBlank()) {
                throw IllegalStateException(res.error ?: "云端返回为空")
            }
            if (!res.reasoning.isNullOrBlank()) onDelta("", res.reasoning)
            onDelta(content, null)
            content
        }
    } else {
        localMutex.withLock {
            if (!DiaEngine.isReady) throw IllegalStateException("本地模型未加载，请先在顶部选择模型")
            DiaEngine.generate(
                systemInstruction = system,
                text = prompt,
                images = images,
                audioClips = audio,
                temperature = temperature,
                thinking = thinking,
                timeoutMs = timeoutMs,
                onDelta = onDelta,
            )
        }
    }

    /**
     * 强制用本机模型推理（例如让 Gemma 直接听原始音频）。即使当前对话走云端，也会用本机已加载的模型。
     * 本机模型没加载时抛出异常。
     */
    suspend fun completeLocal(
        system: String,
        prompt: String,
        audio: List<AudioClip> = emptyList(),
        images: List<Bitmap> = emptyList(),
        temperature: Double = 0.3,
        timeoutMs: Long = 240_000L,
    ): String = localMutex.withLock {
        if (!DiaEngine.isReady) throw IllegalStateException("本机模型未加载")
        DiaEngine.generate(
            systemInstruction = system,
            text = prompt,
            images = images,
            audioClips = audio,
            temperature = temperature,
            timeoutMs = timeoutMs,
        )
    }

    /**
     * 一次发出多个独立请求：云端并发，本地依次执行。返回顺序与输入一致；
     * 某个请求失败时对应位置返回「（失败：原因）」，不影响其它请求。
     */
    suspend fun completeAll(requests: List<Pair<String, String>>, temperature: Double = 0.5, thinking: Boolean = false): List<String> =
        coroutineScope {
            requests.map { (sys, p) ->
                async {
                    try {
                        complete(system = sys, prompt = p, temperature = temperature, thinking = thinking)
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        "（失败：${e.message ?: e.javaClass.simpleName}）"
                    }
                }
            }.awaitAll()
        }

    /** 立即中止正在进行的本地推理。 */
    fun cancelCurrent() {
        DiaEngine.cancelGenerate()
    }

    private fun encodePng(bitmap: Bitmap): String? = try {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
        Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    } catch (_: Throwable) {
        null
    }
}
