package com.dia.app.translate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.dia.app.DiaAccessibilityService
import com.dia.app.MainActivity
import com.dia.app.R
import com.dia.app.llm.BackendRouter
import com.dia.app.llm.DiaEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Foreground service that shows a region-selection overlay on top of any app.
 * The user draws a rectangle, we screenshot that region via the accessibility
 * service, send it to Gemma for translation, and show the result.
 *
 * Flow:
 *   1. User triggers via Guide bubble / quick settings / notification action
 *   2. Semi-transparent overlay appears — "Draw a rectangle around text to translate"
 *   3. User drags finger to select a region
 *   4. We call AccessibilityService.takeScreenshot() (API 30+)
 *   5. Crop the bitmap to the selected rect
 *   6. Send to DiaEngine with translate prompt
 *   7. Show translation in a floating result bubble
 *   8. User taps to dismiss
 */
class ScreenTranslateService : Service() {

    /**
     * Each mode picks a different system + user prompt for the same
     * pipeline (region select → screenshot → vision query → result card).
     * The bubble menu surfaces these to the user as separate menu items.
     */
    enum class Mode(
        val title: String,
        val instruction: String,
        val systemPrompt: String,
        val userPrompt: String,
    ) {
        TRANSLATE(
            title = "翻译",
            instruction = "框选要翻译的区域（点一下 = 全屏）",
            systemPrompt = """你是屏幕文字翻译器，会收到一张屏幕截图。
规则：
1. 找出图中所有文字。
2. 把不是{TARGET}的文字翻译成{TARGET}，格式：原文 → 译文（较长的段落可以只给译文）。
3. 如果全部文字已经是{TARGET}，就用 1-2 句话概括它说了什么。
4. 不要描述界面布局、颜色或图标，不要说“图片显示”。
5. 只输出译文或概括。""",
            userPrompt = "把这张截图里的文字翻译成{TARGET}。",
        ),
        SUMMARIZE(
            title = "总结",
            instruction = "框选要总结的区域（点一下 = 全屏）",
            systemPrompt = """你负责总结屏幕截图的内容：读出文字、识别图表/列表/聊天等结构，提炼用户最关心的要点。
规则：用{TARGET}输出 2-5 句话或 3-5 条要点；不要说“截图显示”；文章给主旨，图表说趋势，聊天说清人物和话题。""",
            userPrompt = "用{TARGET}总结这张截图的内容。",
        ),
        ANSWER(
            title = "答题",
            instruction = "框选题目（点一下 = 全屏）",
            systemPrompt = """你负责回答截图中的题目（选择、填空、简答等）。
规则：
1. 仔细读题和选项。
2. 选择题先给出选项（如“B. 巴黎”），再用一句话说明理由。
3. 简答题 1-3 句话，直接明确。
4. 不要描述截图本身，只输出答案。使用{TARGET}。""",
            userPrompt = "回答这张截图中的题目。",
        ),
        SOLVE(
            title = "解题",
            instruction = "框选要解的题（点一下 = 全屏）",
            systemPrompt = """你负责解截图中的题目：数学、物理、化学、代码、逻辑题等。
规则：
1. 准确识别题目。
2. 给出关键步骤（3-6 行），用纯文本，不要用 LaTeX。
3. 最后单独一行以“答案：”开头写出最终结果。
4. 代码题：用 1-2 句话说明问题并给出修正后的代码。
5. 不要寒暄，只输出解答。使用{TARGET}。""",
            userPrompt = "解这道题，简要写出步骤，最后给出答案。",
        ),
        /** 语音 / 自定义提示词 + 截图 */
        ASK(
            title = "提问",
            instruction = "框选区域，然后说出或输入你的问题",
            systemPrompt = """你是视觉助手。用户给你一张屏幕截图并提出问题或指令，请只根据图中可见内容完成。
规则：直接回答，不寒暄，不说“图片显示”；无法从图中判断时简短说明。使用{TARGET}。""",
            userPrompt = "看这张截图，回答我的问题。",
        ),
        /** Two-step ASK: pick the region first, then ask the question. */
        ASK_TWO_STEP(
            title = "提问",
            instruction = "框选你想问的区域",
            systemPrompt = """你是视觉助手。用户给你一张屏幕截图并提出问题，请只根据图中可见内容回答。
规则：直接回答，1-3 句话，不寒暄；无法判断时简短说明。使用{TARGET}。""",
            userPrompt = "看这张截图，回答我的问题。",
        ),
    }

    private fun fill(s: String): String =
        s.replace("{TARGET}", com.dia.app.prefs.DiaSettings.translateTarget.value.ifBlank { "简体中文" })

    companion object {
        private const val TAG = "ScreenTranslate"
        private const val CHANNEL_ID = "dia_translate_channel"
        private const val NOTIFICATION_ID = 4713
        private const val EXTRA_MODE = "extra_mode"
        private const val EXTRA_CUSTOM_PROMPT = "extra_custom_prompt"

        @Volatile
        private var running = false
        fun isRunning() = running

        // ── Two-step ASK: capture region first, prompt for question after ──
        @Volatile private var pendingBitmap: Bitmap? = null
        @Volatile private var pendingRegionCallback: (() -> Unit)? = null
        @Volatile private var instance: ScreenTranslateService? = null

        @JvmOverloads
        fun start(context: Context, mode: Mode = Mode.TRANSLATE, customPrompt: String? = null) {
            val intent = Intent(context, ScreenTranslateService::class.java)
                .putExtra(EXTRA_MODE, mode.name)
            if (!customPrompt.isNullOrBlank()) {
                intent.putExtra(EXTRA_CUSTOM_PROMPT, customPrompt)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else context.startService(intent)
            } catch (e: Exception) {
                Log.w(TAG, "start failed: ${e.message}")
            }
        }

        /**
         * Two-step ASK: launch the region selector. Once the user picks
         * a region, [onRegionPicked] is called and the captured bitmap
         * is held until [submitTwoStepAsk] is called with a question.
         */
        fun startTwoStepAsk(context: Context, onRegionPicked: () -> Unit) {
            pendingRegionCallback = onRegionPicked
            pendingBitmap = null
            val intent = Intent(context, ScreenTranslateService::class.java)
                .putExtra(EXTRA_MODE, Mode.ASK_TWO_STEP.name)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else context.startService(intent)
            } catch (_: Exception) {}
        }

        /** Submit the user's question for the captured region. */
        fun submitTwoStepAsk(context: Context, question: String) {
            val svc = instance
            val bmp = pendingBitmap
            if (svc != null && bmp != null) {
                svc.translateImageWithCustom(bmp, Mode.ASK, question)
                pendingBitmap = null
                pendingRegionCallback = null
            }
        }

        /** Cancel the two-step ASK flow. */
        fun cancelTwoStepAsk(context: Context) {
            pendingBitmap = null
            pendingRegionCallback = null
            try { context.stopService(Intent(context, ScreenTranslateService::class.java)) } catch (_: Exception) {}
        }

        fun stop(context: Context) {
            try { context.stopService(Intent(context, ScreenTranslateService::class.java)) }
            catch (_: Exception) {}
        }
    }

    private lateinit var windowManager: WindowManager
    private var selectionOverlay: SelectionOverlayView? = null
    private var resultOverlay: View? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    @Volatile
    private var currentMode: Mode = Mode.TRANSLATE
    @Volatile
    private var customUserPrompt: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        instance = this
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = intent?.getStringExtra(EXTRA_MODE)
            ?.let { name -> runCatching { Mode.valueOf(name) }.getOrNull() }
            ?: Mode.TRANSLATE
        currentMode = mode
        customUserPrompt = intent?.getStringExtra(EXTRA_CUSTOM_PROMPT)
        // (Re)start foreground notification with the right title.
        startForeground(NOTIFICATION_ID, buildNotification(mode.title, mode.instruction))
        // Replace any prior selection overlay so Translate→Answer→Solve
        // can be triggered back-to-back without leftover overlays.
        removeSelectionOverlay()
        removeResultOverlay()
        showSelectionOverlay()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        instance = null
        removeSelectionOverlay()
        removeResultOverlay()
        super.onDestroy()
    }

    private fun showSelectionOverlay() {
        val overlay = SelectionOverlayView(this, hintLabel = currentMode.instruction) { rect ->
            // User finished drawing the selection rectangle.
            removeSelectionOverlay()
            captureAndTranslate(rect)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        try {
            windowManager.addView(overlay, params)
            selectionOverlay = overlay
        } catch (e: Exception) {
            Log.e(TAG, "overlay add failed: ${e.message}")
            stopSelf()
        }
    }

    private fun removeSelectionOverlay() {
        selectionOverlay?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        selectionOverlay = null
    }

    private fun removeResultOverlay() {
        resultOverlay?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        resultOverlay = null
    }

    private fun captureAndTranslate(selectedRect: Rect) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            showResult("屏幕识别需要 Android 11 及以上系统")
            return
        }

        val service = DiaAccessibilityService.getInstance()
        if (service == null) {
            showResult("请先在系统设置中开启灵犀的无障碍服务")
            return
        }

        // takeScreenshot must be called FROM the accessibility service itself.
        service.captureScreenshot { bitmap ->
            if (bitmap == null) {
                scope.launch { showResult("截图失败，请重试") }
                return@captureScreenshot
            }

            // Crop to selected region
            val left = selectedRect.left.coerceIn(0, bitmap.width - 1)
            val top = selectedRect.top.coerceIn(0, bitmap.height - 1)
            val right = selectedRect.right.coerceIn(left + 1, bitmap.width)
            val bottom = selectedRect.bottom.coerceIn(top + 1, bitmap.height)

            try {
                val cropped = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)

                // Scale down if too large
                val maxDim = 512
                val scale = maxDim.toFloat() / maxOf(cropped.width, cropped.height)
                val scaled = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        cropped,
                        (cropped.width * scale).toInt(),
                        (cropped.height * scale).toInt(),
                        true
                    )
                } else cropped

                if (currentMode == Mode.ASK_TWO_STEP) {
                    // Hold the bitmap and signal the caller to collect a question.
                    pendingBitmap = scaled
                    val cb = pendingRegionCallback
                    scope.launch(Dispatchers.Main) {
                        showResult("已选好区域，请说出你的问题…", autoDismissAndStop = false, isFinal = false)
                        cb?.invoke()
                    }
                } else {
                    scope.launch { translateImage(scaled) }
                }
            } catch (e: Exception) {
                Log.e(TAG, "crop failed", e)
                scope.launch { showResult("截图处理失败") }
            }
        }
    }

    /** Public entry for two-step ASK after the question has been collected. */
    fun translateImageWithCustom(bitmap: Bitmap, mode: Mode, customPrompt: String) {
        currentMode = mode
        customUserPrompt = customPrompt
        scope.launch { translateImage(bitmap) }
    }

    private fun translateImage(bitmap: Bitmap) {
        val mode = currentMode
        showResult("${mode.title}中…", autoDismissAndStop = false, isFinal = false)

        // Cancel any prior session to avoid conflicts
        DiaEngine.cancelPilotSession()

        // Use custom voice prompt if provided (ASK mode), otherwise mode default.
        val prompt = customUserPrompt?.takeIf { it.isNotBlank() }
            ?: fill(mode.userPrompt)

        val sb = StringBuilder()
        BackendRouter.sendSingleTurn(
            text = prompt,
            images = listOf(bitmap),
            onToken = { partial, done ->
                if (partial.isNotEmpty()) sb.append(partial)
                if (done) {
                    val result = sb.toString().trim()
                    scope.launch(Dispatchers.Main) {
                        showResult(result.ifBlank { "没有得到结果" })
                    }
                }
            },
            onError = { msg ->
                scope.launch(Dispatchers.Main) { showResult("出错了：$msg") }
            },
            systemInstruction = fill(mode.systemPrompt),
        )
    }

    private fun showResult(text: String) {
        showResult(text, autoDismissAndStop = true, isFinal = true)
    }

    /**
     * 结果卡片：文字可滚动；带「复制 / 发到对话 / 关闭」按钮，
     * 「发到对话」会打开灵犀并把结果放进输入框，可继续追问或编辑。
     */
    private fun showResult(text: String, autoDismissAndStop: Boolean, isFinal: Boolean = true) {
        removeResultOverlay()
        val style = com.dia.app.screen.BubbleConfig.style.value

        val card = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xF21F1A16.toInt())
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0x66D4A85A)
            }
            elevation = dp(8).toFloat()
        }
        val scroll = android.widget.ScrollView(this)
        val tv = TextView(this).apply {
            this.text = text
            setTextColor(0xFFF0E8D8.toInt())
            textSize = 15f
            setLineSpacing(0f, 1.25f)
            setTextIsSelectable(isFinal)
        }
        scroll.addView(tv)
        card.addView(scroll, android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
        ))
        if (isFinal) {
            val row = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = Gravity.END
                setPadding(0, dp(8), 0, 0)
            }
            fun btn(label: String, color: Int, onClick: () -> Unit) {
                val b = TextView(this).apply {
                    this.text = label
                    setTextColor(color)
                    textSize = 13f
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                    setOnClickListener { onClick() }
                }
                row.addView(b)
            }
            btn("复制", 0xFFD4A85A.toInt()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("灵犀", text))
                android.widget.Toast.makeText(this, "已复制", android.widget.Toast.LENGTH_SHORT).show()
            }
            btn("发到对话", 0xFFE0533F.toInt()) {
                com.dia.app.screen.ChatBridge.openChatWithDraft(this, "【${currentMode.title}结果】\n$text\n\n")
                removeResultOverlay()
                stopSelf()
            }
            btn("关闭", 0xFFB5A88F.toInt()) {
                removeResultOverlay()
                if (autoDismissAndStop) stopSelf()
            }
            card.addView(row)
        }

        val screenH = resources.displayMetrics.heightPixels
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        tv.maxHeight = (screenH * 0.5f).toInt()

        try {
            windowManager.addView(card, params)
            resultOverlay = card
        } catch (e: Exception) {
            Log.e(TAG, "result overlay failed: ${e.message}")
        }

        val seconds = style.resultSeconds
        if (autoDismissAndStop && seconds > 0) {
            scope.launch {
                delay(seconds * 1000L)
                if (resultOverlay === card) {
                    removeResultOverlay()
                    stopSelf()
                }
            }
        } else if (!isFinal) {
            // 「处理中」提示不自动关闭，结果出来时会被替换
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "灵犀 屏幕识别", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_dia_logo)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pending)
            .build()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
