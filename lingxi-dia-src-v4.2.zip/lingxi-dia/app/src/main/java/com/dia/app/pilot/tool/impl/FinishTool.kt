package com.dia.app.pilot.tool.impl

import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class FinishTool : BaseTool() {
    override fun getName(): String = "finish"

    override fun getDescription(): String = "Finish the task with a summary."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("summary", "string", "Short summary of what was done", true),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        val summary = requireString(params, "summary")
        return ToolResult.success(summary)
    }
}
