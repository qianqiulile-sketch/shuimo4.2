package com.dia.app.agent

import org.json.JSONArray
import org.json.JSONObject

/**
 * 工具目录：给「工具台」和「@工具」用的说明书——每个工具的参数表、说法示例、主参数。
 *
 * 同一套工具既可以由 AI 自主调用（模型输出 `<tool>`），也可以由用户亲自调用：
 *  - 在输入框写「@联网搜索 今日新闻」「@计算 (12+3)*4」「@web_search {"query":"…"}」
 *  - 或者在工具台里选工具、填参数，「立即执行」或「执行后交给 AI」
 */
object ToolCatalog {

    data class Param(
        val key: String,
        val example: String,
        val choices: List<String> = emptyList(),
        val kind: String = "text", // text / file / files / bool / number / list / json / long
    )

    data class Mention(val calls: List<Pair<String, JSONObject>>, val text: String)

    val GROUP_LABELS = linkedMapOf(
        "core" to "常用", "doc" to "文档", "phone" to "手机", "home" to "家居", "app" to "灵犀自身", "deep" to "长思专用",
    )

    /** 自然语言的说法示例（直接这样跟灵犀说，它就会调用这个工具）。 */
    val EXAMPLES: Map<String, List<String>> = mapOf(
        "web_search" to listOf("查一下今天的金价", "搜搜最新的 Android 版本"),
        "read_webpage" to listOf("读一下这个网页：https://…"),
        "step_think" to listOf("深入分析一下这个问题", "/分步 比较三种方案"),
        "calc" to listOf("算一下 1234×5.6", "月供多少：本金 50 万、年利率 3.5%、30 年"),
        "read_file" to listOf("看看这份文件讲了什么"),
        "create_file" to listOf("把上面的内容存成 Word", "做一个 Excel 表格"),
        "edit_file" to listOf("把第 3 段改成…", "把 PPT 第 2 页标题改成…"),
        "rewrite_file" to listOf("把这份文档润色一遍", "整篇翻译成英文，保留排版"),
        "translate" to listOf("翻译成英文：…"),
        "generate_image" to listOf("画一幅烟雨江南"),
        "remember" to listOf("记住我对花生过敏"),
        "recall" to listOf("你记得我喜欢什么吗"),
        "ai_files" to listOf("看看你的文件夹里有什么", "把刚才的想法记到你的笔记里"),
        "transcribe_audio" to listOf("把这段录音转成文字", "/转写"),
        "listen_audio" to listOf("听听这段音频里说话人是什么情绪"),
        "deep_think" to listOf("开始长思：研究国产大模型的发展", "帮我持续跟进这个课题"),
        "doc_outline" to listOf("看看这份 PPT 每页讲什么"),
        "list_files" to listOf("看看下载目录里有什么"),
        "pdf_tool" to listOf("把这两个 PDF 合并", "提取第 3~5 页"),
        "convert_file" to listOf("把这个 Word 转成 PDF"),
        "restore_file" to listOf("把文件还原到修改前"),
        "download" to listOf("把这个文件下载下来：https://…"),
        "open_app" to listOf("打开微信"),
        "phone_task" to listOf("打开微信给张三发：晚点到"),
        "phone_action" to listOf("点一下「确定」", "往下滑"),
        "read_screen" to listOf("看看我屏幕上有什么"),
        "look_screen" to listOf("截屏看看这张图是什么"),
        "notifications" to listOf("有哪些未读通知"),
        "clipboard" to listOf("读一下剪贴板"),
        "device_info" to listOf("还剩多少电"),
        "list_apps" to listOf("我装了哪些地图应用"),
        "contacts" to listOf("张三的电话是多少"),
        "call_phone" to listOf("给妈妈打电话"),
        "send_message" to listOf("给李四发短信说我到了"),
        "open_url" to listOf("用浏览器打开 bilibili.com"),
        "guide" to listOf("教我在设置里打开深色模式"),
        "translate_screen" to listOf("翻译屏幕上的内容"),
        "smart_home" to listOf("把客厅灯打开"),
        "open_page" to listOf("打开手写板"),
        "set_theme" to listOf("换成夜间主题"),
        "set_background" to listOf("/背景 雪夜孤舟"),
        "forget" to listOf("忘掉关于花生的记忆"),
        "theme" to listOf("换成水墨太极主题", "把发送按钮换成「发」字", "生成一个青绿山水主题"),
        "plan" to listOf("（长思中 AI 自己用）"),
        "ask_user" to listOf("（长思中 AI 自己用）"),
        "mark_file" to listOf("（长思中 AI 自己用：把用完的资料标成已用过）"),
    )

    /** 便于 @ 的别名。 */
    private val ALIASES = mapOf(
        "搜索" to "web_search", "搜" to "web_search", "联网" to "web_search", "计算" to "calc", "算" to "calc",
        "画" to "generate_image", "画图" to "generate_image", "翻译" to "translate", "译" to "translate",
        "长思" to "deep_think", "转写" to "transcribe_audio", "听" to "listen_audio", "文件夹" to "ai_files",
        "记住" to "remember", "读屏" to "read_screen", "主题" to "theme", "分步" to "step_think",
    )

    fun find(token: String): ToolSpec? {
        val t = token.trim().trimStart('@').trimEnd('：', ':', '，', ',')
        if (t.isEmpty()) return null
        AgentTools.spec(t)?.let { return it }
        AgentTools.ALL.firstOrNull { it.title == t }?.let { return it }
        ALIASES[t]?.let { return AgentTools.spec(it) }
        return AgentTools.ALL.firstOrNull { it.title.replace(" ", "").equals(t.replace(" ", ""), true) }
    }

    fun params(spec: ToolSpec): List<Param> {
        val o = try { JSONObject(spec.args) } catch (_: Exception) { return emptyList() }
        val out = ArrayList<Param>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = o.get(k)
            out.add(
                when {
                    v is Boolean -> Param(k, v.toString(), kind = "bool")
                    v is Number -> Param(k, v.toString(), kind = "number")
                    v is JSONArray -> Param(k, v.join("，").replace("\"", ""), kind = if (k == "files") "files" else "list")
                    v is JSONObject -> Param(k, v.toString(), kind = "json")
                    else -> {
                        val s = v.toString()
                        val choices = if (s.contains('|') && !s.contains(' ')) s.split('|').filter { it.isNotBlank() } else emptyList()
                        val kind = when {
                            k == "file" -> "file"
                            k in setOf("content", "text", "instruction", "body", "task", "question", "topic") -> "long"
                            else -> "text"
                        }
                        Param(k, if (choices.isNotEmpty()) choices.first() else s, choices, kind)
                    }
                },
            )
        }
        return out
    }

    /** 只写一句话时，这句话填进哪个参数。 */
    fun primaryKey(spec: ToolSpec): String? = when (spec.name) {
        "edit_file", "pdf_tool", "phone_action", "ai_files", "theme", "plan", "smart_home", "clipboard", "set_background" -> null
        "translate" -> "text"
        else -> params(spec).firstOrNull { it.kind in setOf("text", "long", "file") }?.key
    }

    /** 把表单里填的字符串转成工具参数（自动转数字、布尔、列表、JSON）。 */
    fun buildArgs(spec: ToolSpec, values: Map<String, String>): JSONObject {
        val ps = params(spec).associateBy { it.key }
        val o = JSONObject()
        for ((k, raw) in values) {
            val v = raw.trim()
            if (v.isEmpty()) continue
            val p = ps[k]
            when (p?.kind) {
                "bool" -> o.put(k, v == "true" || v == "是" || v == "1" || v == "开")
                "number" -> o.put(k, v.toIntOrNull() ?: v.toDoubleOrNull() ?: v)
                "list", "files" -> o.put(k, if (v.startsWith("[")) (try { JSONArray(v) } catch (_: Exception) { JSONArray().put(v) })
                    else JSONArray(v.split(Regex("[，,\\n]")).map { it.trim() }.filter { it.isNotEmpty() }))
                "json" -> o.put(k, try { if (v.startsWith("[")) JSONArray(v) else JSONObject(v) } catch (_: Exception) { v })
                else -> o.put(k, v)
            }
        }
        return o
    }

    /**
     * 解析「@工具 参数」。支持：
     *  - @联网搜索 今天北京天气
     *  - @calc (12+3)*4
     *  - @web_search {"query":"…"}
     *  - 多个：@联网搜索 金价 @计算 3*4（每个 @ 开始一个新调用）
     * 返回 null 表示 @ 后面不是已知工具（当作普通文字发送）。
     */
    fun parseMention(text: String): Mention? {
        val parts = Regex("(?:^|\\s)@(\\S+)").findAll(text).toList()
        if (parts.isEmpty()) return null
        val calls = ArrayList<Pair<String, JSONObject>>()
        val rest = StringBuilder()
        for ((i, m) in parts.withIndex()) {
            val spec = find(m.groupValues[1]) ?: continue
            val start = m.range.last + 1
            val end = if (i + 1 < parts.size) parts[i + 1].range.first else text.length
            val argText = text.substring(start, end).trim()
            val args = when {
                argText.startsWith("{") -> try { JSONObject(argText) } catch (_: Exception) { null }
                else -> null
            } ?: JSONObject().also { o ->
                val key = primaryKey(spec)
                if (argText.isNotBlank()) {
                    if (key != null) o.put(key, argText) else o.put("action", argText.substringBefore(' ')).put("text", argText.substringAfter(' ', ""))
                }
            }
            calls.add(spec.name to args)
            if (!argText.startsWith("{")) rest.append(argText).append(' ')
        }
        if (calls.isEmpty()) return null
        return Mention(calls, rest.toString().trim())
    }

    /** 参数摘要（显示在用户消息里）。 */
    fun argsSummary(args: JSONObject): String {
        val sb = StringBuilder()
        val keys = args.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = args.opt(k)?.toString().orEmpty()
            if (v.isBlank()) continue
            if (sb.isNotEmpty()) sb.append("  ")
            sb.append(k).append('=').append(v.replace('\n', ' ').take(60))
        }
        return sb.toString()
    }
}
